use tdln_backends::cuda::CudaGenerator;

#[test]
fn test_cuda_generator_matmul() {
    let code = CudaGenerator::generate_matmul(4);
    
    assert!(code.contains("__global__"));
    assert!(code.contains("matmul_4x4"));
}

#[test]
fn test_cuda_generator_deterministic() {
    let code1 = CudaGenerator::generate_matmul(16);
    let code2 = CudaGenerator::generate_matmul(16);
    
    assert_eq!(code1, code2);
}
