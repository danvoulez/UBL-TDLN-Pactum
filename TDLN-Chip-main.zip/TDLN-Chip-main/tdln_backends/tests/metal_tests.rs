use tdln_backends::metal::MetalGenerator;

#[test]
fn test_metal_generator_matmul() {
    let code = MetalGenerator::generate_matmul(4);
    
    // Verificar que código Metal foi gerado
    assert!(code.contains("kernel"));
    assert!(code.contains("matmul_4x4"));
    assert!(code.contains("metal_stdlib"));
}

#[test]
fn test_metal_generator_deterministic() {
    let code1 = MetalGenerator::generate_matmul(8);
    let code2 = MetalGenerator::generate_matmul(8);
    
    // Mesma entrada deve gerar mesmo código
    assert_eq!(code1, code2);
}

#[test]
fn test_metal_generator_different_sizes() {
    let code4 = MetalGenerator::generate_matmul(4);
    let code8 = MetalGenerator::generate_matmul(8);
    
    // Tamanhos diferentes devem gerar códigos diferentes
    assert_ne!(code4, code8);
    assert!(code4.contains("4x4"));
    assert!(code8.contains("8x8"));
}
