use tdln_backends::verilog::VerilogGenerator;

#[test]
fn test_verilog_generator_creates_module() {
    let code = VerilogGenerator::generate_matmul(4);
    
    assert!(code.contains("module"));
    assert!(code.contains("matmul_4x4"));
    assert!(code.contains("endmodule"));
}

#[test]
fn test_verilog_generator_deterministic() {
    let code1 = VerilogGenerator::generate_matmul(8);
    let code2 = VerilogGenerator::generate_matmul(8);
    
    assert_eq!(code1, code2);
}
