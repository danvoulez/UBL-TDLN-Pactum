use tdln_core::*;

pub struct CudaGenerator;

impl CudaGenerator {
    pub fn generate_matmul(size: usize) -> String {
        format!(r#"#include <cuda_runtime.h>

// Basic matrix multiplication kernel
__global__ void matmul_{size}x{size}(
    const float* A,
    const float* B,
    float* C,
    int N
)
{{
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;
    
    if (row >= N || col >= N) {{
        return;
    }}
    
    float sum = 0.0f;
    for (int k = 0; k < N; k++) {{
        sum += A[row * N + k] * B[k * N + col];
    }}
    
    C[row * N + col] = sum;
}}

// Optimized version with shared memory tiling
__global__ void matmul_{size}x{size}_optimized(
    const float* A,
    const float* B,
    float* C,
    int N
)
{{
    const int TILE_SIZE = 16;
    
    __shared__ float As[16][16];
    __shared__ float Bs[16][16];
    
    int bx = blockIdx.x;
    int by = blockIdx.y;
    int tx = threadIdx.x;
    int ty = threadIdx.y;
    
    int row = by * TILE_SIZE + ty;
    int col = bx * TILE_SIZE + tx;
    
    float sum = 0.0f;
    
    // Loop over tiles
    for (int t = 0; t < (N + TILE_SIZE - 1) / TILE_SIZE; t++) {{
        // Load tile of A into shared memory
        if (row < N && t * TILE_SIZE + tx < N) {{
            As[ty][tx] = A[row * N + t * TILE_SIZE + tx];
        }} else {{
            As[ty][tx] = 0.0f;
        }}
        
        // Load tile of B into shared memory
        if (col < N && t * TILE_SIZE + ty < N) {{
            Bs[ty][tx] = B[(t * TILE_SIZE + ty) * N + col];
        }} else {{
            Bs[ty][tx] = 0.0f;
        }}
        
        __syncthreads();
        
        // Compute partial dot product for this tile
        #pragma unroll
        for (int k = 0; k < TILE_SIZE; k++) {{
            sum += As[ty][k] * Bs[k][tx];
        }}
        
        __syncthreads();
    }}
    
    // Write result
    if (row < N && col < N) {{
        C[row * N + col] = sum;
    }}
}}

// Wrapper for launching the kernel
extern "C" void launch_matmul_{size}(
    const float* d_A,
    const float* d_B,
    float* d_C,
    cudaStream_t stream
)
{{
    const int N = {size};
    const int TILE_SIZE = 16;
    
    dim3 blockDim(TILE_SIZE, TILE_SIZE);
    dim3 gridDim((N + TILE_SIZE - 1) / TILE_SIZE, (N + TILE_SIZE - 1) / TILE_SIZE);
    
    matmul_{size}x{size}_optimized<<<gridDim, blockDim, 0, stream>>>(d_A, d_B, d_C, N);
}}
"#       // kernel call in wrapper
        )
    }
    
    pub fn generate_dot_product(size: usize) -> String {
        format!(r#"#include <cuda_runtime.h>

// Dot product with reduction in shared memory
__global__ void dot_product_{size}(
    const float* A,
    const float* B,
    float* partial_sums,
    int N
)
{{
    const int BLOCK_SIZE = 256;
    
    __shared__ float shared_data[BLOCK_SIZE];
    
    int tid = threadIdx.x;
    int gid = blockIdx.x * blockDim.x + threadIdx.x;
    int gridSize = blockDim.x * gridDim.x;
    
    float sum = 0.0f;
    
    // Grid-stride loop: each thread sums multiple elements
    for (int i = gid; i < N; i += gridSize) {{
        sum += A[i] * B[i];
    }}
    
    shared_data[tid] = sum;
    __syncthreads();
    
    // Reduction in shared memory
    for (int s = blockDim.x / 2; s > 0; s >>= 1) {{
        if (tid < s) {{
            shared_data[tid] += shared_data[tid + s];
        }}
        __syncthreads();
    }}
    
    // Write result for this block
    if (tid == 0) {{
        partial_sums[blockIdx.x] = shared_data[0];
    }}
}}

// Wrapper for launching the kernel
extern "C" void launch_dot_product_{size}(
    const float* d_A,
    const float* d_B,
    float* d_partial_sums,
    int num_blocks,
    cudaStream_t stream
)
{{
    const int N = {size};
    const int BLOCK_SIZE = 256;
    
    dot_product_{size}<<<num_blocks, BLOCK_SIZE, 0, stream>>>(d_A, d_B, d_partial_sums, N);
}}
"#)
    }
    
    pub fn generate_convolution(
        input_size: usize,
        kernel_size: usize,
        output_size: usize,
    ) -> String {
        format!(r#"#include <cuda_runtime.h>

// 2D Convolution kernel
__global__ void convolution_{input_size}x{input_size}_k{kernel_size}(
    const float* input,
    const float* kernel,
    float* output,
    int input_size,
    int kernel_size,
    int output_size
)
{{
    int out_row = blockIdx.y * blockDim.y + threadIdx.y;
    int out_col = blockIdx.x * blockDim.x + threadIdx.x;
    
    if (out_row >= output_size || out_col >= output_size) {{
        return;
    }}
    
    float sum = 0.0f;
    
    for (int kr = 0; kr < kernel_size; kr++) {{
        for (int kc = 0; kc < kernel_size; kc++) {{
            int in_row = out_row + kr;
            int in_col = out_col + kc;
            
            if (in_row < input_size && in_col < input_size) {{
                sum += input[in_row * input_size + in_col] * 
                       kernel[kr * kernel_size + kc];
            }}
        }}
    }}
    
    output[out_row * output_size + out_col] = sum;
}}

extern "C" void launch_convolution_{input_size}_k{kernel_size}(
    const float* d_input,
    const float* d_kernel,
    float* d_output,
    cudaStream_t stream
)
{{
    const int INPUT_SIZE = {input_size};
    const int KERNEL_SIZE = {kernel_size};
    const int OUTPUT_SIZE = {output_size};
    
    dim3 blockDim(16, 16);
    dim3 gridDim(
        (OUTPUT_SIZE + blockDim.x - 1) / blockDim.x,
        (OUTPUT_SIZE + blockDim.y - 1) / blockDim.y
    );
    
    convolution_{input_size}x{input_size}_k{kernel_size}<<<gridDim, blockDim, 0, stream>>>(
        d_input, d_kernel, d_output,
        INPUT_SIZE, KERNEL_SIZE, OUTPUT_SIZE
    );
}}
"#   // kernel call
        )
    }
    
    pub fn generate_from_op(op: &SemanticOp) -> String {
        match op {
            SemanticOp::MatMul => {
                // Default size for demo, real implementation would extract from context
                Self::generate_matmul(512)
            }
            SemanticOp::DotProduct => {
                Self::generate_dot_product(1024)
            }
            SemanticOp::Convolution2D => {
                // Default MNIST-like size
                Self::generate_convolution(28, 3, 26)
            }
            _ => format!("// TODO: Implement CUDA for {op:?}"),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_generate_matmul() {
        let cuda = CudaGenerator::generate_matmul(512);
        assert!(cuda.contains("__global__ void matmul_512x512"));
        assert!(cuda.contains("matmul_512x512_optimized"));
        assert!(cuda.contains("__shared__ float As[16][16]"));
        assert!(cuda.contains("__syncthreads()"));
        assert!(cuda.contains("launch_matmul_512"));
    }

    #[test]
    fn test_generate_dot_product() {
        let cuda = CudaGenerator::generate_dot_product(1000);
        assert!(cuda.contains("__global__ void dot_product_1000"));
        assert!(cuda.contains("BLOCK_SIZE = 256"));
        assert!(cuda.contains("__syncthreads()"));
        assert!(cuda.contains("launch_dot_product_1000"));
    }
    
    #[test]
    fn test_generate_convolution() {
        let cuda = CudaGenerator::generate_convolution(28, 3, 26);
        assert!(cuda.contains("convolution_28x28_k3"));
        assert!(cuda.contains("launch_convolution_28_k3"));
    }
    
    #[test]
    fn test_generate_from_op() {
        let matmul = SemanticOp::MatMul;
        let cuda = CudaGenerator::generate_from_op(&matmul);
        assert!(cuda.contains("matmul_512x512"));
        
        let dot = SemanticOp::DotProduct;
        let cuda = CudaGenerator::generate_from_op(&dot);
        assert!(cuda.contains("dot_product_1024"));
        
        let conv = SemanticOp::Convolution2D;
        let cuda = CudaGenerator::generate_from_op(&conv);
        assert!(cuda.contains("convolution_28x28_k3"));
    }
}
