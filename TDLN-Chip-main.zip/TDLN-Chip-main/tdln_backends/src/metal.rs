pub struct MetalGenerator;

impl MetalGenerator {
    pub fn generate_matmul(size: usize) -> String {
        format!(r#"#include <metal_stdlib>
using namespace metal;

kernel void matmul_{size}x{size}(
    device const float* A [[buffer(0)]],
    device const float* B [[buffer(1)]],
    device float* C [[buffer(2)]],
    uint2 gid [[thread_position_in_grid]]
)
{{
    uint row = gid.y;
    uint col = gid.x;
    
    if (row >= {size} || col >= {size}) {{
        return;
    }}
    
    float sum = 0.0;
    for (uint k = 0; k < {size}; k++) {{
        sum += A[row * {size} + k] * B[k * {size} + col];
    }}
    
    C[row * {size} + col] = sum;
}}

// Optimized version with thread group memory
kernel void matmul_{size}x{size}_optimized(
    device const float* A [[buffer(0)]],
    device const float* B [[buffer(1)]],
    device float* C [[buffer(2)]],
    uint2 gid [[thread_position_in_grid]],
    uint2 tid [[thread_position_in_threadgroup]],
    uint2 tgid [[threadgroup_position_in_grid]]
)
{{
    const uint TILE_SIZE = 16;
    threadgroup float As[TILE_SIZE][TILE_SIZE];
    threadgroup float Bs[TILE_SIZE][TILE_SIZE];
    
    uint row = tgid.y * TILE_SIZE + tid.y;
    uint col = tgid.x * TILE_SIZE + tid.x;
    
    float sum = 0.0;
    
    for (uint t = 0; t < ({size} + TILE_SIZE - 1) / TILE_SIZE; t++) {{
        // Load tiles into threadgroup memory
        if (row < {size} && t * TILE_SIZE + tid.x < {size}) {{
            As[tid.y][tid.x] = A[row * {size} + t * TILE_SIZE + tid.x];
        }} else {{
            As[tid.y][tid.x] = 0.0;
        }}
        
        if (col < {size} && t * TILE_SIZE + tid.y < {size}) {{
            Bs[tid.y][tid.x] = B[(t * TILE_SIZE + tid.y) * {size} + col];
        }} else {{
            Bs[tid.y][tid.x] = 0.0;
        }}
        
        threadgroup_barrier(mem_flags::mem_threadgroup);
        
        // Compute partial dot product
        for (uint k = 0; k < TILE_SIZE; k++) {{
            sum += As[tid.y][k] * Bs[k][tid.x];
        }}
        
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }}
    
    if (row < {size} && col < {size}) {{
        C[row * {size} + col] = sum;
    }}
}}
"#         // output indexing
        )
    }
    
    pub fn generate_dot_product(size: usize) -> String {
        format!(r#"#include <metal_stdlib>
using namespace metal;

kernel void dot_product_{size}(
    device const float* A [[buffer(0)]],
    device const float* B [[buffer(1)]],
    device float* partial_sums [[buffer(2)]],
    uint gid [[thread_position_in_grid]],
    uint lid [[thread_position_in_threadgroup]],
    uint group_id [[threadgroup_position_in_grid]]
)
{{
    const uint GROUP_SIZE = 256;
    threadgroup float shared_data[GROUP_SIZE];
    
    float sum = 0.0;
    
    // Each thread sums multiple elements
    for (uint i = gid; i < {size}; i += GROUP_SIZE * num_threadgroups) {{
        sum += A[i] * B[i];
    }}
    
    shared_data[lid] = sum;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    
    // Reduction in shared memory
    for (uint s = GROUP_SIZE / 2; s > 0; s >>= 1) {{
        if (lid < s) {{
            shared_data[lid] += shared_data[lid + s];
        }}
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }}
    
    // Write result for this threadgroup
    if (lid == 0) {{
        partial_sums[group_id] = shared_data[0];
    }}
}}
"#)
    }
}

impl MetalGenerator {
    pub fn generate_from_op(op: &tdln_core::SemanticOp) -> String {
        match op {
            tdln_core::SemanticOp::MatMul => {
                Self::generate_matmul(512)
            }
            tdln_core::SemanticOp::DotProduct => {
                Self::generate_dot_product(1024)
            }
            tdln_core::SemanticOp::Convolution2D => {
                Self::generate_matmul(28) // placeholder
            }
            _ => format!("// TODO: Implement Metal for {op:?}"),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_generate_matmul() {
        let shader = MetalGenerator::generate_matmul(256);
        assert!(shader.contains("kernel void matmul_256x256"));
        assert!(shader.contains("matmul_256x256_optimized"));
        assert!(shader.contains("TILE_SIZE = 16"));
    }

    #[test]
    fn test_generate_dot_product() {
        let shader = MetalGenerator::generate_dot_product(1000);
        assert!(shader.contains("kernel void dot_product_1000"));
        assert!(shader.contains("GROUP_SIZE = 256"));
    }
}
