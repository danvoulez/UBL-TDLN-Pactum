pub use tdln_core::*;

pub mod metal;
pub mod cuda;
pub mod verilog;

pub use metal::MetalGenerator;
pub use cuda::CudaGenerator;
pub use verilog::VerilogGenerator;
