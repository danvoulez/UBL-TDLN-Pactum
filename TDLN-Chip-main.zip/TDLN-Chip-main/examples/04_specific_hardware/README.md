# Specific Hardware Examples

Esta pasta contém exemplos para **hardware específico** com otimizações customizadas.

## Targets Disponíveis

### 🍎 Apple Silicon

#### M4 Pro
```json
{
  "compilation": {
    "backend": "metal",
    "target": "apple-m4-pro",
    "custom_target": {
      "architecture": "arm64",
      "gpu_family": "Apple9",
      "max_threads_per_threadgroup": 1024,
      "shared_memory_kb": 64
    }
  }
}
```

**Features**: 20-core GPU, 273 GB/s bandwidth

#### M4 Max
```json
{
  "target": "apple-m4-max",
  "custom_target": {
    "gpu_cores": 40,
    "memory_bandwidth_gbs": 546
  }
}
```

---

### 🟢 NVIDIA GPUs

#### H100 (Hopper)
```json
{
  "compilation": {
    "backend": "cuda",
    "target": "nvidia-h100",
    "custom_target": {
      "compute_capability": "9.0",
      "tensor_cores": true,
      "nvlink": true,
      "hbm3_bandwidth_tbs": 3.35
    }
  }
}
```

**Features**: 80 GB HBM3, 3.35 TB/s bandwidth

#### A100 (Ampere)
```json
{
  "target": "nvidia-a100",
  "custom_target": {
    "compute_capability": "8.0",
    "multi_instance_gpu": true
  }
}
```

---

### 🔴 AMD Radeon

#### MI300X
```json
{
  "compilation": {
    "backend": "rocm",
    "target": "amd-mi300x",
    "custom_target": {
      "compute_units": 304,
      "hbm3_memory_gb": 192,
      "memory_bandwidth_tbs": 5.3
    }
  }
}
```

---

### ⚡ FPGAs

#### Xilinx Virtex UltraScale+
```json
{
  "compilation": {
    "backend": "verilog",
    "target": "xilinx-virtex-ultrascale-plus",
    "custom_target": {
      "logic_cells": 1143000,
      "dsp_slices": 6840,
      "bram_mb": 71.3
    }
  }
}
```

#### Intel Stratix 10
```json
{
  "target": "intel-stratix-10",
  "custom_target": {
    "alms": 933000,
    "dsp_blocks": 5760
  }
}
```

---

## Otimizações por Hardware

### Apple M4
```json
{
  "custom_optimizations": {
    "simdgroup_size": 32,
    "threadgroup_memory_optimization": true,
    "texture_swizzling": true
  }
}
```

### NVIDIA H100
```json
{
  "custom_optimizations": {
    "tensor_core_utilization": true,
    "async_copy": true,
    "thread_block_cluster": true
  }
}
```

### AMD MI300X
```json
{
  "custom_optimizations": {
    "wave_size": 64,
    "lds_optimization": true,
    "infinity_fabric_aware": true
  }
}
```

## Profiling por Hardware

```json
{
  "profiling": {
    "custom_metrics": {
      // Apple Metal
      "gpu_utilization_percent": 95.3,
      "memory_bandwidth_utilization": 0.87,
      
      // NVIDIA CUDA
      "sm_occupancy": 0.92,
      "tensor_core_utilization": 0.88,
      
      // AMD ROCm
      "wavefront_occupancy": 0.90,
      "valu_utilization": 0.85
    }
  }
}
```

## Como Escolher Target

1. **Identifique seu hardware**: `metal-smi`, `nvidia-smi`, `rocm-smi`
2. **Configure target**: Escolha preset ou custom
3. **Otimize**: Ajuste flags específicas
4. **Benchmark**: Meça performance real
5. **Itere**: Refine otimizações

## Recursos

- [MAC_MINI_RESULTS.md](../../MAC_MINI_RESULTS.md) - M4 Pro benchmarks
- [NVIDIA_COMPARISON.md](../../NVIDIA_COMPARISON.md) - NVIDIA benchmarks
- [CUSTOMIZATION.md](../../CUSTOMIZATION.md) - Customização avançada
