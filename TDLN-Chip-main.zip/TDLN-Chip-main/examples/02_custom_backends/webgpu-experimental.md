# WebGPU Backend (Experimental)

This example demonstrates compilation to WebGPU for browser-native execution.

## Why WebGPU?

- **Universal**: Runs in Chrome, Edge, Firefox
- **Zero install**: No drivers, just a browser
- **Performance**: Near-native GPU speed
- **Accessible**: Democratizes GPU computing

## Status

🚧 **Experimental** - Not production-ready yet

## Example Policy

```json
{
  "tdln_spec_version": "2.0.0",
  "node_type": "semantic_unit",
  "name": "webgpu_vector_add",
  "materialization_hints": {
    "backend": "webgpu",
    "shader_stage": "compute"
  },
  "policies": [ ... ]
}
```

## Expected Output: WGSL Shader

```wgsl
@group(0) @binding(0) var<storage, read> input_a: array<f32>;
@group(0) @binding(1) var<storage, read> input_b: array<f32>;
@group(0) @binding(2) var<storage, read_write> output: array<f32>;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
    let idx = global_id.x;
    output[idx] = input_a[idx] + input_b[idx];
}
```

## Browser Integration

```javascript
// Request GPU device
const adapter = await navigator.gpu.requestAdapter();
const device = await adapter.requestDevice();

// Load compiled WGSL
const shaderModule = device.createShaderModule({ code: wgslCode });

// Create pipeline
const pipeline = device.createComputePipeline({
  layout: 'auto',
  compute: { module: shaderModule, entryPoint: 'main' }
});

// Execute
// ... bind buffers, dispatch workgroups
```

## Performance

Browser GPUs vary widely, but WebGPU can approach native speeds:

| Device | Backend | Performance |
|--------|---------|-------------|
| M4 Pro (Safari) | Metal | ~90% of native |
| RTX 4060 (Chrome) | Vulkan | ~85% of native |
| Integrated GPU | Any | Varies |

## Use Cases

- **Web apps** needing GPU acceleration
- **Education** (try TDLN without installing anything)
- **Prototyping** before deploying to native
- **Democratization** (anyone with browser can run)

## Contributing

Want to help complete the WebGPU backend?

1. Check [CONTRIBUTING.md](../../CONTRIBUTING.md)
2. See [issues tagged `webgpu`](https://github.com/logline-foundation/TDLN-Chip/issues?q=label:webgpu)
3. Join the discussion!
