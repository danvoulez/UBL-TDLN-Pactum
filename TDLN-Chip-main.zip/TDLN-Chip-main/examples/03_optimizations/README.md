# Optimization Examples

Esta pasta contém exemplos de **otimizações customizadas** para código de hardware.

## Níveis de Otimização Padrão

```json
{
  "compilation": {
    "optimization_level": 0  // 0 = nenhuma, 3 = máxima
  }
}
```

- **Level 0**: Sem otimizações (debug)
- **Level 1**: Otimizações básicas
- **Level 2**: Otimizações agressivas (padrão)
- **Level 3**: Máxima performance (pode aumentar tamanho)

## Otimizações Customizadas

### 🔄 Loop Unrolling

Desenrola loops para reduzir overhead de controle.

```json
{
  "compilation": {
    "custom_optimizations": {
      "loop_unrolling": true,
      "unroll_factor": 4
    }
  }
}
```

**Metal Example**:
```metal
// Antes
for (int i = 0; i < 16; i++) {
    result += input[i];
}

// Depois (unroll_factor = 4)
for (int i = 0; i < 16; i += 4) {
    result += input[i];
    result += input[i+1];
    result += input[i+2];
    result += input[i+3];
}
```

### ⚡ Vectorization

Usa instruções SIMD para processar múltiplos dados.

```json
{
  "compilation": {
    "custom_optimizations": {
      "vectorization": "auto",
      "vector_width": 4
    }
  }
}
```

### 🧠 Memory Coalescing

Otimiza padrões de acesso à memória.

```json
{
  "compilation": {
    "custom_optimizations": {
      "memory_coalescing": true,
      "cache_optimization": "L1"
    }
  }
}
```

### 📊 Register Allocation

Otimiza uso de registradores.

```json
{
  "compilation": {
    "custom_optimizations": {
      "register_pressure_limit": 64,
      "spill_strategy": "minimal"
    }
  }
}
```

### 🔀 Instruction Scheduling

Reordena instruções para minimizar latência.

```json
{
  "compilation": {
    "custom_optimizations": {
      "instruction_scheduling": true,
      "schedule_strategy": "latency_hiding"
    }
  }
}
```

## Benchmarking

```bash
# Compilar sem otimização
cargo run -- compile input.tdln.json --opt-level 0

# Compilar com otimização máxima
cargo run -- compile input.tdln.json --opt-level 3

# Benchmark
cargo bench
```

## Trade-offs

| Otimização | Vantagem | Desvantagem |
|------------|----------|-------------|
| Loop Unrolling | ⬆️ Performance | ⬆️ Tamanho código |
| Vectorization | ⬆️ Throughput | ⬆️ Complexidade |
| Memory Coalescing | ⬆️ Bandwidth | ⬇️ Portabilidade |
| Register Allocation | ⬆️ Velocidade | ⬆️ Tempo compilação |

## Recursos

- [BENCHMARK_RESULTS.md](../../BENCHMARK_RESULTS.md) - Resultados
- [CUSTOMIZATION.md](../../CUSTOMIZATION.md) - Guia customização
