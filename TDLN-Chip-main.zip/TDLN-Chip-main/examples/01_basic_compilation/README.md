# Basic Compilation Examples

Simple TDLN policy compilation to different hardware backends.

## What's Here

These examples demonstrate the fundamental compilation pipeline:

1. **Parse** a `.tdln.json` policy
2. **Canonicalize** to minimal form
3. **Compile** to target backend (Metal, CUDA, Verilog)
4. **Execute** and measure performance

## Files

- [simple-matmul.tdln.json](simple-matmul.tdln.json) - Matrix multiplication example with GPU hints

## Available Backends

### 🍎 Metal (Apple Silicon)

For macOS with M1/M2/M3/M4 chips:

```bash
cargo run -- compile simple-matmul.tdln.json --backend metal
```

**Target**: macOS, iOS, Apple Silicon  
**Output**: Metal Shading Language (.metal)  
**Performance**: 250-300 GFLOPS on M4 Pro

### 🟢 CUDA (NVIDIA GPUs)

Requires CUDA Toolkit:

```bash
cargo run -- compile simple-matmul.tdln.json --backend cuda --features cuda
```

**Target**: NVIDIA GPUs  
**Output**: CUDA C++ (.cu)  
**Performance**: 280-350 GFLOPS on RTX 4060

### ⚡ Verilog (FPGA/ASIC)

⚠️ Experimental - generates HDL:

```bash
cargo run -- compile simple-matmul.tdln.json --backend verilog --features verilog
```

**Target**: FPGAs, ASICs  
**Output**: Verilog HDL (.v)  
**Use Case**: Custom silicon, FPGA deployment

## What Gets Compiled?

A TDLN policy like this:

```json
{
  "node_type": "policy_bit",
  "condition": { "type": "binary", "operator": "GT", ... },
  "materialization_hints": {
    "backend": "metal",
    "optimization_level": 2
  }
}
```

Becomes **Metal** like this:

```metal
kernel void policy_kernel(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    uint id [[thread_position_in_grid]]
) {
    output[id] = (input[id] > threshold) ? 1.0 : 0.0;
}
```

Or **CUDA** like this:

```cuda
__global__ void policy_kernel(const float* input, float* output, int n) {
    int id = blockIdx.x * blockDim.x + threadIdx.x;
    if (id < n) output[id] = (input[id] > threshold) ? 1.0f : 0.0f;
}
```

## Workflow

```
TDLN Unit (.tdln.json)
    ↓
TDLN-Chip Parser & Canonicalizer
    ↓
Backend Code Generator
    ↓
Hardware Code (.metal / .cu / .v)
    ↓
Native Compiler (xcrun / nvcc / iverilog)
    ↓
Executable Binary
```

## Performance Comparison

| Backend | Device | GFLOPS | Compile Time | Energy/Op |
|---------|--------|--------|--------------|-----------|
| Metal | M4 Pro | 268 | 0.1s | 0.15 mJ |
| CUDA | RTX 4060 | 295 | 0.15s | 0.18 mJ |
| Verilog | FPGA | Varies | 2-5s | ~0.01 mJ |

## Next Steps

- [Custom backends](../02_custom_backends/) - WebGPU, ROCm, custom targets
- [Optimization](../03_optimization/) - Advanced performance tuning
- [Full compilation](../04_full_compilation/) - Complete pipeline with trace manifests

## Resources

- [INTEGRATION_GUIDE.md](../../docs/INTEGRATION_GUIDE.md) - Complete integration guide
- [CHIP_FORMAT.md](../../specs/CHIP_FORMAT.md) - Chip manifest specification
