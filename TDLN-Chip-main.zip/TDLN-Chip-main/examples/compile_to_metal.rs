//! Exemplo: Compilar SemanticUnit TDLN → Metal GPU Code
//!
//! Este exemplo demonstra como TDLN-Chip usa o core protocol
//! definido em ../TDLN para gerar código Metal.

use tdln_core::{SemanticUnit, PolicyBit, Expression};
use tdln_backends::metal::MetalCompiler;

fn main() {
    // 1. Criar SemanticUnit usando tdln_core (importado de TDLN)
    let unit = SemanticUnit {
        id: "matrix_mul_4x4".to_string(),
        hash: "blake3_abc123...".to_string(),
        expression: Expression::PolicyComposition {
            operator: "AND".to_string(),
            operands: vec![
                Expression::PolicyBit(PolicyBit {
                    name: "input_validated".to_string(),
                    value: 1,
                }),
                Expression::PolicyBit(PolicyBit {
                    name: "output_bounded".to_string(),
                    value: 1,
                }),
            ],
        },
        signature: None,
    };

    // 2. Compilar para Metal (backend específico de TDLN-Chip)
    let compiler = MetalCompiler::new();
    let metal_code = compiler.compile(&unit);

    println!("=== TDLN → Metal GPU Code ===");
    println!("{}", metal_code);
    
    // Resultado: Código Metal otimizado para Apple Silicon
    // - Kernels paralelos
    // - Validação de políticas embutida
    // - ~20ns overhead por operação
}
