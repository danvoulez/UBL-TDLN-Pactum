# TDLN-Chip — From Text Files to Silicon

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Rust](https://img.shields.io/badge/Rust-1.70+-orange.svg)](https://www.rust-lang.org/)

> **Hardware design shouldn't require years of training and millions of dollars. TDLN-Chip proves it doesn't have to.**

TDLN-Chip transforms text files into executable hardware — GPU shaders, FPGA configurations, even ASIC designs. Write your logic once, deploy it anywhere, from cloud servers to embedded devices to custom silicon.

**What this means:**
- **Chip-as-Code**: Hardware design in text files, versionable with git
- **Instant prototyping**: Test infinite variations before fabrication
- **Cost revolution**: $0 to design, cents to manufacture (at scale)
- **Perfect auditability**: Verilog/Metal code is text you can read
- **LLM-native**: Language models can generate chips via prompts

This isn't simulation. It's compilation to real, executable hardware.

---

## 📋 What Is TDLN-Chip?

Traditional hardware design is slow, expensive, and opaque:
- Years to learn Verilog/VHDL
- Months to design a chip
- Millions of dollars to fabricate
- Impossible to audit black-box binaries

**TDLN-Chip flips this model:**

### The Paradigm Shift

Instead of thinking "how do I program this GPU?", think "how do I describe what I want the hardware to do?"

```
Your Intent (text) → TDLN Policy Graph → Hardware Code
```

**Example workflow:**
1. Write policy: "Validate transactions over $10,000"
2. Generate .tdln file (manually or via LLM)
3. Compile to Metal (Apple GPU) or CUDA (NVIDIA) or Verilog (FPGA)
4. Deploy to hardware
5. **Result**: Purpose-built accelerator, generated from text

### Proven Performance

Real benchmarks on Apple M4 Pro (20-core GPU):
- **268 GFLOPS** peak performance
- **0.47ms** latency for complex policy graphs
- **7x energy efficiency** vs general-purpose CPUs
- **Linear scaling**: 2.5x cores = 2.5x performance
- **20,000x cost advantage** (text file vs custom ASIC)

NVIDIA comparison:
- **H100**: 5.9x faster (raw speed)
- **M4 Pro**: 21x cheaper (cost efficiency)
- **RTX 4060**: Similar performance to M4 Pro

**The insight**: For many workloads, cost-per-decision matters more than raw FLOPS.

---

## 📚 Guias

- **[Integration Guide](./docs/INTEGRATION_GUIDE.md)** — Como usar specs TDLN + TDLN-Chip juntos
- **[Chip Format](./specs/CHIP_FORMAT.md)** — Canonização de compilação
- **[Quick Start](./QUICK_START.md)** — Começar em 5 minutos

---

## 🏗️ Estrutura

```
TDLN-Chip/
├── tdln_backends/        # Metal, CUDA, Verilog code generators
├── specs/                # Especificações de formato de chip
│   ├── TDLN_SPEC.md     # Link para spec oficial TDLN
│   ├── CHIP_FORMAT.md   # Canonização .tdln → hardware
│   └── tdln-chip-extensions.schema.json
├── examples/             # Exemplos de compilação
├── Cargo.toml            # Workspace (importa tdln_core de ../TDLN)
└── README.md             # Este arquivo
```

**Nota**: `tdln_core` e `tdln_runtime` residem em [TDLN](https://github.com/logline-foundation/TDLN) e são importados como dependências.

**Especificações**:
- **Formato TDLN Core**: [specs/TDLN_SPEC.md](./specs/TDLN_SPEC.md) (referencia [TDLN](https://github.com/logline-foundation/TDLN))
- **Formato de Chip**: [specs/CHIP_FORMAT.md](./specs/CHIP_FORMAT.md)
- **Extensões**: [specs/tdln-chip-extensions.schema.json](./specs/tdln-chip-extensions.schema.json)

---

## 🚀 Quick Start

### 1. Compilar

```bash
cargo build --release
```

### 2. Executar Benchmarks

```bash
cd ../TDLN/tdln_runtime
cargo bench --bench matrix_ops
```

**Resultado esperado**: ~1.56ms para MatMul 512×512 (M1 GPU)

### 3. Usar como Biblioteca

```toml
[dependencies]
tdln_core = { path = "path/to/tdln_core" }
tdln_backends = { path = "path/to/tdln_backends" }
```

```rust
use tdln_core::{SemanticUnit, PolicyBit};
use tdln_backends::MetalGenerator;

// Carregar .tdln
let tdln_file = std::fs::read_to_string("arquivo.tdln")?;
let unit: SemanticUnit = serde_json::from_str(&tdln_file)?;

// Compilar para Metal
let generator = MetalGenerator::new();
let metal_code = generator.generate(&unit)?;

// Salvar shader
std::fs::write("output.metal", metal_code)?;
```

---

## 📦 Módulos

### tdln_core

Estruturas de dados do TDLN Core:

- `SemanticUnit` — Raiz do arquivo .tdln
- `PolicyBit` — Átomo de decisão
- `PolicyComposition` — Composição de políticas
- `Expression` — AST recursivo (BinaryExpression, UnaryExpression, etc)

### tdln_backends

Geradores de código:

- `MetalGenerator` — Apple Metal shaders
- `CudaGenerator` — NVIDIA CUDA kernels
- `VerilogGenerator` — FPGA/ASIC HDL

### tdln_runtime

Runtime de referência:

- Interpretador CPU para validação
- Benchmarks de baseline
- Testes de performance

---

## 🔥 Performance

### MatMul 512×512 (Apple M1)

| Componente | Latência |
|------------|----------|
| **Execução Metal** | 1.56ms |
| **Integrity (CRC32)** | ~20ns |
| **Total** | 1.56ms |

**vs Python NumPy**: ~17x mais rápido  
**vs Rust CPU**: ~45x mais rápido

---

## 🎯 Responsabilidades

### O Que TDLN Chip Faz

- ✅ Compila `policies[]` do .tdln para hardware
- ✅ Gera código Metal/CUDA/Verilog otimizado
- ✅ Valida integridade física (CRC32 ~20ns)
- ✅ Fornece runtime de referência (CPU)

### O Que TDLN Chip NÃO Faz

- ❌ Define formato .tdln → TDLN Pure
- ❌ Auditoria de workflow (Blake3, Ed25519) → TDLN Pure
- ❌ Tradução LLM → TDLN API
- ❌ Auto-otimização com IA → TDLN API

---

## 🔗 Ecossistema TDLN

```
TDLN Pure (MIT)        → Define .tdln (protocolo)
TDLN Chip (MIT) ⭐     → Compila para hardware
TDLN API (Proprietary) → Serviço LLM + otimização
```

---

## 🛠️ Desenvolvimento

### Estrutura do Código

```rust
// tdln_core/src/lib.rs
pub struct SemanticUnit {
    pub tdln_spec_version: String,
    pub node_type: String,  // "semantic_unit"
    pub id: String,
    pub hash: String,
    pub policies: Vec<Policy>,
    // ...
}

pub enum Policy {
    Bit(PolicyBit),
    Composition(PolicyComposition),
}

pub struct PolicyBit {
    pub node_type: String,  // "policy_bit"
    pub id: String,
    pub hash: String,
    pub condition: Expression,
    // ...
}
```

### Adicionar Novo Backend

1. Crie arquivo em `tdln_backends/src/seu_backend.rs`
2. Implemente trait `CodeGenerator`:

```rust
pub trait CodeGenerator {
    fn generate(&self, unit: &SemanticUnit) -> Result<String>;
}

pub struct SeuBackend;

impl CodeGenerator for SeuBackend {
    fn generate(&self, unit: &SemanticUnit) -> Result<String> {
        // Sua lógica aqui
        Ok(codigo_gerado)
    }
}
```

3. Adicione testes
4. Atualize documentação

---

## 🎨 Extensibilidade e Customização

TDLN-Chip é **extensível por design**. A comunidade pode criar:

- ✅ **Novos backends** (WebGPU, ROCm, TPU, OpenCL, Vulkan, Quantum)
- ✅ **Otimizações customizadas** (loop unrolling, vectorization, etc.)
- ✅ **Targets específicos** (M4 Max, H100, MI300X, FPGAs customizados)
- ✅ **Pipelines avançados** (multi-GPU, heterogeneous, distributed)

**Requisitos de backend**:
- ✅ Compilação determinística
- ✅ Implementar TODAS políticas TDLN
- ✅ Código verificável e auditável
- ✅ Testes de regressão

➡️ **Guia completo**: [CUSTOMIZATION.md](./CUSTOMIZATION.md)  
➡️ **Exemplos categorizados**: [examples/](./examples/)

**Categorias de exemplos**:
1. **[01_basic_compilation/](./examples/01_basic_compilation/)** - Metal, CUDA, Verilog básicos
2. **[02_custom_backends/](./examples/02_custom_backends/)** - WebGPU, ROCm, TPU, OpenCL
3. **[03_optimizations/](./examples/03_optimizations/)** - Loop unrolling, vectorization
4. **[04_specific_hardware/](./examples/04_specific_hardware/)** - M4 Pro, H100, MI300X
5. **[05_advanced/](./examples/05_advanced/)** - Multi-GPU, heterogeneous, streaming

---

## 🧪 Testes

```bash
# Rodar todos os testes
cargo test --workspace

# Rodar benchmarks
cd tdln_runtime
cargo bench

# Check sem compilar
cargo check --workspace
```

---

## 📊 Benchmarks

Performance validated on real hardware:

**Apple M4 Pro (20-core GPU):**
```
MatMul 512×512:     0.47ms   (268 GFLOPS)
MatMul 1024×1024:   3.8ms    (268 GFLOPS sustained)
```

**NVIDIA RTX 4060:**
```
MatMul 512×512:     0.50ms   (~250 GFLOPS)
```

See detailed results:
- [BENCHMARK_RESULTS.md](./BENCHMARK_RESULTS.md) - Complete methodology
- [MAC_MINI_RESULTS.md](./MAC_MINI_RESULTS.md) - M4 Pro specific data
- [NVIDIA_COMPARISON.md](./NVIDIA_COMPARISON.md) - Metal vs CUDA analysis
- [PERFORMANCE_COMPARISON.md](./PERFORMANCE_COMPARISON.md) - Multi-platform comparison

---

## 🤝 Contribuindo

**TDLN-Chip é focado em "chips as code". A comunidade pode expandir backends e otimizações!**

### Como Contribuir

1. Fork o repositório
2. Crie uma branch (`git checkout -b feature/nova-feature`)
3. Siga arquitetura: TDLN core + extensões de chip
4. Preserve compatibilidade com TDLN
5. Abra um Pull Request

### Áreas de Contribuição

- 🔧 **Novos backends** (WebGPU, ROCm, TPU, etc)
- ⚡ **Otimizações** de compilação e performance
- 🧪 **Testes** e benchmarks em novas plataformas
- 📝 **Documentação** de uso e integração
- 🐛 **Bugs** e melhorias

**Importante**: Sempre use specs TDLN core. Ver [Integration Guide](./docs/INTEGRATION_GUIDE.md).

---

## 🧪 Testes

```bash
# Rodar todos os testes
cargo test --workspace

# Testes específicos
cargo test -p tdln_backends

# Com output detalhado
cargo test -- --nocapture
```

---

## 📄 Licença

MIT License — veja [LICENSE](./LICENSE) para detalhes.

---

## 🔗 Links

- **TDLN Core**: [https://github.com/logline-foundation/TDLN](https://github.com/logline-foundation/TDLN)
- **Integration Guide**: [docs/INTEGRATION_GUIDE.md](./docs/INTEGRATION_GUIDE.md)
- **Benchmarks**: [BENCHMARK_RESULTS.md](./BENCHMARK_RESULTS.md)
- **Chip as Code**: [Chip as Code.md](./Chip%20as%20Code.md)

---

**TDLN Chip** — Do SemanticUnit ao silício. 🚀
