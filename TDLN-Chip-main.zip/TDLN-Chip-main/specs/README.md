# TDLN-Chip Specifications

Especificações e referências de formato para TDLN-Chip.

---

## 📜 Arquivos

### 1. [`TDLN_SPEC.md`](./TDLN_SPEC.md) ⭐
**Link para a especificação oficial do protocolo TDLN.**

- ✅ Referencia [TDLN/specs/tdln-core-v2.0.schema.json](../../TDLN/specs/tdln-core-v2.0.schema.json)
- ✅ Explica que TDLN-Chip **NÃO define** o formato `.tdln`
- ✅ Clarifica que TDLN-Chip **IMPORTA** o core de [TDLN](../../TDLN/)

### 2. [`CHIP_FORMAT.md`](./CHIP_FORMAT.md)
**Canonização do formato de compilação de chip.**

- ✅ Entrada: `SemanticUnit` (formato TDLN)
- ✅ Saída: Metal, CUDA, Verilog
- ✅ Garantias: Determinismo, verificabilidade, conformidade

### 3. [`tdln-chip-extensions.schema.json`](./tdln-chip-extensions.schema.json)
**JSON Schema para extensões específicas de hardware.**

- ✅ Metadados de compilação (`backend`, `target`, `optimization_level`)
- ✅ Configuração de hardware (`gpu_model`, `fpga_family`, `memory_budget_mb`)
- ✅ Profiling (`compilation_time_ms`, `execution_time_us`, `throughput_ops_per_sec`)

**IMPORTANTE**: Estas extensões **COMPLEMENTAM** (não substituem) o formato TDLN core.

---

## 🎯 Princípio de Separação

### **TDLN** (Repositório Mãe)
Define o formato `.tdln`:
- `SemanticUnit`
- `PolicyBit`
- `Expression`
- JSON Schema canônico

📍 **Localização**: [../../TDLN/specs/](../../TDLN/specs/)

### **TDLN-Chip** (Esta Aplicação)
Compila `.tdln` → hardware:
- Backends (Metal, CUDA, Verilog)
- Extensões de metadados
- Otimizações de compilação

📍 **Localização**: Este diretório

---

## 📐 Exemplo Completo

### Entrada: `example.tdln.json`
```json
{
  "id": "matrix_mul_4x4",
  "hash": "blake3_abc123...",
  "expression": {
    "PolicyBit": { "name": "validated", "value": 1 }
  }
}
```

### Compilação: `example.tdln-chip.json`
```json
{
  "tdln_core_version": "2.0.0",
  "compilation": {
    "backend": "metal",
    "target": "apple-m4-pro",
    "optimization_level": 3
  },
  "profiling": {
    "compilation_time_ms": 10.5,
    "execution_time_us": 470
  }
}
```

### Saída: `example.metal`
```metal
kernel void semantic_unit_matrix_mul_4x4(...) {
    // Código Metal gerado
}
```

---

## 🔗 Referências

1. **Especificação TDLN Core**: [../../TDLN/specs/tdln-core-v2.0.schema.json](../../TDLN/specs/tdln-core-v2.0.schema.json)
2. **Documentação TDLN**: [../../TDLN/docs/TDLN_FORMAT.md](../../TDLN/docs/TDLN_FORMAT.md)
3. **Arquitetura TDLN**: [../../TDLN/docs/ARCHITECTURE.md](../../TDLN/docs/ARCHITECTURE.md)

---

**TDLN-Chip specs COMPLEMENTAM a spec core, não a substituem.**
