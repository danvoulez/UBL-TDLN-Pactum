# Formato de Chip TDLN

**Canonização do formato `.tdln` → hardware executável**

---

## 🎯 Visão Geral

TDLN-Chip compila `SemanticUnits` (formato TDLN) em código de hardware:

```
.tdln (JSON) → [TDLN-Chip] → Metal/CUDA/Verilog
```

---

## 📐 Formato de Entrada

**Usa o formato TDLN core oficial**: [../../TDLN/specs/tdln-core-v2.0.schema.json](../../TDLN/specs/tdln-core-v2.0.schema.json)

```json
{
  "id": "matrix_mul_4x4",
  "hash": "blake3_abc123...",
  "expression": {
    "PolicyComposition": {
      "operator": "AND",
      "operands": [
        { "PolicyBit": { "name": "input_validated", "value": 1 } },
        { "PolicyBit": { "name": "output_bounded", "value": 1 } }
      ]
    }
  },
  "signature": "ed25519_def456..."
}
```

---

## 🔧 Formato de Saída

### **Metal (Apple Silicon)**

```metal
kernel void semantic_unit_matrix_mul_4x4(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    uint id [[thread_position_in_grid]]
) {
    // Validação de política (input_validated)
    if (id >= MAX_INPUT_SIZE) return;
    
    // Lógica core
    float result = input[id] * 2.0;
    
    // Validação de política (output_bounded)
    result = clamp(result, 0.0, 1.0);
    
    output[id] = result;
}
```

### **CUDA (NVIDIA)**

```cuda
__global__ void semantic_unit_matrix_mul_4x4(
    const float* input,
    float* output,
    int size
) {
    int id = blockIdx.x * blockDim.x + threadIdx.x;
    
    // Validação de política (input_validated)
    if (id >= size) return;
    
    // Lógica core
    float result = input[id] * 2.0f;
    
    // Validação de política (output_bounded)
    result = fminf(fmaxf(result, 0.0f), 1.0f);
    
    output[id] = result;
}
```

### **Verilog (FPGA/ASIC)**

```verilog
module semantic_unit_matrix_mul_4x4 (
    input wire clk,
    input wire rst,
    input wire [31:0] data_in,
    input wire valid_in,
    output reg [31:0] data_out,
    output reg valid_out
);
    // Validação de política (input_validated)
    wire input_valid = valid_in && (data_in < MAX_INPUT);
    
    // Lógica core
    wire [31:0] result = data_in * 2;
    
    // Validação de política (output_bounded)
    wire [31:0] bounded = (result > MAX_OUTPUT) ? MAX_OUTPUT : result;
    
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            data_out <= 0;
            valid_out <= 0;
        end else if (input_valid) begin
            data_out <= bounded;
            valid_out <= 1;
        end
    end
endmodule
```

---

## 📊 Metadados de Compilação

TDLN-Chip adiciona metadados específicos de hardware (NÃO modifica o `.tdln` core):

Ver: [`tdln-chip-extensions.schema.json`](./tdln-chip-extensions.schema.json)

**Exemplo**:
```json
{
  "tdln_core_version": "2.0.0",
  "compilation": {
    "backend": "metal",
    "target": "apple-m4-pro",
    "optimization_level": 3
  },
  "profiling": {
    "compilation_time_ms": 10.5,
    "execution_time_us": 470
  }
}
```

---

## 🔐 Garantias de Canonização

1. **Input Hash**: Hash Blake3 do `.tdln` original preservado
2. **Output Hash**: Hash do código compilado gerado
3. **Determinismo**: Mesma entrada `.tdln` → mesmo código de saída
4. **Verificação**: Código gerado pode ser reverificado contra hash original

---

## 🎯 Princípio

**TDLN-Chip NÃO define o formato `.tdln`** — ele COMPILA.

Formato `.tdln` definido em: [TDLN/specs/](../../TDLN/specs/)
