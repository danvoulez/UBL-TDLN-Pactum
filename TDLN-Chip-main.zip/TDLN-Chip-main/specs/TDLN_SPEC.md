# Especificação TDLN Core

**TDLN-Chip usa a especificação oficial do protocolo TDLN.**

---

## 📜 Especificação Oficial

👉 **[TDLN Core v2.0 - JSON Schema](../../TDLN/specs/tdln-core-v2.0.schema.json)**

A especificação canônica do formato `.tdln` está definida no repositório mãe:
- **Repositório**: [TDLN](../../TDLN/)
- **Schema JSON**: `specs/tdln-core-v2.0.schema.json`
- **Documentação**: `docs/TDLN_FORMAT.md`

---

## 🔧 Extensões Específicas de TDLN-Chip

TDLN-Chip **NÃO modifica** o formato core `.tdln`.

TDLN-Chip **ADICIONA**:
- Metadados de compilação (backend, otimizações)
- Configurações de hardware (GPU model, FPGA target)
- Trace de execução (performance profiling)

Ver: [`tdln-chip-extensions.schema.json`](./tdln-chip-extensions.schema.json)

---

## 📐 Formato Core (Referência)

```json
{
  "id": "example",
  "hash": "blake3_...",
  "expression": {
    "PolicyBit": { "name": "validated", "value": 1 }
  },
  "signature": "ed25519_..."
}
```

**Spec completa**: [TDLN/specs/tdln-core-v2.0.schema.json](../../TDLN/specs/tdln-core-v2.0.schema.json)

---

## 🎯 Princípio

**TDLN-Chip CONSOME o formato TDLN.**  
**TDLN-Chip NÃO define o formato TDLN.**

A definição oficial está em [TDLN](../../TDLN/).
