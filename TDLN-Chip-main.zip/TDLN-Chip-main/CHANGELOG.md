# Changelog

All notable changes to TDLN Pure will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [2.0.0] - 2025-12-16

### 🎉 Initial Release - Fractal Format

This is the first stable release of TDLN Pure with the definitive fractal format.

### Added

#### Core Specification
- **JSON Schema** (`specs/tdln-core-v2.0.schema.json`): Complete canonical schema for `.tdln` format
- **SemanticUnit** fractal structure: Self-describing nodes with `node_type`, `id`, `hash`
- **PolicyBit**: Atomic policy evaluation unit
- **PolicyComposition**: Aggregation of multiple policies (AND/OR/CUSTOM)
- **Expression System**: Recursive expression tree (BinaryExpression, UnaryExpression, FunctionCall, etc.)
- **TranslationProof**: Optional auditability with translation steps and provenance
- **MaterializationHints**: Optional compiler optimization hints

#### Documentation
- **TDLN_FORMAT.md**: Complete specification of the `.tdln` format (581 lines)
- **README.md**: Project overview and quick start guide
- **README.examples.md**: Guide to included examples

#### Examples
- **premium-user-access.tdln.json**: Complete example with proof (458 lines)
- **chip-minimal.tdln.json**: Minimal example for chip compilation (87 lines)
- **pipeline.example.yaml**: Reference pipeline configuration
- **policy.none.v1.example.yaml**: Neutral sandbox policy
- **pack.manifest.example.json**: Pack activation control
- **trace.manifest.example.ndjson**: Trace manifest example

#### Grammars
- **generic.in.v1.example.yaml**: Input grammar example
- **generic.out.v1.example.yaml**: Output grammar example

#### Integrations
- **json-atomic**: Documentation for JSON atomic integration

#### Infrastructure
- **LICENSE**: MIT License
- **.gitignore**: Ignore patterns for development
- **CONTRIBUTING.md**: Contribution guidelines
- **CODE_OF_CONDUCT.md**: Community standards
- **SECURITY.md**: Security policy

### Design Decisions

#### Fractal Structure
- Chose **SemanticUnit as root** (not wrapper/envelope) to preserve TDLN's inherent fractal nature
- Each level self-describing: maintains recursion at all scales
- Direct reflection of TDLN Core invention

#### Proof System
- **Optional proof field**: Separates auditability (Pure) from compilation (Chip)
- Blake3 hashing: Fast, cryptographically secure
- Ed25519 signatures: Standard for provenance
- NDJSON traces: Streaming-friendly audit logs

#### Backward Compatibility
- Version field (`tdln_spec_version`) for future evolution
- Optional fields for gradual adoption
- Clear separation: canonical (.tdln.json) vs examples (.example.*)

---

## [Unreleased]

### Planned

- CI/CD automation (GitHub Actions)
- Additional language examples (Python, Rust, JavaScript)
- Performance benchmarks for validation
- Extended grammar library
- Policy pack repository

---

## Version History

- **v2.0.0** (2025-12-16): Initial stable release with fractal format
- **v1.x**: Pre-release development (not publicly released)

---

## Upgrade Guides

### Migrating to v2.0

If you have pre-release TDLN files:

1. **Add version field**: `"tdln_spec_version": "2.0.0"`
2. **Update node structure**: Ensure all nodes have `node_type`, `id`, `hash`
3. **Rename fields**: 
   - `semantic_op` → part of `policies` structure
   - Legacy wrappers → flatten to SemanticUnit
4. **Validate**: Use `jsonschema` to validate against new schema

See [TDLN_FORMAT.md](./docs/TDLN_FORMAT.md) for complete specification.

---

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md) for how to contribute to TDLN Pure.

---

[2.0.0]: https://github.com/your-org/tdln-pure/releases/tag/v2.0.0
[Unreleased]: https://github.com/your-org/tdln-pure/compare/v2.0.0...HEAD
