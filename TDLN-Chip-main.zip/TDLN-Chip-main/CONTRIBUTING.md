# Contributing to TDLN-Chip

**Help us push the boundaries of "Chip as Code" — where LLMs create silicon via text.**

Thank you for your interest in TDLN-Chip! This isn't just a compiler — it's proof that hardware design can be as flexible as software development.

---

## 🧭 The Discovery Timeline

### What We've Proven

**December 15, 2024: The Paradigm Shift**
- Benchmark showed "CPU faster than GPU"
- Community insight: *"You're comparing apples to oranges"*
- **Revelation**: TDLN isn't a CPU competitor — it's a *chip architecture*

**December 15-16, 2024: Validation Sprint**
- M4 Pro benchmarks: 268 GFLOPS, 0.47ms latency
- Metal vs CUDA comparison: H100 is 5.9x faster, but M4 Pro is 21x cheaper
- NVIDIA 4060 comparison: Similar performance to M4 Pro
- **Conclusion**: Cost-efficiency matters more than raw speed for many use cases

**The Three Sacred Principles:**
1. **Determinism**: Same .tdln → same hardware, always
2. **Auditability**: Verilog/Metal code is text, readable, verifiable
3. **Cost**: $0 to prototype infinite variations before fabrication

### What We're Still Exploring

**Unexplored Backends:**
- **WebGPU**: Browser-native chip execution
- **ROCm**: AMD GPU support
- **TPU**: Google tensor processors
- **OpenCL**: Universal compute standard
- **Vulkan Compute**: Cross-platform GPU
- **SYCL**: Khronos parallel programming
- **FPGA Vendors**: Xilinx, Intel, Lattice
- **Future Silicon**: Photonics, memristors, quantum

**Untested Hardware:**
- Apple M4 Max (40-core GPU)
- NVIDIA H100 (physical testing)
- AMD MI300X (competitor to H100)
- Intel Arc GPUs
- Mobile GPUs (Adreno, Mali)
- Custom ASICs

**Optimization Frontiers:**
- **Kernel Fusion**: Combine multiple TDLN units into single kernel
- **Multi-GPU**: Automatic sharding across devices
- **Mixed Precision**: FP16/BF16 for efficiency
- **Quantization**: INT8/INT4 for edge devices
- **Sparsity**: Exploit zero patterns in policies
- **Tiling Strategies**: Optimal cache usage

**Tooling Gaps:**
- Performance profilers (where are bottlenecks?)
- Visual circuit designers (drag-and-drop policy composition)
- Automated benchmarking suite
- Cost estimators (ASIC tape-out pricing)
- Power analyzers (energy consumption predictions)

## 🚀 What You Can Discover

### 1. New Hardware Targets
**We've proven:** Metal (Apple), CUDA (NVIDIA), Verilog (FPGA/ASIC)  
**What about:**
- Your favorite GPU?
- Specialized accelerators?
- Embedded processors?
- Future substrates?

### 2. Compilation Strategies
**We use:** Direct AST → shader translation  
**What about:**
- IR optimizations (LLVM-style)?
- Polyhedral compilation?
- Auto-vectorization?
- Loop transformations?

### 3. Performance Optimization
**We found:** Level 2 is sweet spot, linear scaling  
**What about:**
- Better memory access patterns?
- Occupancy optimizers?
- Register allocation strategies?
- Warp/wavefront utilization?

### 4. Real-World Validation
**We measured:** Synthetic benchmarks (MatMul, Conv2D)  
**What about:**
- Production workloads?
- Edge case policies?
- Stress testing?
- Long-running stability?

### 5. Developer Experience
**We have:** Rust API, JSON specs  
**What's missing:**
- High-level DSL for chip design?
- Error messages that explain *why* compilation failed?
- Interactive notebooks (Jupyter)?
- Cloud compilation services?

---

## 🤝 Code of Conduct

This project adheres to the [Contributor Covenant Code of Conduct](https://github.com/logline-foundation/TDLN/blob/main/CODE_OF_CONDUCT.md). By participating, you are expected to uphold this code.

---

## 🎯 How Can I Contribute?

### Reporting Issues

- **Security vulnerabilities**: See [SECURITY.md](https://github.com/logline-foundation/TDLN/blob/main/SECURITY.md)
- **Bugs**: Open an issue with:
  - Clear description of the problem
  - Steps to reproduce
  - Expected vs actual behavior
  - Hardware details (GPU model, OS, driver version)
  - TDLN-Chip version
  
- **Feature requests**: Open an issue describing:
  - The use case
  - Why it's valuable for Chip as Code
  - Proposed solution (if any)
  - Performance implications

### Improving Documentation

Documentation improvements are always welcome:
- Fix typos, clarify explanations
- Add examples of chip compilation
- Improve tutorials (especially for new backends)
- Document performance characteristics
- Translate documentation

### Proposing New Backends

Want to add support for new hardware?
1. Open an issue proposing the backend
2. Explain the target hardware and why it matters
3. Provide performance expectations
4. Reference vendor documentation for the platform

---

## 🔧 Development Process

### Setting Up

```bash
# Clone the repository
git clone https://github.com/logline-foundation/TDLN-Chip.git
cd TDLN-Chip

# Build
cargo build --release

# Run tests
cargo test --workspace

# Run benchmarks
cd tdln_runtime
cargo bench --bench matrix_ops
```

### Testing Changes

When modifying backends or adding optimizations:

```bash
# Run all tests
cargo test --workspace

# Run specific backend tests
cargo test -p tdln_backends

# Benchmark performance
cargo bench

# Check without compiling
cargo check --workspace
```

---

## 🎨 Backend Implementation Guide

### Adding a New Backend

1. Create file in `tdln_backends/src/your_backend.rs`
2. Implement `CodeGenerator` trait:

```rust
pub trait CodeGenerator {
    fn generate(&self, unit: &SemanticUnit) -> Result<String>;
}

pub struct YourBackend;

impl CodeGenerator for YourBackend {
    fn generate(&self, unit: &SemanticUnit) -> Result<String> {
        // Your compilation logic
        Ok(generated_code)
    }
}
```

3. Add comprehensive tests
4. Document performance characteristics
5. Add examples to `examples/`

### Backend Requirements

- ✅ **Deterministic compilation**: Same .tdln → same output
- ✅ **Full policy support**: Implement ALL TDLN policies
- ✅ **Verifiable output**: Code is human-readable
- ✅ **Performance metrics**: Document latency, throughput, energy
- ✅ **Regression tests**: Ensure changes don't break existing behavior

---

## 📐 Optimization Contributions

### Performance Improvements

When submitting optimizations:

1. **Benchmark before/after** with `cargo bench`
2. **Document trade-offs** (speed vs memory, etc.)
3. **Test on real hardware** when possible
4. **Profile bottlenecks** (use `perf`, `Instruments`, `nsys`)
5. **Explain the technique** in PR description

### Acceptable Optimizations

- ✅ Kernel fusion strategies
- ✅ Memory access improvements
- ✅ Compiler directives (unrolling, vectorization)
- ✅ Algorithm selection (based on workload size)
- ✅ Platform-specific tuning

### Not Acceptable

- ❌ Breaks determinism
- ❌ Sacrifices auditability
- ❌ Platform-specific hacks without fallbacks
- ❌ Unverifiable "magic numbers"

---

## 🔄 Pull Request Process

### Before Submitting

1. **Create an issue** to discuss significant changes
2. **Update documentation** to reflect your changes
3. **Add tests** demonstrating correctness
4. **Benchmark** if performance-related
5. **Update CHANGELOG.md** with your changes
6. **Ensure all tests pass** (`cargo test --workspace`)

### PR Guidelines

- **Title**: Clear, descriptive (e.g., "Add ROCm backend support")
- **Description**: 
  - What changed and why
  - Performance impact (if any)
  - Hardware tested on
  - Link to related issues
  - Breaking changes (if any)
- **Commits**: 
  - Atomic, focused commits
  - Clear commit messages
  - Sign commits (`git commit -s`)

### Review Process

1. Maintainers will review your PR
2. CI will run tests and benchmarks
3. Address feedback and update as needed
4. Once approved, maintainers will merge

---

## 📝 Style Guidelines

### Rust Code

```rust
// Use descriptive names
fn generate_metal_kernel(unit: &SemanticUnit) -> Result<String> {
    // Clear logic flow
    let header = generate_header()?;
    let kernel = generate_kernel_body(unit)?;
    let footer = generate_footer()?;
    
    Ok(format!("{}\n{}\n{}", header, kernel, footer))
}

// Document public APIs
/// Generates Metal shader code from a TDLN SemanticUnit.
/// 
/// # Arguments
/// * `unit` - The semantic unit to compile
/// 
/// # Returns
/// Metal shader source code as a String
///
/// # Errors
/// Returns error if unit contains unsupported policies
pub fn generate(&self, unit: &SemanticUnit) -> Result<String>
```

### Markdown Documentation

- Use clear headings (`##`, `###`)
- Include code examples
- Keep lines under 120 characters
- Use tables for performance comparisons
- Link to related docs

### Example Files

- Include realistic chip compilation examples
- Document expected output (Metal/CUDA/Verilog)
- Explain design decisions in comments
- Show performance characteristics

---

## 🏷️ Commit Message Format

```
<type>(<scope>): <subject>

<body>

<footer>
```

**Types**:
- `feat`: New backend or feature
- `perf`: Performance improvement
- `fix`: Bug fix
- `docs`: Documentation changes
- `test`: Test additions or fixes
- `refactor`: Code restructuring
- `chore`: Maintenance tasks

**Example**:
```
feat(backends): Add ROCm backend for AMD GPUs

Implement CodeGenerator for AMD ROCm platform. Supports
gfx900-gfx1100 architectures. Benchmarked on MI100.

Performance: 180 GFLOPS on MI100 (vs 268 on M4 Pro).

Closes #67
```

---

## 🚀 Release Process

(For maintainers)

1. Update `CHANGELOG.md` with version and date
2. Update version in `Cargo.toml` files
3. Run full test suite and benchmarks
4. Tag release: `git tag -a v0.3.0 -m "Release v0.3.0"`
5. Push tag: `git push origin v0.3.0`
6. Create GitHub release with changelog
7. Publish to crates.io (if applicable)

---

## ❓ Questions?

- Open a [discussion](https://github.com/logline-foundation/TDLN-Chip/discussions)
- Check existing issues
- Read the [Integration Guide](./docs/INTEGRATION_GUIDE.md)
- See [benchmark results](./BENCHMARK_RESULTS.md)

---

## 🙏 Thank You!

Your contributions help push the boundaries of "Chip as Code". Together, we're making hardware design as flexible as software development.

Every backend you add, every optimization you discover, every bug you fix — these all expand what's possible.

**The future of computing is written in text files. Let's build it together.**

---

**License**: By contributing, you agree that your contributions will be licensed under the MIT License.
