# ✅ Canonização e Especificações - TDLN-Chip

**Data**: 16 de dezembro de 2025  
**Status**: ✅ Implementado com boas práticas

---

## 🎯 Problema Resolvido

**Questão**: "Deve haver em TDLN-Chip canonização do formato do chip e se necessário conter a especificação do TDLN individual?"

**Solução**: TDLN-Chip agora tem:
1. ✅ **Link para especificação oficial** (não duplicação)
2. ✅ **Canonização de formato de chip** (entrada → saída)
3. ✅ **Extensões específicas de hardware** (metadados)

---

## 📁 Arquivos Criados

### 1. [`specs/TDLN_SPEC.md`](./specs/TDLN_SPEC.md)
**Melhor prática**: Link para spec oficial, não duplicação.

```markdown
# Especificação TDLN Core

**TDLN-Chip usa a especificação oficial do protocolo TDLN.**

👉 **[TDLN Core v2.0 - JSON Schema](../../TDLN/specs/tdln-core-v2.0.schema.json)**
```

**Por quê?**
- ✅ Single source of truth (TDLN é o repo mãe)
- ✅ Sem dessincronia entre repos
- ✅ Clarifica que TDLN-Chip **IMPORTA** o protocolo

---

### 2. [`specs/CHIP_FORMAT.md`](./specs/CHIP_FORMAT.md)
**Canonização completa**: `.tdln` → Metal/CUDA/Verilog

**Conteúdo**:
- Formato de entrada (`SemanticUnit`)
- Formato de saída (código Metal, CUDA, Verilog)
- Garantias (determinismo, verificabilidade, conformidade)

**Exemplo**:
```json
// Entrada
{"id": "matrix_mul", "expression": {...}}

// ↓ TDLN-Chip compila ↓

// Saída (Metal)
kernel void semantic_unit_matrix_mul(...) { ... }
```

---

### 3. [`specs/tdln-chip-extensions.schema.json`](./specs/tdln-chip-extensions.schema.json)
**JSON Schema para extensões de hardware**

**Metadados que TDLN-Chip adiciona** (não modifica o core):
```json
{
  "tdln_core_version": "2.0.0",
  "compilation": {
    "backend": "metal",
    "target": "apple-m4-pro",
    "optimization_level": 3
  },
  "hardware_config": {
    "gpu_model": "M4 Pro",
    "memory_budget_mb": 4096
  },
  "profiling": {
    "compilation_time_ms": 10.5,
    "execution_time_us": 470
  }
}
```

**Por quê?**
- ✅ Separa protocolo core (TDLN) de extensões (TDLN-Chip)
- ✅ Permite profiling sem modificar `.tdln`
- ✅ Documentado via JSON Schema (validável)

---

### 4. [`specs/README.md`](./specs/README.md)
**Índice das especificações**

Explica:
- O que cada arquivo faz
- Princípio de separação (core vs extensões)
- Referências cruzadas

---

## 🎯 Boas Práticas Aplicadas

### ✅ **Single Source of Truth**
```
TDLN/specs/tdln-core-v2.0.schema.json  ← Spec oficial (autoridade)
         ↑
         │ (referencia)
         │
TDLN-Chip/specs/TDLN_SPEC.md           ← Link, não cópia
```

### ✅ **Separação de Concerns**
```
TDLN         → Define protocolo (SemanticUnit, PolicyBit)
TDLN-Chip    → Compila protocolo (Metal, CUDA, Verilog)
              + Adiciona metadados (profiling, hardware config)
```

### ✅ **Versionamento Explícito**
```json
{
  "tdln_core_version": "2.0.0",  // Qual versão do core usamos
  "compilation": { ... }          // Extensões específicas
}
```

### ✅ **Documentação em Camadas**
1. `TDLN_SPEC.md` — Link para autoridade
2. `CHIP_FORMAT.md` — Canonização de compilação
3. `tdln-chip-extensions.schema.json` — Schema validável
4. `README.md` — Índice e princípios

---

## 📊 Comparação com Outras Práticas

| Abordagem | TDLN-Chip | Alternativas |
|-----------|-----------|--------------|
| **Duplicar spec** | ❌ Não duplica | Muitos projetos duplicam (ruim) |
| **Link para oficial** | ✅ Sim | Raro, mas melhor prática |
| **Extensões separadas** | ✅ Schema próprio | Comum misturar (ruim) |
| **Versionamento** | ✅ Explícito | Muitos implícito (ruim) |

---

## 🔄 Atualização do `CANONIZACAO_TDLN.md`

O arquivo [`CANONIZACAO_TDLN.md`](./CANONIZACAO_TDLN.md) foi atualizado:

**Antes**: Descrevia sistema ótico abstrato (histórico)  
**Depois**: 
- ✅ Referencia spec oficial TDLN
- ✅ Canonização de compilação para hardware
- ✅ Extensões específicas de chip
- ✅ Conteúdo histórico preservado em `<details>`

---

## 🚀 Como Usar

### 1. Consultar Spec Oficial
```bash
# Ver spec core TDLN
cat ../TDLN/specs/tdln-core-v2.0.schema.json
```

### 2. Consultar Formato de Chip
```bash
# Ver canonização de compilação
cat specs/CHIP_FORMAT.md
```

### 3. Validar Extensões
```bash
# Validar metadados de chip contra schema
cat metadata.json | jq . # validate against tdln-chip-extensions.schema.json
```

---

## 📝 Checklist de Melhores Práticas

- [x] **Não duplicar especificação** — Link para TDLN oficial ✅
- [x] **Separar core de extensões** — Schema próprio para metadados ✅
- [x] **Documentar canonização** — CHIP_FORMAT.md completo ✅
- [x] **Versionamento explícito** — `tdln_core_version` em extensões ✅
- [x] **Índice de specs** — README.md em specs/ ✅
- [x] **Preservar histórico** — Conteúdo ótico em `<details>` ✅

---

## 🎯 Resultado Final

```
TDLN-Chip/specs/
├── README.md                              ← Índice
├── TDLN_SPEC.md                          ← Link para oficial
├── CHIP_FORMAT.md                        ← Canonização de compilação
└── tdln-chip-extensions.schema.json      ← Extensões de HW
```

**Princípios alcançados**:
1. **TDLN-Chip NÃO define o protocolo** — apenas referencia
2. **TDLN-Chip compila o protocolo** — canonização clara
3. **TDLN-Chip adiciona metadados** — extensões separadas
4. **Single source of truth** — TDLN é autoridade

---

**✅ Boas práticas de especificação implementadas com sucesso!**
