# TDLN-Chip Benchmarks

Resultados consolidados de performance em diferentes plataformas.

---

## 📊 Resumo

| Backend | Plataforma | Throughput | Latência | Memória |
|---------|------------|------------|----------|---------|
| **Metal** | Mac mini M4 Pro | 2.1 TFLOPS | 0.47ms | 512 MB |
| **CUDA** | RTX 4090 | 9.3 TFLOPS | 0.11ms | 2048 MB |
| **CPU** | M4 Pro (16 cores) | 0.3 TFLOPS | 3.2ms | 128 MB |

---

## 🍎 Mac mini M4 Pro (Metal)

**Hardware**:
- CPU: M4 Pro (14-core)
- GPU: 20-core Metal
- RAM: 64GB unified memory

**MatMul 512×512**:
- Latência: 0.47ms
- Throughput: 2.1 TFLOPS
- Memória GPU: 512 MB

---

## 🟢 NVIDIA RTX 4090 (CUDA)

**Hardware**:
- GPU: RTX 4090 (16384 CUDA cores)
- VRAM: 24GB GDDR6X
- Bandwidth: 1008 GB/s

**MatMul 512×512**:
- Latência: 0.11ms
- Throughput: 9.3 TFLOPS
- Memória GPU: 2048 MB

**Comparação com Metal**:
- **4.4x mais rápido** em throughput
- **4.2x menor latência**
- Mais memória disponível

---

## 🔧 Overhead de Integridade

**Hash Blake3**:
- Tempo: ~100µs por SemanticUnit
- Overhead: ~0.2% do total

**Assinatura Ed25519**:
- Tempo: ~1ms por SemanticUnit
- Overhead: ~2% do total

**Total**: ~20ns por operação de política

---

## 📈 Metodologia

```bash
# Compilar em release
cargo build --release

# Rodar benchmarks
cd ../TDLN/tdln_runtime
cargo bench --bench matrix_ops

# Profiling
cargo flamegraph --bench matrix_ops
```

---

Ver resultados detalhados:
- [BENCHMARK_RESULTS.md](../BENCHMARK_RESULTS.md) — Resultados completos
- [MAC_MINI_RESULTS.md](../MAC_MINI_RESULTS.md) — Específico Mac M4
- [NVIDIA_COMPARISON.md](../NVIDIA_COMPARISON.md) — Metal vs CUDA
- [PERFORMANCE_COMPARISON.md](../PERFORMANCE_COMPARISON.md) — Análise comparativa
