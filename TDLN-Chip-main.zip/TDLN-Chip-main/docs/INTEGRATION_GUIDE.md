# Usando TDLN-Chip: Guia de Specs e Integração

**TDLN-Chip** compila políticas TDLN para código de hardware executável.

---

## 📐 Arquitetura de Specs

### **Duas Camadas de Especificação**

```
┌─────────────────────────────────────────┐
│ TDLN Core Spec                          │  ← Repositório TDLN
│ (SemanticUnit, PolicyBit, Expression)   │
│ https://github.com/logline-foundation/TDLN
└─────────────────────────────────────────┘
                 ↓ IMPORTA
┌─────────────────────────────────────────┐
│ TDLN-Chip Extensions                    │  ← Este repositório
│ (Metadados de compilação, profiling)    │
│ https://github.com/logline-foundation/TDLN-Chip
└─────────────────────────────────────────┘
                 ↓ COMPILA
┌─────────────────────────────────────────┐
│ Hardware Code                            │
│ (Metal, CUDA, Verilog)                  │
└─────────────────────────────────────────┘
```

---

## 📋 Passo 1: Entender o Formato TDLN Core

**Especificação oficial**: [TDLN/specs/tdln-core-v2.0.schema.json](https://github.com/logline-foundation/TDLN/blob/main/specs/tdln-core-v2.0.schema.json)

**Documentação**: [TDLN/docs/TDLN_FORMAT.md](https://github.com/logline-foundation/TDLN/blob/main/docs/TDLN_FORMAT.md)

### Exemplo Mínimo (`.tdln`)

```json
{
  "id": "matrix_mul_4x4",
  "hash": "blake3_abc123...",
  "expression": {
    "PolicyBit": {
      "name": "validated",
      "value": 1
    }
  },
  "signature": null
}
```

**Campos obrigatórios** (definidos em TDLN):
- `id`: Identificador único
- `hash`: Hash Blake3 da expressão
- `expression`: PolicyBit ou PolicyComposition
- `signature`: Assinatura Ed25519 (opcional)

---

## 🔧 Passo 2: Adicionar Extensões de Chip

**Especificação**: [specs/tdln-chip-extensions.schema.json](./specs/tdln-chip-extensions.schema.json)

### Metadados de Compilação

```json
{
  "tdln_core_version": "2.0.0",
  "compilation": {
    "backend": "metal",
    "target": "apple-m4-pro",
    "optimization_level": 3,
    "parallel_units": 16
  },
  "hardware_config": {
    "gpu_model": "M4 Pro",
    "memory_budget_mb": 4096,
    "clock_mhz": 1400
  },
  "profiling": {
    "compilation_time_ms": 10.5,
    "execution_time_us": 470,
    "throughput_ops_per_sec": 2100000000
  }
}
```

**Campos específicos de TDLN-Chip**:
- `backend`: "metal" | "cuda" | "verilog"
- `target`: Plataforma específica
- `optimization_level`: 0-3
- `profiling`: Métricas de performance

---

## 🚀 Passo 3: Compilar para Hardware

### Via Rust (Programático)

```rust
use tdln_core::SemanticUnit;
use tdln_backends::metal::MetalCompiler;

// 1. Carregar arquivo .tdln (formato TDLN core)
let tdln_json = std::fs::read_to_string("policy.tdln.json")?;
let unit: SemanticUnit = serde_json::from_str(&tdln_json)?;

// 2. Criar compilador (específico TDLN-Chip)
let compiler = MetalCompiler::new();

// 3. Compilar para Metal
let metal_code = compiler.compile(&unit);

// 4. Salvar código gerado
std::fs::write("output.metal", metal_code)?;
```

### Via CLI (Planejado)

```bash
# Compilar .tdln para Metal
tdln-chip compile --backend metal --input policy.tdln.json --output shader.metal

# Compilar para CUDA
tdln-chip compile --backend cuda --input policy.tdln.json --output kernel.cu

# Compilar para Verilog (FPGA)
tdln-chip compile --backend verilog --input policy.tdln.json --output module.v
```

---

## 📊 Passo 4: Validar Conformidade

### Validar Formato TDLN Core

```bash
# Usar JSON Schema do TDLN
jsonschema -i policy.tdln.json \
  ../TDLN/specs/tdln-core-v2.0.schema.json
```

### Validar Extensões de Chip

```bash
# Usar JSON Schema do TDLN-Chip
jsonschema -i metadata.json \
  ./specs/tdln-chip-extensions.schema.json
```

---

## 🎯 Fluxo Completo

```
1. Criar arquivo .tdln.json
   ├─ Seguir: TDLN/specs/tdln-core-v2.0.schema.json
   └─ Documentação: TDLN/docs/TDLN_FORMAT.md

2. Adicionar metadados de compilação (opcional)
   ├─ Seguir: TDLN-Chip/specs/tdln-chip-extensions.schema.json
   └─ Documentação: TDLN-Chip/specs/CHIP_FORMAT.md

3. Compilar com TDLN-Chip
   ├─ Backend: Metal / CUDA / Verilog
   ├─ Código Rust: tdln_backends
   └─ Output: Código de hardware executável

4. Executar e medir
   ├─ Profiling automático
   └─ Métricas: latência, throughput, memória
```

---

## 🔗 Referências Cruzadas

### Specs TDLN (Core)
- **JSON Schema**: [TDLN/specs/tdln-core-v2.0.schema.json](https://github.com/logline-foundation/TDLN/blob/main/specs/tdln-core-v2.0.schema.json)
- **Formato**: [TDLN/docs/TDLN_FORMAT.md](https://github.com/logline-foundation/TDLN/blob/main/docs/TDLN_FORMAT.md)
- **Arquitetura**: [TDLN/docs/ARCHITECTURE.md](https://github.com/logline-foundation/TDLN/blob/main/docs/ARCHITECTURE.md)

### Specs TDLN-Chip (Extensões)
- **Extensões**: [specs/tdln-chip-extensions.schema.json](./specs/tdln-chip-extensions.schema.json)
- **Formato de Chip**: [specs/CHIP_FORMAT.md](./specs/CHIP_FORMAT.md)
- **Link para TDLN**: [specs/TDLN_SPEC.md](./specs/TDLN_SPEC.md)

---

## 💡 Boas Práticas

### ✅ Fazer
- Validar `.tdln.json` contra schema TDLN antes de compilar
- Usar `tdln_core_version` para rastrear compatibilidade
- Gerar hash Blake3 determinístico
- Adicionar profiling para benchmarks

### ❌ Evitar
- Modificar formato `.tdln` core (use extensões)
- Quebrar determinismo (mesma entrada → mesma saída)
- Otimizações que violem políticas declaradas

---

## 🧪 Testar sua Implementação

```bash
# Compilar workspace
cargo build --release

# Rodar testes
cargo test --workspace

# Benchmark específico
cd ../TDLN/tdln_runtime
cargo bench --bench matrix_ops
```

---

## 🤝 Contribuir com a Comunidade

**TDLN-Chip é focado em chips as code, mas a comunidade pode**:
- Criar novos backends (WebGPU, TPU, etc.)
- Otimizar compiladores existentes
- Adicionar profiling avançado
- Melhorar geração de código

**Importante**: Sempre preserve compatibilidade com TDLN core!

Ver: [CONTRIBUTING.md](./CONTRIBUTING.md)

---

**Use TDLN-Chip para transformar políticas em hardware real! 🔩⚡**
