use tdln_core::{SemanticUnit, PolicyBit, Expression, Value, UnitType, SemanticOp};

#[test]
fn test_policy_bit_creation() {
    let bit = PolicyBit::new("test_policy", "A test policy");
    
    assert_eq!(bit.name, "test_policy");
    assert_eq!(bit.description, "A test policy");
}

#[test]
fn test_semantic_unit_creation() {
    let unit = SemanticUnit::new("test_unit", "Test semantic unit");
    
    assert_eq!(unit.name, "test_unit");
    assert_eq!(unit.description, "Test semantic unit");
}

#[test]
fn test_semantic_unit_with_type() {
    let unit = SemanticUnit::new("matrix_proc", "Matrix processor")
        .with_type(UnitType::MatrixProcessor);
    
    assert!(matches!(unit.unit_type, UnitType::MatrixProcessor));
}

#[test]
fn test_add_policy_to_unit() {
    let mut unit = SemanticUnit::new("test", "Test");
    let policy = PolicyBit::new("validated", "Input must be validated")
        .with_condition(Expression::Literal(Value::Boolean(true)));
    
    unit.add_policy(policy);
    
    assert_eq!(unit.policies.len(), 1);
    assert_eq!(unit.policies[0].name, "validated");
}

#[test]
fn test_binary_expression() {
    let left = Expression::Literal(Value::Integer(5));
    let right = Expression::Literal(Value::Integer(10));
    
    let expr = Expression::BinaryOp {
        op: SemanticOp::Add,
        left: Box::new(left),
        right: Box::new(right),
    };
    
    if let Expression::BinaryOp { op, .. } = expr {
        assert!(matches!(op, SemanticOp::Add));
    } else {
        panic!("Expected BinaryOp");
    }
}

#[test]
fn test_matrix_expression() {
    let matrix = Expression::Matrix {
        rows: 2,
        cols: 2,
        data: vec![
            Expression::Literal(Value::Float(1.0)),
            Expression::Literal(Value::Float(2.0)),
            Expression::Literal(Value::Float(3.0)),
            Expression::Literal(Value::Float(4.0)),
        ],
    };
    
    if let Expression::Matrix { rows, cols, data } = matrix {
        assert_eq!(rows, 2);
        assert_eq!(cols, 2);
        assert_eq!(data.len(), 4);
    } else {
        panic!("Expected Matrix");
    }
}

#[test]
fn test_semantic_unit_serialization() {
    let unit = SemanticUnit::new("serialization_test", "Test serialization");
    
    let json = serde_json::to_string(&unit).expect("Serialization failed");
    let deserialized: SemanticUnit = serde_json::from_str(&json).expect("Deserialization failed");
    
    assert_eq!(unit.name, deserialized.name);
    assert_eq!(unit.description, deserialized.description);
}

#[test]
fn test_calculate_hash() {
    let mut unit = SemanticUnit::new("hash_test", "Test hashing");
    unit.calculate_hash();
    
    assert!(unit.source_hash.is_some());
    let hash = unit.source_hash.unwrap();
    assert!(!hash.is_empty());
}

#[test]
fn test_hash_determinism() {
    let mut unit1 = SemanticUnit::new("deterministic", "Test");
    let mut unit2 = SemanticUnit::new("deterministic", "Test");
    
    unit1.calculate_hash();
    unit2.calculate_hash();
    
    assert_eq!(unit1.source_hash, unit2.source_hash);
}
