//! TDLN Core v2 - Semantic Computing Framework
//! 
//! Não é só lógica booleana. É uma ARQUITETURA MODULAR para compilar
//! QUALQUER computação semântica em hardware.

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::HashMap;

// ============================================================================
// SEMANTIC OPERATORS - O núcleo modular
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum SemanticOp {
    // Lógica booleana (o que temos)
    And,
    Or,
    Not,
    Xor,
    
    // Comparações
    Eq,
    Neq,
    Gt,
    Lt,
    Gte,
    Lte,
    
    // Aritmética (NOVO)
    Add,
    Sub,
    Mul,
    Div,
    Mod,
    Pow,
    
    // Operações vetoriais (NOVO - para ML)
    DotProduct,
    CrossProduct,
    VectorAdd,
    VectorMul,
    
    // Matrix operations (NOVO - competir com NVIDIA)
    MatMul,
    MatAdd,
    Transpose,
    Convolution2D,
    
    // Agregações (NOVO)
    Sum,
    Mean,
    Max,
    Min,
    Reduce(Box<SemanticOp>),
    
    // Transformações (NOVO)
    Map(Box<SemanticOp>),
    Filter(Box<Expression>),
    
    // Funções especiais
    Custom(String),
}

// ============================================================================
// EXPRESSION - Agora suporta TUDO
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum Expression {
    // Primitivos
    Literal(Value),
    Variable(String),
    ContextRef { path: Vec<String> },
    
    // Operações binárias MODULARES
    BinaryOp {
        op: SemanticOp,
        left: Box<Expression>,
        right: Box<Expression>,
    },
    
    // Operações unárias
    UnaryOp {
        op: SemanticOp,
        arg: Box<Expression>,
    },
    
    // Arrays e vetores (NOVO)
    Array(Vec<Expression>),
    ArrayAccess {
        array: Box<Expression>,
        index: Box<Expression>,
    },
    
    // Matrizes (NOVO - para competir com NVIDIA)
    Matrix {
        rows: usize,
        cols: usize,
        data: Vec<Expression>,
    },
    
    // Chamadas de função (existente mas expandido)
    FunctionCall {
        function: String,
        arguments: Vec<Expression>,
    },
    
    // Pipeline de operações (NOVO)
    Pipeline(Vec<Expression>),
    
    // Condicional
    Conditional {
        test: Box<Expression>,
        consequent: Box<Expression>,
        alternate: Box<Expression>,
    },
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum Value {
    Boolean(bool),
    Integer(i64),
    Float(f64),
    String(String),
    Array(Vec<Value>),
    Matrix { rows: usize, cols: usize, data: Vec<f64> },
    Null,
}

// ============================================================================
// SEMANTIC UNIT - Agora compila QUALQUER coisa
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SemanticUnit {
    pub name: String,
    pub description: String,
    pub unit_type: UnitType,  // NOVO
    pub policies: Vec<PolicyBit>,
    pub operators: Vec<OperatorDef>,  // NOVO
    pub source_hash: Option<String>,
    pub metadata: HashMap<String, String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum UnitType {
    // Tipos originais
    PolicyValidator,
    AccessControl,
    
    // NOVOS - competir com NVIDIA
    NeuralNetworkLayer,      // Compila camada de NN em hardware
    MatrixProcessor,         // Multiplicação de matrizes dedicada
    ConvolutionEngine,       // CNN em silício
    TransformerBlock,        // Attention em hardware
    
    // Outros
    DataTransformer,
    Aggregator,
    CustomLogic,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorDef {
    pub name: String,
    pub op_type: SemanticOp,
    pub inputs: Vec<String>,
    pub output: String,
    pub expression: Expression,
}

impl SemanticUnit {
    pub fn new(name: &str, description: &str) -> Self {
        Self {
            name: name.to_string(),
            description: description.to_string(),
            unit_type: UnitType::CustomLogic,
            policies: Vec::new(),
            operators: Vec::new(),
            source_hash: None,
            metadata: HashMap::new(),
        }
    }
    
    pub fn with_type(mut self, unit_type: UnitType) -> Self {
        self.unit_type = unit_type;
        self
    }
    
    pub fn add_operator(&mut self, operator: OperatorDef) {
        self.operators.push(operator);
    }
    
    pub fn add_policy(&mut self, policy: PolicyBit) {
        self.policies.push(policy);
    }
    
    // Calcula hash canônico
    pub fn calculate_hash(&mut self) {
        let mut hasher = Sha256::new();
        
        // Hash do tipo
        hasher.update(format!("{:?}", self.unit_type).as_bytes());
        
        // Hash dos operadores (ordenado)
        let mut ops: Vec<_> = self.operators.iter().map(|o| &o.name).collect();
        ops.sort();
        for op in ops {
            hasher.update(op.as_bytes());
        }
        
        // Hash das policies
        let mut policies: Vec<_> = self.policies.iter().map(|p| &p.name).collect();
        policies.sort();
        for policy in policies {
            hasher.update(policy.as_bytes());
        }
        
        let result = hasher.finalize();
        self.source_hash = Some(hex::encode(result));
    }
}

// ============================================================================
// POLICY BIT - Mantém compatibilidade
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PolicyBit {
    pub name: String,
    pub description: String,
    pub condition: Expression,
    pub metadata: HashMap<String, String>,
}

impl PolicyBit {
    pub fn new(name: &str, description: &str) -> Self {
        Self {
            name: name.to_string(),
            description: description.to_string(),
            condition: Expression::Literal(Value::Boolean(true)),
            metadata: HashMap::new(),
        }
    }
    
    pub fn with_condition(mut self, condition: Expression) -> Self {
        self.condition = condition;
        self
    }
}

// ============================================================================
// BUILDERS - API fluente
// ============================================================================

pub fn matrix_multiply(a: Expression, b: Expression) -> Expression {
    Expression::BinaryOp {
        op: SemanticOp::MatMul,
        left: Box::new(a),
        right: Box::new(b),
    }
}

pub fn dot_product(a: Expression, b: Expression) -> Expression {
    Expression::BinaryOp {
        op: SemanticOp::DotProduct,
        left: Box::new(a),
        right: Box::new(b),
    }
}

pub fn convolution(input: Expression, kernel: Expression) -> Expression {
    Expression::BinaryOp {
        op: SemanticOp::Convolution2D,
        left: Box::new(input),
        right: Box::new(kernel),
    }
}

// Comparison helpers
pub fn eq(a: Expression, b: Expression) -> Expression {
    Expression::BinaryOp {
        op: SemanticOp::Eq,
        left: Box::new(a),
        right: Box::new(b),
    }
}

pub fn neq(a: Expression, b: Expression) -> Expression {
    Expression::BinaryOp {
        op: SemanticOp::Neq,
        left: Box::new(a),
        right: Box::new(b),
    }
}

pub fn gt(a: Expression, b: Expression) -> Expression {
    Expression::BinaryOp {
        op: SemanticOp::Gt,
        left: Box::new(a),
        right: Box::new(b),
    }
}

pub fn lt(a: Expression, b: Expression) -> Expression {
    Expression::BinaryOp {
        op: SemanticOp::Lt,
        left: Box::new(a),
        right: Box::new(b),
    }
}

pub fn gte(a: Expression, b: Expression) -> Expression {
    Expression::BinaryOp {
        op: SemanticOp::Gte,
        left: Box::new(a),
        right: Box::new(b),
    }
}

pub fn lte(a: Expression, b: Expression) -> Expression {
    Expression::BinaryOp {
        op: SemanticOp::Lte,
        left: Box::new(a),
        right: Box::new(b),
    }
}

// Arithmetic helpers
pub fn add(a: Expression, b: Expression) -> Expression {
    Expression::BinaryOp {
        op: SemanticOp::Add,
        left: Box::new(a),
        right: Box::new(b),
    }
}

pub fn sub(a: Expression, b: Expression) -> Expression {
    Expression::BinaryOp {
        op: SemanticOp::Sub,
        left: Box::new(a),
        right: Box::new(b),
    }
}

pub fn mul(a: Expression, b: Expression) -> Expression {
    Expression::BinaryOp {
        op: SemanticOp::Mul,
        left: Box::new(a),
        right: Box::new(b),
    }
}

pub fn div(a: Expression, b: Expression) -> Expression {
    Expression::BinaryOp {
        op: SemanticOp::Div,
        left: Box::new(a),
        right: Box::new(b),
    }
}

// Mantém compatibilidade com código existente
pub fn binary_expr(op: Operator, left: Expression, right: Expression) -> Expression {
    let semantic_op = match op {
        Operator::And => SemanticOp::And,
        Operator::Or => SemanticOp::Or,
        Operator::Eq => SemanticOp::Eq,
        Operator::Neq => SemanticOp::Neq,
        Operator::Gt => SemanticOp::Gt,
        Operator::Lt => SemanticOp::Lt,
        Operator::Gte => SemanticOp::Gte,
        Operator::Lte => SemanticOp::Lte,
        Operator::Not => panic!("Not is unary"),
        Operator::In => panic!("In not yet supported"),
    };
    
    Expression::BinaryOp {
        op: semantic_op,
        left: Box::new(left),
        right: Box::new(right),
    }
}

// Compatibilidade reversa
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Operator {
    And,
    Or,
    Not,
    Eq,
    Neq,
    Gt,
    Lt,
    Gte,
    Lte,
    In,
}

pub fn literal(value: serde_json::Value) -> Expression {
    let val = match value {
        serde_json::Value::Bool(b) => Value::Boolean(b),
        serde_json::Value::Number(n) => {
            if let Some(i) = n.as_i64() {
                Value::Integer(i)
            } else if let Some(f) = n.as_f64() {
                Value::Float(f)
            } else {
                Value::Null
            }
        }
        serde_json::Value::String(s) => Value::String(s),
        serde_json::Value::Array(arr) => {
            Value::Array(arr.into_iter().map(|v| match v {
                serde_json::Value::Bool(b) => Value::Boolean(b),
                serde_json::Value::Number(n) => {
                    if let Some(i) = n.as_i64() {
                        Value::Integer(i)
                    } else {
                        Value::Float(n.as_f64().unwrap_or(0.0))
                    }
                }
                _ => Value::Null,
            }).collect())
        }
        _ => Value::Null,
    };
    
    Expression::Literal(val)
}

pub fn context_ref(path: &[&str], _fallback: Option<serde_json::Value>) -> Expression {
    Expression::ContextRef {
        path: path.iter().map(|s| s.to_string()).collect(),
    }
}

pub fn unary_expr(op: Operator, arg: Expression) -> Expression {
    assert_eq!(op, Operator::Not, "Only Not is unary");
    Expression::UnaryOp {
        op: SemanticOp::Not,
        arg: Box::new(arg),
    }
}
