# EXAMPLE ONLY — modelo ilustrativo. NÃO é arquivo canônico. Adapte antes de usar.
# Integração (opcional) — JSON✯Atomic (EXAMPLE ONLY)

Este diretório é apenas documentação de **exemplo** para um possível mapeamento TDLN→JSON✯Atomic.
Nenhum runtime é incluído aqui; o core do TDLN Pure permanece agnóstico de engine.
