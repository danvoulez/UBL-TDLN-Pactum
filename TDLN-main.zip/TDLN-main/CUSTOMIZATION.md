# Customização e Possibilidades Criativas — TDLN

**TDLN é um protocolo extensível. Este documento mostra o que você PODE e o que você NÃO DEVE fazer.**

---

## 🎨 O Que Você PODE Customizar

### 1. **Novos Tipos de Units** ✅

```rust
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum UnitType {
    // TDLN oferece tipos base
    PolicyValidator,
    AccessControl,
    NeuralNetworkLayer,
    MatrixProcessor,
    
    // VOCÊ PODE adicionar tipos próprios
    CustomLogic,              // ✅ Tipo genérico
    AudioProcessor,           // ✅ Seu domínio
    ImageTransformer,         // ✅ Sua necessidade
    BlockchainValidator,      // ✅ Sua aplicação
    QuantumCircuit,           // ✅ Hardware quântico
}
```

**Como fazer**:
- Fork TDLN e adicione seu tipo em `UnitType`
- Crie PR se for útil para comunidade
- Ou crie biblioteca externa que estende

---

### 2. **Novos Operadores Semânticos** ✅

```rust
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum SemanticOp {
    // TDLN oferece operadores base
    And, Or, Add, MatMul, Convolution2D,
    
    // VOCÊ PODE adicionar operadores
    Custom(String),           // ✅ Operador nomeado customizado
    
    // Exemplos possíveis:
    // FourierTransform,
    // WaveletDecomposition,
    // QuantumGate(String),
    // ChemicalReaction,
}
```

**Como fazer**:
```rust
// Seu operador customizado
let custom_op = SemanticOp::Custom("meu_algoritmo_especial".to_string());

let expr = Expression::BinaryOp {
    op: custom_op,
    left: Box::new(input_data),
    right: Box::new(parameters),
};
```

---

### 3. **Novos Tipos de Valores** ✅

```rust
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum Value {
    // TDLN oferece tipos base
    Boolean(bool),
    Integer(i64),
    Float(f64),
    String(String),
    Array(Vec<Value>),
    Matrix { rows: usize, cols: usize, data: Vec<f64> },
    
    // VOCÊ PODE estender via metadados
    Null,  // Use com metadata para tipos customizados
}
```

**Extensão via metadados**:
```rust
let mut unit = SemanticUnit::new("custom", "Custom data type");
unit.metadata.insert("value_type".to_string(), "ComplexNumber".to_string());
unit.metadata.insert("real".to_string(), "3.0".to_string());
unit.metadata.insert("imag".to_string(), "4.0".to_string());
```

---

### 4. **Metadados Customizados** ✅

```rust
let mut unit = SemanticUnit::new("example", "Example unit");

// VOCÊ PODE adicionar qualquer metadado
unit.metadata.insert("author".to_string(), "Seu Nome".to_string());
unit.metadata.insert("version".to_string(), "1.0.0".to_string());
unit.metadata.insert("optimization_hint".to_string(), "parallel".to_string());
unit.metadata.insert("target_hardware".to_string(), "fpga".to_string());
unit.metadata.insert("domain".to_string(), "medical_imaging".to_string());

// Use namespace para evitar conflitos
unit.metadata.insert("myapp:custom_field".to_string(), "value".to_string());
```

---

### 5. **Novos Backends de Compilação** ✅

TDLN é agnóstico de backend. Você pode criar:
- WebGPU compiler
- ROCm compiler (AMD)
- TPU compiler (Google)
- Quantum circuit compiler
- WASM compiler
- JavaScript compiler
- Python compiler

**Padrão**:
```rust
pub trait TDLNBackend {
    fn compile(&self, unit: &SemanticUnit) -> Result<String, Error>;
}

impl TDLNBackend for MeuBackend {
    fn compile(&self, unit: &SemanticUnit) -> Result<String, Error> {
        // Sua lógica de compilação
        Ok(codigo_gerado)
    }
}
```

---

### 6. **Novos Formatos de Serialização** ✅

TDLN usa JSON por padrão, mas você pode:
- YAML serialization
- TOML serialization
- Protobuf serialization
- MessagePack serialization

```rust
// Exemplo: YAML
let yaml = serde_yaml::to_string(&unit)?;

// Exemplo: MessagePack
let msgpack = rmp_serde::to_vec(&unit)?;
```

---

## ⛔ O Que Você NÃO DEVE Fazer

### 1. **Modificar Estruturas Core Existentes** ❌

```rust
// ❌ NÃO FAÇA: Modificar SemanticUnit
pub struct SemanticUnit {
    pub name: String,
    pub meu_campo_novo: String,  // ❌ Quebra compatibilidade
}

// ✅ FAÇA: Use metadados
unit.metadata.insert("meu_campo".to_string(), "valor".to_string());
```

**Por quê?** Quebra compatibilidade com ecossistema TDLN.

---

### 2. **Quebrar Determinismo** ❌

```rust
// ❌ NÃO FAÇA: Hash não-determinístico
use std::time::SystemTime;
let hash = format!("{:?}", SystemTime::now());  // ❌ Diferente a cada execução

// ✅ FAÇA: Hash determinístico
unit.calculate_hash();  // Sempre mesmo resultado para mesma entrada
```

**Por quê?** TDLN garante reprodutibilidade. Mesma entrada = mesma saída.

---

### 3. **Ignorar Hashes e Assinaturas** ❌

```rust
// ❌ NÃO FAÇA: Modificar unit sem recalcular hash
unit.name = "novo_nome".to_string();
// unit.source_hash ainda aponta para versão antiga!

// ✅ FAÇA: Recalcule hash após modificações
unit.name = "novo_nome".to_string();
unit.calculate_hash();
```

**Por quê?** Hashes garantem integridade. Sem recalcular = dados corrompidos.

---

### 4. **Criar Dependências Circulares** ❌

```rust
// ❌ NÃO FAÇA: Referências circulares
let expr_a = Expression::Variable("b".to_string());
let expr_b = Expression::Variable("a".to_string());
// a depende de b, b depende de a = loop infinito

// ✅ FAÇA: Árvores de dependência acíclicas (DAG)
```

**Por quê?** Avaliação infinita = travamento.

---

### 5. **Misturar Domínios no Mesmo Unit** ❌

```rust
// ❌ NÃO FAÇA: Unit fazendo tudo
let unit = SemanticUnit::new("god_object", "Does everything");
unit.add_operator(matrix_mul);
unit.add_operator(audio_fft);
unit.add_operator(blockchain_hash);
unit.add_operator(image_filter);  // Faz tudo = faz nada bem

// ✅ FAÇA: Units focados, composição via pipeline
let unit_matrix = SemanticUnit::new("matrix_proc", "Matrix operations");
let unit_audio = SemanticUnit::new("audio_proc", "Audio processing");
// Compose via Expression::Pipeline([unit_matrix, unit_audio])
```

**Por quê?** Separação de responsabilidades. Reutilização. Testabilidade.

---

### 6. **Usar Nomes Genéricos** ❌

```rust
// ❌ NÃO FAÇA: Nomes vagos
let unit = SemanticUnit::new("unit1", "Does stuff");
let policy = PolicyBit::new("check", "Checks things");

// ✅ FAÇA: Nomes descritivos
let unit = SemanticUnit::new("matrix_multiply_4x4", "4x4 matrix multiplication with bounds checking");
let policy = PolicyBit::new("input_size_validated", "Ensures input matrix is exactly 4x4");
```

**Por quê?** Clareza. Auditabilidade. Manutenção.

---

## 🎯 Categorias de Customização

### **Nível 1: Metadados** (Mais Seguro)
- ✅ Adicionar campos em `metadata`
- ✅ Zero risco de quebrar compatibilidade
- ✅ Ideal para: configurações, hints, anotações

### **Nível 2: Operadores Custom** (Seguro)
- ✅ Usar `SemanticOp::Custom(String)`
- ✅ Compatível com core TDLN
- ✅ Ideal para: algoritmos proprietários, domínios específicos

### **Nível 3: Novos Types** (Moderado)
- ⚠️ Fork do TDLN necessário
- ⚠️ Manter sincronizado com upstream
- ✅ Ideal para: extensões grandes, novos domínios

### **Nível 4: Novos Backends** (Independente)
- ✅ Não modifica TDLN core
- ✅ Crie biblioteca separada
- ✅ Ideal para: novos targets de compilação

---

## 📂 Exemplos por Categoria

```
examples/
├── 01_core_usage/              # Usar TDLN como está
│   ├── basic_policy/
│   ├── matrix_operations/
│   └── data_validation/
│
├── 02_custom_operators/        # Operadores customizados
│   ├── audio_fft/
│   ├── image_convolution/
│   └── quantum_gates/
│
├── 03_custom_types/            # Tipos customizados (fork)
│   ├── neural_network/
│   ├── blockchain/
│   └── chemical_reactions/
│
├── 04_custom_backends/         # Novos compiladores
│   ├── webgpu/
│   ├── rocm/
│   └── quantum_simulator/
│
└── 05_integrations/            # Integrações externas
    ├── python_binding/
    ├── javascript_runtime/
    └── rest_api/
```

---

## 🚀 Próximos Passos

1. **Começar simples**: Use metadados para customização
2. **Crescer gradualmente**: Adicione operadores custom
3. **Contribuir**: Se útil para outros, abra PR
4. **Consultar comunidade**: Discuta grandes mudanças antes

---

## 📚 Referências

- **Core Spec**: [specs/tdln-core-v2.0.schema.json](./specs/tdln-core-v2.0.schema.json)
- **Arquitetura**: [docs/ARCHITECTURE.md](./docs/ARCHITECTURE.md)
- **Contribuir**: [CONTRIBUTING.md](./CONTRIBUTING.md)

---

**TDLN é seu protocolo. Customize com responsabilidade! 🎨**
