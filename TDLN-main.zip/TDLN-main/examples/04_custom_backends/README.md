# Custom Backends Examples

Esta pasta contém exemplos de **backends customizados** que compilam TDLN para diferentes plataformas.

## O Que É Um Backend?

Um backend traduz SemanticUnits TDLN para código executável em uma plataforma específica (GPU, CPU, WASM, etc.).

## Backends de Exemplo

Esta pasta está preparada para receber backends da comunidade como:

- **WebGPU** - Compilação para navegadores
- **Python** - Runtime Python
- **JavaScript/WASM** - Web Assembly
- **ROCm** - GPUs AMD (veja TDLN-Chip)
- **TPU** - Google Tensor Processing Units
- **Quantum** - Circuitos quânticos

## Como Criar Um Backend

```rust
pub trait TDLNBackend {
    fn compile(&self, unit: &SemanticUnit) -> Result<String, Error>;
}

pub struct MeuBackend;

impl TDLNBackend for MeuBackend {
    fn compile(&self, unit: &SemanticUnit) -> Result<String, Error> {
        // 1. Validar entrada
        validate_unit(unit)?;
        
        // 2. Gerar código para sua plataforma
        let code = generate_code_for_platform(unit)?;
        
        // 3. Garantir determinismo
        assert_deterministic(&code)?;
        
        Ok(code)
    }
}
```

## Requisitos de Backend

✅ **DEVE**:
- Ser determinístico (mesma entrada → mesma saída)
- Implementar TODAS as políticas declaradas
- Validar tipos de entrada
- Ser testável

❌ **NÃO DEVE**:
- Modificar estrutura TDLN core
- Ignorar políticas
- Gerar código não-auditável

## Backends de Hardware

Para backends de hardware (Metal, CUDA, Verilog), veja **[TDLN-Chip](https://github.com/logline-foundation/TDLN-Chip)**.

## Recursos

- [CUSTOMIZATION.md](../../CUSTOMIZATION.md) - Guia de customização
- [ARCHITECTURE.md](../../docs/ARCHITECTURE.md) - Arquitetura TDLN
- [TDLN-Chip](https://github.com/logline-foundation/TDLN-Chip) - Backends de hardware
