# Custom Operators

Extend TDLN with domain-specific functions.

## What Are Custom Operators?

TDLN has built-in operators (`AND`, `OR`, `NOT`, `GT`, etc.), but you can define custom functions for:

- **Domain logic**: Financial calculations, business rules, validation
- **External integrations**: Call APIs, databases, ML models
- **Performance**: Hand-optimized implementations

Custom operators appear as `function_call` nodes in policies.

## Files

- [audio-lufs.tdln.json](audio-lufs.tdln.json) - Audio loudness verification using custom LUFS function
- [finance-rsi.tdln.json](finance-rsi.tdln.json) - Trading signals using Relative Strength Index

## How It Works

### 1. Define the Function

In Rust:
```rust
fn compute_rsi(prices: &[f64]) -> f64 {
    let (gains, losses) = calculate_avg_changes(prices);
    100.0 - (100.0 / (1.0 + gains / losses))
}
```

### 2. Register It

```rust
runtime.register_function("compute_rsi", compute_rsi);
```

### 3. Use It in Policies

```json
{
  "type": "function_call",
  "function": "compute_rsi",
  "arguments": [
    { "type": "context_ref", "path": ["prices", "recent_14"] }
  ]
}
```

### 4. Execute

```rust
let result = runtime.evaluate(&policy, &context)?;
```

TDLN handles:
- ✅ Function dispatch
- ✅ Argument marshaling  
- ✅ Error propagation
- ✅ Result caching

## Real-World Examples

### 📻 Audio Processing (LUFS)

```json
{
  "condition": {
    "type": "binary",
    "operator": "GTE",
    "left": {
      "type": "function_call",
      "function": "measure_lufs",
      "arguments": [{ "type": "context_ref", "path": ["audio_buffer"] }]
    },
    "right": { "type": "literal", "value": -23.0 }
  }
}
```

**Use case**: Streaming platforms enforcing loudness standards (Spotify, YouTube).

### 📈 Finance (RSI Indicator)

```json
{
  "condition": {
    "type": "binary",
    "operator": "LT",
    "left": {
      "type": "function_call",
      "function": "compute_rsi",
      "arguments": [{ "type": "context_ref", "path": ["prices"] }]
    },
    "right": { "type": "literal", "value": 30.0 }
  }
}
```

**Use case**: Trading bots detecting oversold conditions (buy signal).

## Performance

Custom functions can be:

- **Interpreted**: Easy to write, slower execution (~100-500 ns/call)
- **Compiled**: Embedded in JIT/AOT pipeline (~10-50 ns/call)
- **GPU-accelerated**: Via `materialization_hints` (parallel execution)

Example compile-time specialization:

```rust
#[inline]
fn compute_rsi_optimized(prices: &[f64; 14]) -> f64 {
    // Compiler unrolls loops, uses SIMD
    // 10-100x faster than generic version
}
```

## Language Bindings

Custom operators work across FFI:

| Language | Binding | Example |
|----------|---------|---------|
| Python | PyO3 | `@tdln.register_fn("my_func")` |
| JavaScript | Napi-rs | `runtime.registerFunction("my_func", ...)` |
| C/C++ | FFI | `tdln_register_fn(ctx, "my_func", ...)` |

See [examples/05_integrations/](../05_integrations/) for complete examples.

## Best Practices

✅ **DO**:
- Use descriptive function names (`compute_rsi`, not `calc1`)
- Return deterministic results (same input → same output)
- Handle errors gracefully
- Document expected input/output types

❌ **DON'T**:
- Use side effects (database writes, file I/O) without clear documentation
- Create non-deterministic functions (random, time-based)
- Ignore error cases

## Next Steps

- [Composition](../03_composition/) - Combine multiple operators in complex policies
- [Integrations](../05_integrations/) - FFI examples (Python, JS, C)
- [Optimization](../../TDLN-Chip/examples/03_optimization/) - GPU-compile custom operators

## Resources

- [TDLN_FORMAT.md](../../docs/TDLN_FORMAT.md) - Policy format specification
- [CONTRIBUTING.md](../../CONTRIBUTING.md) - How to contribute new operators
