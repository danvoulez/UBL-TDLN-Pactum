# Integration Examples

Esta pasta contém exemplos de **integrações** com linguagens e frameworks externos.

## Integrações Possíveis

### Linguagens
- **Python** - Binding via PyO3
- **JavaScript/Node.js** - Binding via NAPI
- **C/C++** - FFI direto
- **Go** - CGo binding
- **Java/Kotlin** - JNI

### Frameworks
- **REST API** - Servidor HTTP que consome TDLN
- **gRPC** - Serviço RPC
- **WebSockets** - Streaming de units
- **Message Queue** - Kafka, RabbitMQ, etc.

### Plataformas
- **Kubernetes** - Operator pattern
- **AWS Lambda** - Serverless
- **Edge Computing** - IoT devices

## Exemplo: Python Binding

```python
import tdln

# Carregar unit
unit = tdln.load("example.tdln.json")

# Avaliar
result = tdln.evaluate(unit, {"x": 10})

# Compilar para hardware (via TDLN-Chip)
code = tdln.compile(unit, backend="metal")
```

## Exemplo: REST API

```bash
POST /api/v1/evaluate
Content-Type: application/json

{
  "unit_file": "example.tdln.json",
  "context": {"x": 10}
}
```

## Como Integrar

1. **Escolha método**: FFI, binding nativo, API HTTP
2. **Serialize TDLN**: JSON é universal
3. **Chame runtime**: `evaluate()` ou compile
4. **Retorne resultado**: JSON, binário, ou código gerado

## Recursos

- [CUSTOMIZATION.md](../../CUSTOMIZATION.md) - Extensibilidade
- [json-atomic/](../../integrations/json-atomic/) - Integração JSON
