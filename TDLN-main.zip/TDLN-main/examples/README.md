# TDLN Examples — Explore Unexplored Territory

Welcome to the TDLN examples! These demonstrate what we've discovered so far — and hint at what's still possible.

---

## 🧭 What We Know Works

### Proven Use Cases

1. **Core Usage** ([01_core_usage/](./01_core_usage/))
   - Basic .tdln policies
   - Standard PolicyBit composition
   - Context evaluation
   - **Discovery**: Fractal structure makes nesting intuitive

2. **Custom Operators** ([02_custom_operators/](./02_custom_operators/))
   - Domain-specific operators (AudioFFT, ImageConv, etc.)
   - Extending Expression types
   - **Discovery**: SemanticOp::Custom("name") enables infinite domains

3. **Custom Types** ([03_custom_types/](./03_custom_types/))
   - New data types (Tensors, Graphs, etc.)
   - Type validation
   - **Discovery**: Fork spec to add types, maintain determinism

4. **Custom Backends** ([04_custom_backends/](./04_custom_backends/))
   - Target platforms beyond default
   - WebAssembly, Python, Rego
   - **Discovery**: Same .tdln → multiple execution environments

5. **Integrations** ([05_integrations/](./05_integrations/))
   - REST APIs
   - Python/JavaScript libraries
   - Database triggers
   - **Discovery**: TDLN plugs into existing systems seamlessly

---

## 🚀 What We Haven't Explored Yet

### Open Questions

**Can TDLN be used for:**
- Network packet filtering?
- Compiler optimization passes?
- Scientific workflow orchestration?
- Game AI decision trees?
- Financial trading rules?
- **Your idea?**

### Integration Possibilities

**Platforms we haven't tried:**
- Kubernetes admission controllers
- Serverless functions (Lambda, Cloud Functions)
- Message queues (Kafka, RabbitMQ)
- Blockchain smart contracts
- Edge compute (Cloudflare Workers, Fastly Compute)

### Performance Unknowns

**Questions we can't answer yet:**
- What's the largest policy graph that's practical?
- How does performance scale with nesting depth?
- Can we parallelize policy evaluation?
- What's the sweet spot for caching?

---

## 📚 How to Use These Examples

### Running Examples

Each category has a README with:
- What the example demonstrates
- How to run it
- Expected output
- Performance characteristics (if known)

### Creating Your Own

1. Copy a similar example as starting point
2. Modify the .tdln structure
3. Validate against schema: `jsonschema -i your-example.tdln specs/tdln-core-v2.0.schema.json`
4. Test and measure
5. **Share your discovery!**

---

## 🎯 Contributing Your Discoveries

Found something interesting? We want to know!

### Share Your Results

- **New use case**: Open an issue describing it
- **Performance findings**: Include benchmarks
- **Integration patterns**: Show the code
- **Unexpected behaviors**: Document edge cases

### Add an Example

1. Create a new file in the appropriate category
2. Include inline comments explaining decisions
3. Add expected output
4. Document any dependencies
5. Submit a PR

---

## 🔬 Research Directions

### Academic Questions

- **Formal verification**: Can we prove policy correctness?
- **Complexity analysis**: What's the computational class?
- **Optimization bounds**: Theoretical limits?
- **Type theory**: Is TDLN a typed lambda calculus?

### Engineering Challenges

- **Debugging**: How to trace policy execution?
- **Profiling**: Where are bottlenecks?
- **Visualization**: Graph rendering of policy composition?
- **Tooling**: IDE support, linters, formatters?

---

## 🌟 Example Categories Explained

### 01_core_usage/
**Purpose**: Learn TDLN fundamentals  
**Audience**: Beginners  
**No customization** — pure protocol usage

### 02_custom_operators/
**Purpose**: Domain-specific extensions  
**Audience**: Domain experts  
**Customization**: New operators, same structure

### 03_custom_types/
**Purpose**: Type system extensions  
**Audience**: Advanced users  
**Customization**: Fork spec, extend types

### 04_custom_backends/
**Purpose**: Target new platforms  
**Audience**: Platform integrators  
**Customization**: New CodeGenerator implementations

### 05_integrations/
**Purpose**: Real-world deployments  
**Audience**: Engineers  
**Customization**: API wrappers, libraries, plugins

---

## 📖 Related Documentation

- [TDLN Format Specification](../docs/TDLN_FORMAT.md)
- [Customization Guide](../CUSTOMIZATION.md)
- [Contributing Guidelines](../CONTRIBUTING.md)
- [Architecture Overview](../docs/ARCHITECTURE.md)

---

## 🤝 Community Discoveries

**Share your findings!** Open a discussion to:
- Report surprising behaviors
- Propose new example categories
- Share performance optimizations
- Document integration patterns

**Every example here started as someone's experiment. Yours could be next.**

---

**The best discoveries are the ones we haven't made yet. Let's find them together.** 🔍✨
