# TDLN Translator: Natural Language → TDLN

Este exemplo demonstra como traduzir linguagem natural para o formato `.tdln` verificável.

## Overview

TDLN como **tradutor** permite converter especificações humanas em políticas formais e auditáveis.

## Exemplo

### Input (Linguagem Natural)

```
"Usuários premium podem fazer download de até 1000 arquivos por dia, 
desde que estejam autenticados e verificados."
```

### Output (TDLN)

```json
{
  "tdln_spec_version": "2.0.0",
  "node_type": "semantic_unit",
  "id": "su_premium_download_policy",
  
  "policies": [
    {
      "node_type": "policy_bit",
      "id": "pb_is_premium",
      "condition": {
        "type": "binary",
        "operator": "EQ",
        "left": {"type": "context_ref", "path": ["user", "tier"]},
        "right": {"type": "literal", "value": "premium"}
      }
    },
    {
      "node_type": "policy_bit",
      "id": "pb_is_authenticated",
      "condition": {
        "type": "binary",
        "operator": "EQ",
        "left": {"type": "context_ref", "path": ["auth", "status"]},
        "right": {"type": "literal", "value": "verified"}
      }
    },
    {
      "node_type": "policy_bit",
      "id": "pb_quota_check",
      "condition": {
        "type": "binary",
        "operator": "LT",
        "left": {"type": "context_ref", "path": ["user", "downloads_today"]},
        "right": {"type": "literal", "value": 1000}
      }
    },
    {
      "node_type": "policy_composition",
      "id": "pc_final_policy",
      "policies": ["pb_is_premium", "pb_is_authenticated", "pb_quota_check"],
      "aggregator": {"type": "ALL"}
    }
  ]
}
```

## Como Implementar

```rust
use tdln_core::{SemanticUnit, PolicyBit, Expression};

struct NaturalLanguageParser {
    // LLM ou parser baseado em gramática
}

impl NaturalLanguageParser {
    fn parse(&self, input: &str) -> Result<SemanticUnit, Error> {
        // 1. Extrair intenções (NLP/LLM)
        let intents = self.extract_intents(input);
        
        // 2. Mapear para PolicyBits
        let policies = intents.iter()
            .map(|intent| self.intent_to_policy(intent))
            .collect();
        
        // 3. Compor SemanticUnit
        Ok(SemanticUnit {
            tdln_spec_version: "2.0.0".to_string(),
            node_type: "semantic_unit".to_string(),
            policies,
            ..Default::default()
        })
    }
}
```

## Validação

Após tradução, validar contra schema:

```bash
jsonschema -i output.tdln ../specs/tdln-core-v2.0.schema.json
```

## Garantias

- ✅ **Determinismo**: Mesma entrada → mesma saída
- ✅ **Auditabilidade**: Hash Blake3 da política gerada
- ✅ **Verificabilidade**: Schema JSON valida correção
- ✅ **Rastreabilidade**: TranslationProof opcional

## Use Cases

- Contratos inteligentes em linguagem natural
- Políticas de compliance (GDPR, LGPD)
- Regras de negócio documentadas
- Especificações de requisitos

---

**Use Case**: Traduzir especificações humanas para políticas formais 🗣️
