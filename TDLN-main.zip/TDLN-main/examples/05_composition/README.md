# TDLN Composition: Composição de Políticas

Este exemplo demonstra como **compor múltiplas políticas** TDLN de forma modular e verificável.

## Overview

TDLN permite composição de políticas complexas a partir de políticas atômicas:
- **Parallel**: Executa políticas em paralelo
- **Sequential**: Executa em sequência
- **Conditional**: Executa conforme condição

## Tipos de Composição

### 1. Parallel (ALL/ANY)

Múltiplas políticas executam simultaneamente:

```json
{
  "node_type": "policy_composition",
  "id": "pc_multi_factor_auth",
  "policies": [
    "pb_password_valid",
    "pb_2fa_verified",
    "pb_device_trusted"
  ],
  "aggregator": {"type": "ALL"}
}
```

**Resultado**: `true` se TODAS as políticas retornarem `true`

### 2. Threshold Voting

Votação com threshold:

```json
{
  "node_type": "policy_composition",
  "id": "pc_consensus",
  "policies": [
    "pb_validator_1",
    "pb_validator_2",
    "pb_validator_3",
    "pb_validator_4"
  ],
  "aggregator": {
    "type": "THRESHOLD",
    "min_votes": 3
  }
}
```

**Resultado**: `true` se pelo menos 3 de 4 validadores aprovarem

### 3. Sequential Pipeline

Políticas executam em ordem (output de uma → input da próxima):

```json
{
  "node_type": "policy_composition",
  "id": "pc_data_pipeline",
  "policies": [
    "pb_sanitize_input",
    "pb_validate_schema",
    "pb_apply_business_rules",
    "pb_audit_log"
  ],
  "aggregator": {"type": "SEQUENTIAL"}
}
```

## Implementação

```rust
use tdln_core::{PolicyComposition, AggregatorType};
use tdln_runtime::Evaluator;

impl Evaluator {
    /// Avalia composição de políticas
    fn evaluate_composition(
        &self,
        composition: &PolicyComposition,
        context: &Context,
    ) -> Result<bool, Error> {
        let results: Vec<bool> = composition.policies.iter()
            .map(|policy_id| {
                let policy = self.get_policy(policy_id)?;
                self.evaluate(&policy, context)
            })
            .collect::<Result<Vec<_>, _>>()?;
        
        match &composition.aggregator.aggregator_type {
            AggregatorType::ALL => Ok(results.iter().all(|&r| r)),
            AggregatorType::ANY => Ok(results.iter().any(|&r| r)),
            AggregatorType::THRESHOLD { min_votes } => {
                let votes = results.iter().filter(|&&r| r).count();
                Ok(votes >= *min_votes)
            }
            AggregatorType::SEQUENTIAL => {
                // Pipeline: cada etapa usa output da anterior
                self.evaluate_pipeline(&results, context)
            }
        }
    }
}
```

## Exemplos Reais

### 1. Smart Contract (Blockchain)

```rust
// Política de transferência de token
let transfer_policy = PolicyComposition {
    id: "pc_token_transfer",
    policies: vec![
        "pb_sender_has_balance",
        "pb_receiver_valid",
        "pb_amount_within_limits",
        "pb_not_blacklisted",
    ],
    aggregator: AggregatorType::ALL,
};
```

### 2. Sistema de Permissões (RBAC)

```rust
// Admin pode fazer tudo, usuário só leitura
let access_policy = PolicyComposition {
    id: "pc_resource_access",
    policies: vec![
        PolicyComposition {
            id: "pc_admin_full_access",
            policies: vec!["pb_is_admin"],
            aggregator: AggregatorType::ANY,
        },
        PolicyComposition {
            id: "pc_user_read_only",
            policies: vec!["pb_is_user", "pb_action_is_read"],
            aggregator: AggregatorType::ALL,
        },
    ],
    aggregator: AggregatorType::ANY, // Admin OU user read-only
};
```

### 3. Pipeline de Processamento

```rust
// ETL pipeline
let etl_pipeline = PolicyComposition {
    id: "pc_data_etl",
    policies: vec![
        "pb_extract_from_source",
        "pb_transform_data",
        "pb_validate_output",
        "pb_load_to_target",
    ],
    aggregator: AggregatorType::SEQUENTIAL,
};
```

## Verificação de Composição

```rust
fn verify_composition(composition: &PolicyComposition) -> Result<(), Error> {
    // 1. Todas as políticas referenciadas existem?
    for policy_id in &composition.policies {
        if !policy_exists(policy_id) {
            return Err(Error::PolicyNotFound(policy_id.clone()));
        }
    }
    
    // 2. Não há ciclos (A → B → A)?
    if has_cycle(composition) {
        return Err(Error::CyclicDependency);
    }
    
    // 3. Threshold é válido?
    if let AggregatorType::THRESHOLD { min_votes } = &composition.aggregator.aggregator_type {
        if *min_votes > composition.policies.len() {
            return Err(Error::InvalidThreshold);
        }
    }
    
    Ok(())
}
```

## Performance

| Tipo | Overhead | Paralelizável |
|------|----------|---------------|
| **ALL/ANY** | ~1µs por política | ✅ Sim (parallel) |
| **THRESHOLD** | ~1µs por política | ✅ Sim (parallel) |
| **SEQUENTIAL** | ~1µs por política | ❌ Não (pipeline) |

## Padrões Comuns

### Circuit Breaker

```json
{
  "id": "pc_circuit_breaker",
  "policies": [
    "pb_error_rate_below_threshold",
    "pb_latency_acceptable",
    "pb_upstream_healthy"
  ],
  "aggregator": {"type": "ALL"}
}
```

### Rate Limiting

```json
{
  "id": "pc_rate_limit",
  "policies": [
    "pb_requests_per_second_ok",
    "pb_daily_quota_ok",
    "pb_not_suspicious_pattern"
  ],
  "aggregator": {"type": "ALL"}
}
```

### Multi-Sig Wallet

```json
{
  "id": "pc_multisig_approval",
  "policies": [
    "pb_owner_1_signed",
    "pb_owner_2_signed",
    "pb_owner_3_signed"
  ],
  "aggregator": {
    "type": "THRESHOLD",
    "min_votes": 2
  }
}
```

## Exemplo Completo

Ver arquivo: `../premium-user-access.tdln.json` (usa PolicyComposition com ALL)

---

**Use Case**: Construir políticas complexas de forma modular e reutilizável 🔗
