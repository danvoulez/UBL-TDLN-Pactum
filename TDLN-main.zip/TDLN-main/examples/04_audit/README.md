# TDLN Audit: Sistema de Rastreabilidade e Compliance

Este exemplo demonstra como usar TDLN para **auditoria completa** de decisões de política.

## Overview

TDLN como **sistema de audit** garante rastreabilidade total:
- Quem criou a política
- Quando foi executada
- Qual foi o input/output
- Prova criptográfica de correção

## Componentes de Auditoria

### 1. TranslationProof

```json
{
  "proof_type": "translation",
  "translation_steps": [
    {
      "stage": "parse",
      "input_hash": "blake3_abc...",
      "output_hash": "blake3_def...",
      "duration_ms": 1.2,
      "engine": "tdln_parser_v2.0"
    },
    {
      "stage": "policy",
      "input_hash": "blake3_def...",
      "output_hash": "blake3_ghi...",
      "duration_ms": 0.8,
      "engine": "tdln_policy_engine_v2.0",
      "metadata": {
        "policy_type": "policy.none.v1",
        "transformations_applied": 3
      }
    }
  ],
  "provenance": {
    "created_by": "user_alice_doe",
    "created_at": "2025-01-15T14:30:45.123Z",
    "organization": "LogLine Foundation"
  },
  "signature": "ed25519_..."
}
```

### 2. Trace Manifest (NDJSON)

```ndjson
{"event":"policy_created","timestamp":"2025-01-15T14:30:00Z","policy_id":"pb_admin_check","hash":"blake3_..."}
{"event":"policy_evaluated","timestamp":"2025-01-15T14:31:00Z","policy_id":"pb_admin_check","input_hash":"blake3_...","output":true}
{"event":"policy_evaluated","timestamp":"2025-01-15T14:32:00Z","policy_id":"pb_admin_check","input_hash":"blake3_...","output":false}
```

## Implementação

```rust
use tdln_core::{SemanticUnit, TranslationProof};
use std::fs::OpenOptions;
use std::io::Write;

struct AuditLogger {
    trace_file: String,
}

impl AuditLogger {
    /// Registra execução de política
    fn log_execution(
        &self,
        policy_id: &str,
        context: &Context,
        result: bool,
    ) -> Result<(), Error> {
        let entry = json!({
            "event": "policy_evaluated",
            "timestamp": Utc::now().to_rfc3339(),
            "policy_id": policy_id,
            "input_hash": blake3::hash(&serde_json::to_vec(context)?),
            "output": result,
        });
        
        // Append to NDJSON trace
        let mut file = OpenOptions::new()
            .create(true)
            .append(true)
            .open(&self.trace_file)?;
        
        writeln!(file, "{}", entry)?;
        Ok(())
    }
    
    /// Gera relatório de auditoria
    fn generate_audit_report(&self, start: DateTime, end: DateTime) -> AuditReport {
        // Ler traces NDJSON
        let traces = self.read_traces(start, end);
        
        AuditReport {
            period: (start, end),
            total_executions: traces.len(),
            unique_policies: traces.iter().map(|t| &t.policy_id).collect(),
            decisions: traces.iter().filter(|t| t.output).count(),
            // ...
        }
    }
}
```

## Use Cases

### 1. Compliance Regulatório (GDPR, LGPD)

```rust
// Provar que decisão de acesso foi correta
fn audit_gdpr_compliance(user_id: &str, date: DateTime) -> ComplianceReport {
    let logger = AuditLogger::new("traces.ndjson");
    let traces = logger.get_user_traces(user_id, date);
    
    ComplianceReport {
        user_id: user_id.to_string(),
        date,
        all_decisions_logged: traces.len() > 0,
        all_hashes_valid: traces.iter().all(|t| verify_hash(t)),
        signature_valid: verify_signature(&traces),
    }
}
```

### 2. Investigação de Incidentes

```bash
# Quem aprovou a transação suspeita?
grep "transaction_id:12345" traces.ndjson | jq '.provenance.created_by'

# Qual política foi aplicada?
grep "transaction_id:12345" traces.ndjson | jq '.policy_id'

# Hash da política na época
grep "pb_fraud_check" traces.ndjson | head -1 | jq '.hash'
```

### 3. Análise Forense

```rust
fn forensic_analysis(incident_time: DateTime) -> ForensicReport {
    // Reconstruir estado exato da política no momento do incidente
    let policy_hash = get_policy_hash_at(incident_time);
    let policy = reconstruct_policy_from_hash(policy_hash);
    
    // Re-executar com mesmo input
    let context = get_context_at(incident_time);
    let result = evaluator.evaluate(&policy, &context);
    
    ForensicReport {
        can_reproduce: true,
        policy_unchanged: verify_policy_immutable(policy_hash),
        decision_correct: result == expected_result,
    }
}
```

## Garantias Criptográficas

- ✅ **Imutabilidade**: Blake3 hash impede alteração
- ✅ **Autenticidade**: Ed25519 signature prova autoria
- ✅ **Não-repúdio**: Assinatura digital irrefutável
- ✅ **Completude**: Trace NDJSON registra tudo

## Performance

| Componente | Overhead | Quando usar |
|------------|----------|-------------|
| Blake3 hash | ~100µs | Sempre (integridade) |
| Ed25519 signature | ~1ms | Auditoria crítica |
| NDJSON trace | ~50µs | Compliance |
| **Total** | **~1.8ms** | Auditoria completa |

## Exemplo Completo

Ver arquivo: `../complete-with-trace.tdln.json` (tem proof + signature completo)

---

**Use Case**: Compliance regulatório e investigação forense 📊
