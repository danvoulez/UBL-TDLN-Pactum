# TDLN Validator: Verificação Formal de Políticas

Este exemplo demonstra como usar TDLN para **validar políticas** de forma determinística.

## Overview

TDLN como **validador** permite verificar se políticas são:
- Sintaticamente corretas
- Semanticamente consistentes
- Livres de contradições
- Completas (cobrem todos casos)

## Exemplo: Validador de Políticas de Acesso

```rust
use tdln_core::{SemanticUnit, PolicyComposition};
use tdln_runtime::Evaluator;

struct PolicyValidator {
    evaluator: Evaluator,
}

impl PolicyValidator {
    /// Valida se política está bem formada
    fn validate_syntax(&self, unit: &SemanticUnit) -> Result<(), ValidationError> {
        // 1. Verificar schema JSON
        self.check_schema(unit)?;
        
        // 2. Verificar hashes
        self.verify_hashes(unit)?;
        
        // 3. Verificar referências (PolicyComposition aponta para PolicyBits válidos)
        self.check_references(unit)?;
        
        Ok(())
    }
    
    /// Valida se política é semanticamente consistente
    fn validate_semantics(&self, unit: &SemanticUnit) -> Result<(), ValidationError> {
        // 1. Detectar contradições
        if self.has_contradictions(unit) {
            return Err(ValidationError::Contradiction);
        }
        
        // 2. Verificar completude (todos casos cobertos)
        if !self.is_complete(unit) {
            return Err(ValidationError::Incomplete);
        }
        
        // 3. Testar com casos de teste
        self.run_test_suite(unit)?;
        
        Ok(())
    }
    
    /// Detecta contradições lógicas
    fn has_contradictions(&self, unit: &SemanticUnit) -> bool {
        // Exemplo: (x == true) AND (x == false)
        // Usar SAT solver ou análise de AST
        false // placeholder
    }
}
```

## Casos de Uso

### 1. Validação de Compliance

```json
{
  "policy_name": "GDPR Article 17 - Right to Erasure",
  "policies": [
    {
      "id": "pb_user_requests_deletion",
      "condition": "user.requested_deletion == true"
    },
    {
      "id": "pb_no_legal_obligation",
      "condition": "legal.retention_required == false"
    }
  ]
}
```

**Validação**: Verificar se política cobre todos requisitos GDPR.

### 2. Detecção de Deadlocks

```json
{
  "policies": [
    {"id": "pb_resource_A_locked", "condition": "lock.A == true"},
    {"id": "pb_resource_B_locked", "condition": "lock.B == true"},
    {
      "id": "pc_wait_for_both",
      "aggregator": {"type": "ALL"},
      "policies": ["pb_resource_A_locked", "pb_resource_B_locked"]
    }
  ]
}
```

**Validação**: Analisar se há risco de deadlock (A espera B, B espera A).

### 3. Coverage Analysis

```rust
fn test_policy_coverage() {
    let unit = load_policy("access_control.tdln");
    let validator = PolicyValidator::new();
    
    // Gerar casos de teste
    let test_cases = vec![
        Context { role: "admin", verified: true },
        Context { role: "user", verified: true },
        Context { role: "user", verified: false },
        // ... todos os casos
    ];
    
    // Verificar se todos retornam resultado determinístico
    for case in test_cases {
        let result = validator.evaluate(&unit, &case);
        assert!(result.is_ok());
    }
}
```

## Ferramentas

```bash
# Validar sintaxe
./scripts/validate-all.sh

# Verificar integridade (hashes)
./scripts/check-integrity.sh

# Rodar suite de testes
cargo test --package tdln_runtime -- validator
```

## Garantias Formais

- ✅ **Sintaxe**: Schema JSON garante estrutura correta
- ✅ **Integridade**: Blake3 hash garante imutabilidade
- ✅ **Semântica**: Evaluator testa todos caminhos
- ✅ **Completude**: Coverage analysis detecta gaps

## Exemplo Completo

Ver arquivo: `../premium-user-access.tdln.json` (tem proof de validação)

---

**Use Case**: Verificar correção de políticas antes de deployment ✅
