# Core Usage Examples

Esta pasta contém exemplos de **uso básico** do protocolo TDLN usando apenas estruturas core (sem customização).

## Exemplos

### 🔩 `chip-minimal.tdln.json`
Exemplo mínimo de SemanticUnit com matriz 4x4.

**Operação**: `MatMul` (multiplicação de matrizes)  
**Políticas**: Validação de tamanho de entrada

### 👤 `premium-user-access.tdln.json`
Exemplo de controle de acesso premium usando PolicyBit.

**Operação**: `And` (lógica booleana)  
**Políticas**: Validação de usuário premium

## Estrutura TDLN Core

```json
{
  "tdln_version": "2.0.0",
  "id": "meu_exemplo",
  "unit_type": "PolicyValidator",
  "name": "Nome descritivo",
  "expression": { /* lógica */ },
  "policies": [ /* validações */ ]
}
```

## Tipos de Units Disponíveis

- `PolicyValidator` - Validação de políticas
- `AccessControl` - Controle de acesso
- `NeuralNetworkLayer` - Camadas de rede neural
- `MatrixProcessor` - Processamento de matrizes

## Operadores Disponíveis

- `And`, `Or` - Lógica booleana
- `Add` - Adição aritmética
- `MatMul` - Multiplicação de matrizes
- `Convolution2D` - Convolução 2D

## Recursos

- [TDLN_FORMAT.md](../../docs/TDLN_FORMAT.md) - Especificação completa
- [QUICKSTART.md](../../docs/QUICKSTART.md) - Guia rápido
