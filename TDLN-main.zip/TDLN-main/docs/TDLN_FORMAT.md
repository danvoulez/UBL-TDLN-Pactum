# Formato .tdln v2.0 - Especificação Canônica

**Status**: Definitivo  
**Versão**: 2.0.0  
**Data**: 15 de dezembro de 2025  
**Responsável**: TDLN-Pure (MIT License)

---

## Visão Geral

O formato `.tdln` é a **representação canônica de uma SemanticUnit** — a unidade atômica do protocolo TDLN. Um arquivo .tdln não é um "envelope" ou "wrapper", mas sim **a própria estrutura fractal do TDLN Core**.

```
.tdln file = SemanticUnit (raiz)
    ├─ policies[] (array de PolicyBit ou PolicyComposition)
    │   ├─ PolicyBit { node_type, id, hash, condition }
    │   │   └─ condition: Expression (recursivo)
    │   │       └─ BinaryExpression / UnaryExpression / ...
    │   │
    │   └─ PolicyComposition { node_type, id, hash, policies[], aggregator }
    │
    └─ proof: TranslationProof (opcional, para auditoria)
        └─ translation_steps[] (rastreabilidade completa)
```

**Princípio Fractal**: Cada nível da estrutura é auto-descritivo com `node_type`, `id`, `hash` — mantendo a natureza fractal da invenção TDLN.

---

## Localização da Canonização

### Única Fonte da Verdade

```
TDLN-Pure/specs/tdln-core-v2.0.schema.json ← JSON Schema canônico
```

**Responsável**: TDLN-Pure (repositório MIT)  
**Conteúdo**: Definição completa do SemanticUnit e todos os seus componentes  
**Validação**: Todos os .tdln devem validar contra este schema

### Como Cada Repo Usa

| Repositório | Lê | Responsabilidade |
|-------------|-----|------------------|
| **TDLN-Pure** | SemanticUnit completo | Define spec, valida estrutura, processa proof |
| **TDLN-Chip** | policies[], materialization (hints) | Compila policies para hardware |
| **TDLN-API** | Tudo (proprietário) | Gera .tdln via LLM, otimização |

---

## Estrutura Fractal: TDLN Core

### SemanticUnit (Raiz)

Todo arquivo .tdln é uma **SemanticUnit**:

```typescript
interface SemanticUnit {
  tdln_spec_version: string;     // "2.0.0"
  node_type: "semantic_unit";    // Sempre "semantic_unit" na raiz
  id: string;                    // "su_" + UUID v4
  hash: string;                  // Blake3 hash canônico (64 hex chars)
  version?: string;              // e.g., "1.0.0-core"
  name?: string;                 // Nome descritivo
  description?: string;          // Descrição do que faz
  
  parameters?: Parameter[];      // Inputs da unit
  policies: Policy[];            // ⭐ Core: array de PolicyBit ou PolicyComposition
  inputs?: Parameter[];          // Alias para parameters
  outputs?: OutputDefinition[];  // Outputs
  
  proof?: TranslationProof;      // Opcional: prova de como foi derivado
  materialization?: MaterializationHints;  // Opcional: hints para compilação
}
```

### PolicyBit (Átomo de Decisão)

O "transistor" da computação semântica:

```typescript
interface PolicyBit {
  node_type: "policy_bit";
  id: string;                    // "pb_" + UUID
  hash: string;                  // Blake3 hash
  version?: string;
  name?: string;
  description?: string;
  
  condition: Expression;         // ⭐ Condição booleana (recursiva)
  fallback: boolean;             // Decisão padrão se falhar
}
```

### PolicyComposition (Composição de Políticas)

Agrega múltiplas políticas:

```typescript
interface PolicyComposition {
  node_type: "policy_composition";
  id: string;                    // "pc_" + UUID
  hash: string;
  version?: string;
  name?: string;
  description?: string;
  
  composition_type: "SEQUENTIAL" | "PARALLEL" | "CONDITIONAL";
  policies: string[];            // IDs de PolicyBits/Compositions
  aggregator?: Aggregator;       // Para PARALLEL: como combinar resultados
}

interface Aggregator {
  type: "ALL" | "ANY" | "MAJORITY" | "WEIGHTED";
  weights?: number[];            // Para WEIGHTED
  threshold?: number;            // Para WEIGHTED
}
```

### Expression (AST Recursivo)

A estrutura recursiva que define condições:

```typescript
type Expression =
  | BinaryExpression
  | UnaryExpression
  | FunctionCall
  | ContextReference
  | Literal
  | Conditional;

interface BinaryExpression {
  type: "binary";
  operator: "AND" | "OR" | "EQ" | "NEQ" | "GT" | "LT" | "GTE" | "LTE" | "IN";
  left: Expression;              // ⭐ Recursivo
  right: Expression;             // ⭐ Recursivo
}

interface UnaryExpression {
  type: "unary";
  operator: "NOT" | "EXISTS";
  argument: Expression;          // ⭐ Recursivo
}

interface ContextReference {
  type: "context_ref";
  path: string[];                // e.g., ["user", "account_type"]
  fallback?: any;
}

interface Literal {
  type: "literal";
  value: any;                    // string, number, boolean, null
}

interface FunctionCall {
  type: "function_call";
  function: string;
  arguments: Expression[];       // ⭐ Recursivo
}

interface Conditional {
  type: "conditional";
  test: Expression;              // ⭐ Recursivo
  consequent: Expression;
  alternate: Expression;
}
```

---

## Exemplo Completo: Premium User Access

```json
{
  "tdln_spec_version": "2.0.0",
  "node_type": "semantic_unit",
  "id": "su_550e8400-e29b-41d4-a716-446655440000",
  "hash": "a1b2c3d4e5f67890abcdef1234567890abcdef1234567890abcdef1234567890",
  "version": "1.0.0-core",
  "name": "premium_user_access",
  "description": "Controls access for premium users with active subscriptions",
  
  "parameters": [
    {
      "name": "user_context",
      "type": "context",
      "required": true
    }
  ],
  
  "policies": [
    {
      "node_type": "policy_bit",
      "id": "pb_12345678-1234-1234-1234-123456789012",
      "hash": "d4e5f67890a1b2c3d4e5f67890a1b2c3d4e5f67890a1b2c3d4e5f67890a1b2c3",
      "version": "1.0.0-policybit",
      "name": "is_premium_user",
      "description": "Checks if user has premium account type",
      "condition": {
        "type": "binary",
        "operator": "EQ",
        "left": {
          "type": "context_ref",
          "path": ["user", "account_type"]
        },
        "right": {
          "type": "literal",
          "value": "premium"
        }
      },
      "fallback": false
    },
    {
      "node_type": "policy_bit",
      "id": "pb_23456789-2345-2345-2345-234567890123",
      "hash": "e5f67890a1b2c3d4e5f67890a1b2c3d4e5f67890a1b2c3d4e5f67890a1b2c3d4",
      "version": "1.0.0-policybit",
      "name": "subscription_active",
      "description": "Verifies subscription is currently active",
      "condition": {
        "type": "binary",
        "operator": "AND",
        "left": {
          "type": "function_call",
          "function": "exists",
          "arguments": [
            {
              "type": "context_ref",
              "path": ["user", "subscription", "status"]
            }
          ]
        },
        "right": {
          "type": "binary",
          "operator": "EQ",
          "left": {
            "type": "context_ref",
            "path": ["user", "subscription", "status"]
          },
          "right": {
            "type": "literal",
            "value": "active"
          }
        }
      },
      "fallback": false
    },
    {
      "node_type": "policy_composition",
      "id": "pc_34567890-3456-3456-3456-345678901234",
      "hash": "f67890a1b2c3d4e5f67890a1b2c3d4e5f67890a1b2c3d4e5f67890a1b2c3d4e5",
      "version": "1.0.0-composition",
      "name": "grant_access",
      "description": "Grant access if both premium AND subscription active",
      "composition_type": "PARALLEL",
      "policies": [
        "pb_12345678-1234-1234-1234-123456789012",
        "pb_23456789-2345-2345-2345-234567890123"
      ],
      "aggregator": {
        "type": "ALL"
      }
    }
  ],
  
  "outputs": [
    {
      "name": "access_granted",
      "description": "True if user should be granted access",
      "source_policy": "pc_34567890-3456-3456-3456-345678901234"
    }
  ],
  
  "proof": {
    "proof_type": "translation",
    "source_text": "Allow access for premium users with active subscriptions",
    "source_hash": "abc123def456789abc123def456789abc123def456789abc123def456789abc1",
    "target_core_hash": "a1b2c3d4e5f67890abcdef1234567890abcdef1234567890abcdef1234567890",
    "translation_steps": [
      {
        "sequence": 1,
        "transformation": "parse_natural_language",
        "input_hash": "abc123def456789abc123def456789abc123def456789abc123def456789abc1",
        "output_hash": "bcd234ef567890abcd234ef567890abcd234ef567890abcd234ef567890abcd",
        "rule_applied": "en_US.grammar.access_control",
        "details": {
          "extracted_entities": ["premium users", "active subscriptions"],
          "extracted_conditions": ["account_type == premium", "subscription.status == active"]
        }
      },
      {
        "sequence": 2,
        "transformation": "assist_canonicalization",
        "input_hash": "bcd234ef567890abcd234ef567890abcd234ef567890abcd234ef567890abcd",
        "output_hash": "cde345f6789abcde345f6789abcde345f6789abcde345f6789abcde345f6789",
        "rule_applied": "normalize_boolean_logic",
        "details": {
          "normalization": "AND(is_premium, is_active)"
        }
      },
      {
        "sequence": 3,
        "transformation": "resolve_to_core",
        "input_hash": "cde345f6789abcde345f6789abcde345f6789abcde345f6789abcde345f6789",
        "output_hash": "a1b2c3d4e5f67890abcdef1234567890abcdef1234567890abcdef1234567890",
        "rule_applied": "policy_bit_expansion",
        "details": {
          "created_policies": ["pb_12345678...", "pb_23456789...", "pc_34567890..."]
        }
      }
    ],
    "canonicalization_config": {
      "grammar_version": "1.0.0",
      "policy_library_version": "1.2.3",
      "hash_algorithm": "blake3"
    },
    "timestamp": "2025-01-15T10:30:00Z",
    "signature": "ed25519:1a2b3c4d5e6f7890abcdef..."
  }
}
```

---

## Exemplo Mínimo: Chip-Only

Para máxima performance, sem prova de auditoria:

```json
{
  "tdln_spec_version": "2.0.0",
  "node_type": "semantic_unit",
  "id": "su_abc12345-abcd-1234-abcd-1234567890ab",
  "hash": "1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
  "version": "1.0.0-core",
  "name": "simple_threshold_check",
  "description": "Minimal TDLN for chip compilation - checks if value > 100",
  
  "policies": [
    {
      "node_type": "policy_bit",
      "id": "pb_threshold_100",
      "hash": "567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234",
      "name": "above_threshold",
      "condition": {
        "type": "binary",
        "operator": "GT",
        "left": {
          "type": "context_ref",
          "path": ["input", "value"]
        },
        "right": {
          "type": "literal",
          "value": 100
        }
      },
      "fallback": false
    }
  ],
  
  "outputs": [
    {
      "name": "threshold_exceeded",
      "source_policy": "pb_threshold_100"
    }
  ],
  
  "materialization": {
    "target": "metal",
    "optimization_level": 3,
    "semantic_ops": [
      {
        "type": "PolicyEval",
        "params": {
          "operation": "comparison",
          "comparison_type": "greater_than",
          "threshold": 100
        }
      }
    ],
    "performance_hints": {
      "estimated_gflops": 0.001,
      "estimated_latency_ms": 0.00002,
      "memory_footprint_mb": 0.1
    },
    "integrity": {
      "enabled": true,
      "checksum_algorithm": "crc32"
    }
  }
}
```

---

## Modos de Uso

### 1. Desenvolvimento (Auditoria Completa)

**Arquivo**: SemanticUnit com proof completo

```json
{
  "tdln_spec_version": "2.0.0",
  "node_type": "semantic_unit",
  "policies": [...],
  "proof": {
    "proof_type": "translation",
    "translation_steps": [...],
    "signature": "..."
  }
}
```

**Workflow**:
1. TDLN Pure valida proof (Blake3 + Ed25519)
2. TDLN Pure gera traces NDJSON
3. TDLN Chip extrai policies[], compila

**Overhead**: ~1.8ms (audit) + execução  
**Quando usar**: Desenvolvimento, compliance, debugging

---

### 2. Produção (Performance Máxima)

**Arquivo**: SemanticUnit sem proof

```json
{
  "tdln_spec_version": "2.0.0",
  "node_type": "semantic_unit",
  "policies": [...],
  "materialization": {
    "integrity": {"enabled": true}  // CRC32 ~20ns
  }
}
```

**Workflow**:
1. TDLN Chip lê diretamente
2. TDLN Chip valida integridade (CRC32 hardware)
3. TDLN Chip executa

**Overhead**: ~20ns (CRC32) + execução  
**Speedup**: ~90x mais rápido que modo completo (audit)

**Quando usar**: Produção após validação em dev

---

## Validação

### Validar Arquivo .tdln

```bash
# Usando JSON Schema validator
jsonschema -i arquivo.tdln specs/tdln-core-v2.0.schema.json

# Usando TDLN Pure CLI (futuro)
tdln validate arquivo.tdln
```

### Campos Obrigatórios

```typescript
interface TDLNMinimal {
  tdln_spec_version: string;    // ✅ "2.0.0"
  node_type: "semantic_unit";   // ✅ Sempre
  id: string;                   // ✅ "su_" + UUID
  hash: string;                 // ✅ Blake3 64 hex
  policies: Policy[];           // ✅ Pelo menos 1 policy
}
```

---

## Transporte e Compatibilidade

### Portabilidade

```
┌──────────────────────────────────────────────────────┐
│ Sistema A (TDLN Pure + Chip)                         │
│   1. Cria arquivo.tdln (SemanticUnit completo)       │
│   2. Valida contra schema                            │
│   3. Assina proof (Ed25519)                          │
│   4. Exporta arquivo.tdln                            │
└──────────────────────────────────────────────────────┘
                       ↓ HTTP/gRPC/File
┌──────────────────────────────────────────────────────┐
│ Sistema B (TDLN Chip only)                           │
│   1. Recebe arquivo.tdln                             │
│   2. Ignora proof (não precisa)                      │
│   3. Extrai policies[]                               │
│   4. Valida CRC32 (se materialization.integrity ON)  │
│   5. Compila e executa                               │
└──────────────────────────────────────────────────────┘
```

---

## Performance

### Overhead por Componente

| Componente | Overhead | Quando |
|------------|----------|--------|
| **SemanticUnit metadata** | ~0ns | Sempre (só leitura) |
| **policies[]** | Execução | Sempre (core) |
| **proof** | ~1.8ms | Se TDLN Pure valida |
| **materialization.integrity** | ~20ns | Se enabled (CRC32 hardware) |

### Comparação de Modos

| Modo | Latência Total | Speedup vs Full | Proteção |
|------|---------------|-----------------|----------|
| **Full Audit** (c/ proof) | 1.8ms + exec | 1.0x (baseline) | Workflow + Data |
| **Chip Only** (c/ integrity) | 20ns + exec | ~90x | Data only |
| **No Integrity** | exec | ~90x | Nenhuma |

**Recomendação**:
- Desenvolvimento: Full Audit (com proof) - máxima visibilidade
- Produção: Chip Only com integrity (~20ns) - balanço ideal
- Benchmarks: No Integrity - performance pura

---

## Segurança

### Separação de Camadas

```
WORKFLOW AUDIT (TDLN Pure - proof)
├─ Blake3 hashing (~100µs)
├─ Ed25519 signature (~1ms)
├─ Translation steps tracing
└─ Propósito: Compliance, debugging, provenance

DATA INTEGRITY (TDLN Chip - materialization.integrity)
├─ CRC32 hardware (~20ns)
├─ ECC memory protection
└─ Propósito: Detectar corrupção de memória, bit flips
```

**Filosofia**: 
- TDLN Pure (proof) = "Este workflow aconteceu conforme esperado?"
- TDLN Chip (integrity) = "Estes dados estão corretos?"

Ambas camadas são **independentes** e servem propósitos diferentes.

---

## Referências

- [JSON Schema](../specs/tdln-core-v2.0.schema.json) - Especificação completa
- [Exemplos](../examples/) - premium-user-access.tdln.json, chip-minimal.tdln.json
- [CANONIZACAO_DEFINITIVA.md](../../TDLN%20DEEP/CANONIZACAO_DEFINITIVA.md) - Documento de design
- [PLANO_DIVISAO_REPOS.md](../../TDLN%20DEEP/PLANO_DIVISAO_REPOS.md) - Divisão de responsabilidades
- [Chip as Code.md](../../Chip%20as%20Code.md) - Documento original

---

## Versionamento

```
v2.0 (atual)  - Formato SemanticUnit fractal
v1.5          - Formato Pure-only (obsoleto)
v1.0          - Formato inicial (experimental)
```

**Breaking changes**: v2.0 usa estrutura fractal (SemanticUnit → PolicyBit → Expression), incompatível com v1.x

---

**Questões?** Ver exemplos em [`examples/`](../examples/) ou abrir issue no GitHub.
