# TDLN API Reference

> **Referência completa** dos tipos e estruturas do formato `.tdln` v2.0

---

## 📑 Índice

1. [SemanticUnit](#semanticunit) (raiz)
2. [PolicyBit](#policybit)
3. [PolicyComposition](#policycomposition)
4. [Expression](#expression)
5. [TranslationProof](#translationproof)
6. [MaterializationHints](#materializationhints)

---

## SemanticUnit

**Nó raiz** de um arquivo `.tdln`. Representa uma unidade semântica completa com políticas.

### Schema

```json
{
  "tdln_spec_version": "2.0.0",     // required: string (semantic version)
  "node_type": "semantic_unit",      // required: literal
  "id": "su_...",                    // required: UUID prefixado
  "hash": "blake3_...",              // required: Blake3 hash canônico
  
  "policies": [...],                 // required: array de PolicyBit | PolicyComposition
  "proof": {...},                    // optional: TranslationProof (auditoria)
  "materialization": {...}           // optional: MaterializationHints (performance)
}
```

### Propriedades

| Campo | Tipo | Obrigatório | Descrição |
|-------|------|-------------|-----------|
| `tdln_spec_version` | `string` | ✅ | Versão da spec (e.g., `"2.0.0"`) |
| `node_type` | `"semantic_unit"` | ✅ | Tipo do nó (literal) |
| `id` | `string` | ✅ | UUID com prefixo `su_` |
| `hash` | `string` | ✅ | Blake3 hash canônico (hex) |
| `policies` | `array` | ✅ | Lista de políticas (min 1) |
| `proof` | `object` | ❌ | Prova de tradução (auditoria) |
| `materialization` | `object` | ❌ | Hints de compilação (performance) |

### Exemplo

```json
{
  "tdln_spec_version": "2.0.0",
  "node_type": "semantic_unit",
  "id": "su_550e8400-e29b-41d4-a716-446655440000",
  "hash": "blake3_3f5e2a...",
  
  "policies": [
    {
      "node_type": "policy_bit",
      "id": "pb_auth",
      "hash": "blake3_...",
      "condition": {...}
    }
  ]
}
```

---

## PolicyBit

**Átomo de decisão** — avalia uma expressão booleana simples.

### Schema

```json
{
  "node_type": "policy_bit",         // required: literal
  "id": "pb_...",                    // required: prefixo pb_
  "hash": "blake3_...",              // required: Blake3 hash
  
  "condition": {...}                 // required: Expression
}
```

### Propriedades

| Campo | Tipo | Obrigatório | Descrição |
|-------|------|-------------|-----------|
| `node_type` | `"policy_bit"` | ✅ | Tipo do nó (literal) |
| `id` | `string` | ✅ | ID único (prefixo `pb_`) |
| `hash` | `string` | ✅ | Blake3 hash da condição |
| `condition` | `object` | ✅ | Expressão booleana (ver [Expression](#expression)) |

### Exemplo

```json
{
  "node_type": "policy_bit",
  "id": "pb_role_check",
  "hash": "blake3_a1b2c3...",
  
  "condition": {
    "type": "binary",
    "operator": "EQ",
    "left": {"type": "context_ref", "path": ["user", "role"]},
    "right": {"type": "literal", "value": "admin"}
  }
}
```

---

## PolicyComposition

**Composição de políticas** — combina múltiplos PolicyBits com agregador (AND/OR/ALL/ANY).

### Schema

```json
{
  "node_type": "policy_composition",  // required: literal
  "id": "pc_...",                     // required: prefixo pc_
  "hash": "blake3_...",               // required: Blake3 hash
  
  "policies": ["pb_id1", "pb_id2"],   // required: array de IDs
  "aggregator": {...}                 // required: objeto agregador
}
```

### Propriedades

| Campo | Tipo | Obrigatório | Descrição |
|-------|------|-------------|-----------|
| `node_type` | `"policy_composition"` | ✅ | Tipo do nó (literal) |
| `id` | `string` | ✅ | ID único (prefixo `pc_`) |
| `hash` | `string` | ✅ | Blake3 hash da composição |
| `policies` | `string[]` | ✅ | IDs das políticas (min 2) |
| `aggregator` | `object` | ✅ | Tipo de agregação |

### Aggregator Types

```json
// AND lógico (todas devem passar)
{"type": "ALL"}

// OR lógico (pelo menos uma deve passar)
{"type": "ANY"}

// Votação (threshold personalizado)
{"type": "THRESHOLD", "min_votes": 2}

// Sequencial (executar em ordem)
{"type": "SEQUENTIAL"}

// Paralelo com timeout
{"type": "PARALLEL", "timeout_ms": 1000}
```

### Exemplo

```json
{
  "node_type": "policy_composition",
  "id": "pc_premium_access",
  "hash": "blake3_d4e5f6...",
  
  "policies": ["pb_role_check", "pb_quota_check"],
  "aggregator": {"type": "ALL"}
}
```

---

## Expression

**Expressão recursiva** — representa condições booleanas.

### Tipos

#### 1. BinaryExpression

Operação binária (EQ, NEQ, GT, LT, AND, OR, etc).

```json
{
  "type": "binary",
  "operator": "EQ" | "NEQ" | "GT" | "LT" | "GTE" | "LTE" | "AND" | "OR",
  "left": Expression,
  "right": Expression
}
```

#### 2. UnaryExpression

Operação unária (NOT).

```json
{
  "type": "unary",
  "operator": "NOT",
  "operand": Expression
}
```

#### 3. ContextReference

Referência a contexto externo (e.g., `user.role`).

```json
{
  "type": "context_ref",
  "path": ["user", "role"]
}
```

#### 4. Literal

Valor constante.

```json
{
  "type": "literal",
  "value": "admin" | 100 | true | null
}
```

### Exemplo Completo

```json
{
  "type": "binary",
  "operator": "AND",
  "left": {
    "type": "binary",
    "operator": "EQ",
    "left": {"type": "context_ref", "path": ["user", "role"]},
    "right": {"type": "literal", "value": "admin"}
  },
  "right": {
    "type": "binary",
    "operator": "LT",
    "left": {"type": "context_ref", "path": ["request", "quota"]},
    "right": {"type": "literal", "value": 1000}
  }
}
```

---

## TranslationProof

**Prova de tradução** — auditoria completa do workflow (TDLN Pure).

### Schema

```json
{
  "proof_type": "translation",       // required: tipo de prova
  "translation_steps": [...],        // required: array de steps
  "source_hash": "blake3_...",       // required: hash do input
  "target_hash": "blake3_...",       // required: hash do output
  "provenance": {...},               // optional: metadados de criação
  "signature": "ed25519_..."         // optional: assinatura Ed25519
}
```

### Propriedades

| Campo | Tipo | Obrigatório | Descrição |
|-------|------|-------------|-----------|
| `proof_type` | `"translation"` | ✅ | Tipo de prova |
| `translation_steps` | `array` | ✅ | Passos da tradução |
| `source_hash` | `string` | ✅ | Hash do input (Blake3) |
| `target_hash` | `string` | ✅ | Hash do output (Blake3) |
| `provenance` | `object` | ❌ | Metadados (created_by, created_at) |
| `signature` | `string` | ❌ | Assinatura Ed25519 (hex) |

### Exemplo

```json
{
  "proof_type": "translation",
  "translation_steps": [
    {
      "stage": "parse",
      "input_hash": "blake3_abc...",
      "output_hash": "blake3_def...",
      "duration_ms": 1.2
    },
    {
      "stage": "policy",
      "input_hash": "blake3_def...",
      "output_hash": "blake3_ghi...",
      "duration_ms": 0.5
    }
  ],
  "source_hash": "blake3_abc...",
  "target_hash": "blake3_ghi...",
  "signature": "ed25519_sig..."
}
```

---

## MaterializationHints

**Hints de compilação** — otimizações para TDLN Chip.

### Schema

```json
{
  "data_integrity": {...},           // optional: configuração de integridade
  "backend_specific": {...}          // optional: configs por backend
}
```

### Propriedades

#### `data_integrity`

```json
{
  "checksum_type": "crc32" | "sha256",
  "enable_ecc": true | false
}
```

#### `backend_specific`

```json
{
  "verilog": {
    "data_width": 32,
    "fractional_bits": 16,
    "target_frequency_mhz": 1000
  },
  "metal": {
    "threadgroup_size": [16, 16],
    "shared_memory_kb": 32
  },
  "cuda": {
    "block_size": [16, 16],
    "shared_memory_bytes": 49152
  }
}
```

### Exemplo

```json
{
  "data_integrity": {
    "checksum_type": "crc32",
    "enable_ecc": true
  },
  "backend_specific": {
    "metal": {
      "threadgroup_size": [16, 16]
    }
  }
}
```

---

## 🔐 Hashing e Assinatura

### Blake3 Hash

**Algoritmo**: Blake3 (256-bit)  
**Formato**: Hex lowercase (64 caracteres)  
**Prefixo**: `blake3_`

```bash
# Exemplo
blake3_3f5e2a1b9c8d7e6f4a3b2c1d0e9f8a7b6c5d4e3f2a1b0c9d8e7f6a5b4c3d2e1f
```

### Ed25519 Signature

**Algoritmo**: Ed25519 (512-bit)  
**Formato**: Hex lowercase (128 caracteres)  
**Prefixo**: `ed25519_`

```bash
# Exemplo
ed25519_a1b2c3d4...f0e1d2c3 (128 chars)
```

---

## 📊 Overhead de Performance

| Componente | Tempo | Quando usar |
|------------|-------|-------------|
| **Blake3 hash** | ~100µs | Sempre (integridade) |
| **Ed25519 signature** | ~1ms | Auditoria crítica |
| **Translation proof** | ~800µs | Debug/compliance |
| **CRC32 (chip)** | ~20ns | Produção (chip) |

**Recomendação**:
- **Dev/Debug**: Proof completo (~1.8ms overhead)
- **Produção**: Chip direto (~20ns integrity)
- **Compliance**: Proof + signature (~2.8ms overhead)

---

## ✅ Validação

### Usando JSON Schema

```bash
# Python
pip install jsonschema
jsonschema -i arquivo.tdln specs/tdln-core-v2.0.schema.json

# Node.js
npm install -g ajv-cli
ajv validate -s specs/tdln-core-v2.0.schema.json -d arquivo.tdln
```

### Validação Manual

```bash
# Verificar versão da spec
jq '.tdln_spec_version' arquivo.tdln

# Listar PolicyBits
jq '.policies[] | select(.node_type == "policy_bit") | .id' arquivo.tdln

# Validar hashes (Blake3)
jq '.hash' arquivo.tdln | grep -E '^blake3_[0-9a-f]{64}$'
```

---

## 🔗 Referências

- [TDLN_FORMAT.md](./TDLN_FORMAT.md) — Especificação completa
- [tdln-core-v2.0.schema.json](../specs/tdln-core-v2.0.schema.json) — JSON Schema canônico
- [QUICKSTART.md](./QUICKSTART.md) — Guia rápido
- [ARCHITECTURE.md](./ARCHITECTURE.md) — Arquitetura do sistema

---

**TDLN API Reference** — v2.0.0 🎯
