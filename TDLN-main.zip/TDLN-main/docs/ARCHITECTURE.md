# TDLN Pure Architecture

**Version**: 2.0.0  
**Last Updated**: December 16, 2025

---

## Overview

TDLN Pure is the **protocol layer** of the TDLN ecosystem. It defines the canonical `.tdln` format, processing pipeline, and audit infrastructure.

```
┌─────────────────────────────────────────────────────────────┐
│                      TDLN Ecosystem                          │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  TDLN Pure (MIT)         ← Protocol & Format                 │
│  TDLN-Chip (MIT)         ← Compiler (Metal/CUDA/Verilog)     │
│  TDLN-API (Proprietary)  ← LLM Service & Optimization        │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

This document describes the **internal architecture of TDLN Pure**.

---

## Core Concepts

### The Fractal Principle

TDLN Pure preserves the **fractal nature** of the TDLN Core invention:

```
SemanticUnit (root)
  ├─ node_type: "semantic_unit"
  ├─ id: "su_uuid"
  ├─ hash: "blake3_..."
  │
  └─ policies[] (array)
      ├─ PolicyBit
      │   ├─ node_type: "policy_bit"
      │   ├─ id: "pb_uuid"
      │   ├─ hash: "blake3_..."
      │   └─ condition: Expression (recursive)
      │       ├─ BinaryExpression
      │       │   ├─ left: Expression
      │       │   └─ right: Expression
      │       ├─ UnaryExpression
      │       │   └─ operand: Expression
      │       └─ FunctionCall
      │           └─ arguments: Expression[]
      │
      └─ PolicyComposition
          ├─ node_type: "policy_composition"
          ├─ id: "pc_uuid"
          ├─ hash: "blake3_..."
          └─ policies[] (recursive)
```

**Key insight**: Every level has `node_type`, `id`, `hash` — self-describing at all scales.

---

## Processing Pipeline

TDLN Pure defines a **5-stage pipeline**:

```
Input → [1] → [2] → [3] → [4] → [5] → Output
        ↓     ↓     ↓     ↓     ↓
      Parse Assist Resolve Policy Render
```

### Stage 1: Parse

**Input**: Raw text, JSON, or structured data  
**Output**: Normalized intermediate representation  
**Grammar**: Defined in `grammar/in/*.yaml`

**Responsibility**:
- Parse input format
- Validate syntax
- Extract semantic intent

### Stage 2: Assist (Optional)

**Input**: Parsed data  
**Output**: Enhanced data with suggestions  
**Context**: LLM assistance, autocomplete

**Responsibility**:
- Suggest completions
- Resolve ambiguities
- Validate against constraints

### Stage 3: Resolve

**Input**: Parsed/assisted data  
**Output**: Fully-qualified SemanticUnit  
**Process**: Context resolution, variable expansion

**Responsibility**:
- Resolve context references
- Expand variables
- Type checking

### Stage 4: Policy

**Input**: SemanticUnit  
**Output**: SemanticUnit + policy evaluation results  
**Policies**: Defined in `policies/*.yaml`

**Responsibility**:
- Apply policies to SemanticUnit
- Evaluate conditions
- Determine allow/deny

### Stage 5: Render

**Input**: SemanticUnit + evaluation results  
**Output**: Final format (JSON, text, etc.)  
**Grammar**: Defined in `grammar/out/*.yaml`

**Responsibility**:
- Format output
- Apply templates
- Serialize to target format

---

## Audit Infrastructure

TDLN Pure provides **optional auditability** via the `proof` field.

### Blake3 Hashing

**Purpose**: Content integrity  
**Algorithm**: BLAKE3 (cryptographically secure)  
**Performance**: ~1GB/s single-threaded

**Hash structure**:
```json
{
  "hash": "blake3_a1b2c3d4e5f67890..."
}
```

Each node (SemanticUnit, PolicyBit, PolicyComposition, Expression) has its own hash computed from its content.

### Ed25519 Signatures

**Purpose**: Provenance verification  
**Algorithm**: Ed25519 (EdDSA)  
**Key size**: 32 bytes (public), 64 bytes (private)

**Signature structure**:
```json
{
  "provenance": {
    "signature": "ed25519_signature_base64",
    "signer": "identity_or_public_key",
    "timestamp": "2025-12-16T10:30:00Z"
  }
}
```

### Translation Proof

**Purpose**: Workflow audit trail  
**Format**: Array of translation steps

**Proof structure**:
```json
{
  "proof": {
    "proof_type": "translation",
    "translation_steps": [
      {
        "step_id": "ts_uuid",
        "description": "LLM initial output",
        "input_hash": "blake3_...",
        "output_hash": "blake3_...",
        "timestamp": "2025-12-16T10:30:00Z"
      }
    ],
    "provenance": { ... }
  }
}
```

### Trace Manifests (NDJSON)

**Purpose**: Streaming audit logs  
**Format**: Newline-Delimited JSON (NDJSON)

**Example trace**:
```ndjson
{"event":"pack_activated","pack":"auth_policies","timestamp":"2025-12-16T10:30:00Z"}
{"event":"translation_step","step_id":"ts_001","hash":"blake3_..."}
{"event":"pack_deactivated","pack":"auth_policies","timestamp":"2025-12-16T10:31:00Z"}
```

**Use cases**:
- Compliance logging
- Event sourcing
- Debugging workflows

---

## Performance Characteristics

### TDLN Pure Overhead

**Configuration**: Full audit mode (Blake3 + Ed25519 + traces)

| Operation | Time | Notes |
|-----------|------|-------|
| Blake3 hash (1MB) | ~1ms | Single-threaded |
| Ed25519 sign | ~50μs | Per signature |
| Ed25519 verify | ~100μs | Per signature |
| JSON serialize | ~0.5ms | 500-line .tdln file |
| **Total overhead** | **~1.8ms** | Typical workflow |

### TDLN-Chip Overhead (for comparison)

**Configuration**: Minimal integrity (CRC32 only)

| Operation | Time | Notes |
|-----------|------|-------|
| CRC32 check | ~20ns | Hardware accelerated |
| Compilation | 0ms | Offline, not runtime |
| **Total overhead** | **~20ns** | Production runtime |

**Trade-off**:
- **TDLN Pure**: Full auditability (~1.8ms)
- **TDLN-Chip**: Maximum performance (~20ns)

Choose based on requirements: compliance vs performance.

---

## Data Structures

### SemanticUnit (Root)

```typescript
interface SemanticUnit {
  tdln_spec_version: "2.0.0";
  node_type: "semantic_unit";
  id: string; // "su_uuid"
  hash: string; // "blake3_..."
  
  policies: (PolicyBit | PolicyComposition)[];
  
  proof?: TranslationProof; // Optional
  materialization_hints?: MaterializationHints; // Optional
}
```

### PolicyBit (Atomic Policy)

```typescript
interface PolicyBit {
  node_type: "policy_bit";
  id: string; // "pb_uuid"
  hash: string;
  
  condition: Expression; // Recursive
  fallback: Expression;
  
  metadata?: {
    description?: string;
    tags?: string[];
  };
}
```

### PolicyComposition (Aggregation)

```typescript
interface PolicyComposition {
  node_type: "policy_composition";
  id: string; // "pc_uuid"
  hash: string;
  
  composition_type: "AND" | "OR" | "CUSTOM";
  policies: (PolicyBit | PolicyComposition)[];
  aggregator?: Expression; // For CUSTOM
  
  metadata?: {
    description?: string;
  };
}
```

### Expression (Recursive)

```typescript
type Expression =
  | BinaryExpression
  | UnaryExpression
  | FunctionCall
  | ContextReference
  | Literal
  | Conditional;

interface BinaryExpression {
  type: "binary";
  operator: "EQ" | "NEQ" | "GT" | "LT" | "AND" | "OR";
  left: Expression;
  right: Expression;
}

// ... (see TDLN_FORMAT.md for complete definition)
```

---

## Repository Structure

```
TDLN/
├── specs/                    # ⭐ Canonical specifications
│   └── tdln-core-v2.0.schema.json
│
├── docs/                     # Documentation
│   ├── TDLN_FORMAT.md        # Format specification
│   ├── ARCHITECTURE.md       # This file
│   └── QUICKSTART.md         # Tutorial
│
├── examples/                 # Reference examples
│   ├── premium-user-access.tdln.json  # Complete
│   ├── chip-minimal.tdln.json         # Minimal
│   └── README.examples.md
│
├── grammar/                  # Input/output grammars
│   ├── in/
│   └── out/
│
├── policies/                 # Policy examples
│
├── scripts/                  # Utilities
│   ├── validate-all.sh       # Validate .tdln files
│   ├── check-integrity.sh    # Check hashes
│   └── format-check.sh       # Format validation
│
└── integrations/             # Optional integrations
    └── json-atomic/
```

---

## Integration with TDLN-Chip

**Separation of concerns**:

| Aspect | TDLN Pure | TDLN-Chip |
|--------|-----------|-----------|
| **Defines** | Protocol format | Compiler implementation |
| **Reads** | Full SemanticUnit | `policies[]` + `materialization_hints` |
| **Focus** | Auditability | Performance |
| **Overhead** | ~1.8ms (Blake3 + Ed25519) | ~20ns (CRC32) |
| **Output** | .tdln.json | Metal/CUDA/Verilog |

**Flow**:
```
1. TDLN Pure → Generate .tdln.json (with proof)
2. TDLN-Chip → Read .tdln.json → Compile to hardware
3. Hardware → Execute with ~20ns integrity check
```

**Proof handling**:
- TDLN Pure: Generates and validates proof
- TDLN-Chip: Ignores proof (not needed for compilation)

---

## Versioning Strategy

### Semantic Versioning

- **MAJOR** (3.0.0): Breaking changes to format
- **MINOR** (2.1.0): New optional fields, backward compatible
- **PATCH** (2.0.1): Bug fixes, clarifications

### Version Field

Every `.tdln` file has:
```json
{
  "tdln_spec_version": "2.0.0"
}
```

**Backward compatibility**:
- v2.x parsers MUST accept v2.0 files
- v2.x parsers SHOULD accept v1.x files (deprecated)
- v3.0 may break compatibility (with migration guide)

---

## Security Considerations

### Hash Integrity

- **Algorithm**: BLAKE3 (cryptographically secure)
- **Collision resistance**: 2^128 operations
- **Pre-image resistance**: 2^256 operations

**Use case**: Detect tampering in `.tdln` files

### Signature Verification

- **Algorithm**: Ed25519 (EdDSA on Curve25519)
- **Security level**: ~128-bit
- **Key management**: User responsibility

**Use case**: Verify authorship and integrity

### Threat Model

**Protected against**:
- ✅ Tampering (hash verification)
- ✅ Impersonation (signature verification)
- ✅ Replay attacks (timestamps in provenance)

**Not protected against**:
- ❌ Key compromise (use secure key storage)
- ❌ Side-channel attacks (implementation-dependent)
- ❌ Quantum attacks (Ed25519 not post-quantum)

---

## Future Work

### Planned Features

1. **Policy pack repository**: Centralized library of reusable policies
2. **Grammar extensions**: Support for more input/output formats
3. **Performance optimizations**: Parallel hash computation
4. **Tooling**: CLI for validation, signing, verification
5. **Integrations**: Python/Rust/JavaScript libraries

### Research Directions

1. **Post-quantum signatures**: Transition to lattice-based crypto
2. **Zero-knowledge proofs**: Private policy evaluation
3. **Distributed validation**: Blockchain-based audit trails

---

## References

- **BLAKE3**: https://github.com/BLAKE3-team/BLAKE3
- **Ed25519**: https://ed25519.cr.yp.to/
- **JSON Schema**: https://json-schema.org/
- **Semantic Versioning**: https://semver.org/

---

## Contributing

See [CONTRIBUTING.md](../CONTRIBUTING.md) for how to contribute to TDLN Pure architecture.

---

**TDLN Pure** — Protocol-first, fractal-native, audit-ready. 🎯
