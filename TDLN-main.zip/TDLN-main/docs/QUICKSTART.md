# TDLN Pure — Quick Start Guide

Get started with TDLN Pure in 5 minutes! 🚀

---

## 📦 What You'll Need

- **Python 3.7+** (for validation)
- **jq** (for JSON manipulation)
- **Text editor** (VS Code, vim, etc.)

Optional:
- **b3sum** (for hash verification): `cargo install b3sum`
- **TDLN-Chip** (for hardware compilation)

---

## ⚡ Quick Installation

### Install Validation Tools

```bash
# Python jsonschema validator
pip install jsonschema

# jq (JSON processor)
# macOS
brew install jq

# Linux
sudo apt install jq

# Windows (via Chocolatey)
choco install jq
```

### Clone TDLN Pure

```bash
git clone https://github.com/your-org/tdln-pure.git
cd tdln-pure
```

---

## 🎯 Your First .tdln File

### Step 1: Create a Simple Policy

Create `my-first.tdln.json`:

```json
{
  "tdln_spec_version": "2.0.0",
  "node_type": "semantic_unit",
  "id": "su_550e8400-e29b-41d4-a716-446655440000",
  "hash": "blake3_placeholder",
  
  "policies": [
    {
      "node_type": "policy_bit",
      "id": "pb_123e4567-e89b-12d3-a456-426614174000",
      "hash": "blake3_placeholder",
      "condition": {
        "type": "binary",
        "operator": "EQ",
        "left": {
          "type": "context_ref",
          "path": ["user", "role"]
        },
        "right": {
          "type": "literal",
          "value": "admin"
        }
      },
      "fallback": {
        "type": "literal",
        "value": false
      },
      "metadata": {
        "description": "Check if user is admin"
      }
    }
  ]
}
```

This policy checks: **Is the user's role "admin"?**

### Step 2: Validate Your File

```bash
# Validate against the schema
jsonschema -i my-first.tdln.json specs/tdln-core-v2.0.schema.json
```

**Expected output**: `my-first.tdln.json is valid under the given schema`

✅ Success! You've created a valid `.tdln` file.

---

## 🔍 Exploring Examples

### View the Complete Example

```bash
# Pretty-print the complete example
jq . examples/premium-user-access.tdln.json

# Extract just the policies
jq '.policies' examples/premium-user-access.tdln.json

# Count policies
jq '.policies | length' examples/premium-user-access.tdln.json
```

### View the Minimal Example

```bash
# View chip-optimized example
jq . examples/chip-minimal.tdln.json

# Check for proof (should be null)
jq '.proof' examples/chip-minimal.tdln.json
```

---

## 🧪 Using the Scripts

### Validate All Examples

```bash
./scripts/validate-all.sh
```

**Output**:
```
🔍 Validating TDLN files against schema...

✅ premium-user-access.tdln.json
✅ chip-minimal.tdln.json

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Total: 2 | Passed: 2 | Failed: 0
🎉 All validations passed!
```

### Check Hash Integrity

```bash
./scripts/check-integrity.sh
```

### Format Check

```bash
./scripts/format-check.sh
```

---

## 🏗️ Building Complex Policies

### Multiple Conditions (AND Logic)

```json
{
  "node_type": "policy_composition",
  "id": "pc_uuid",
  "hash": "blake3_placeholder",
  "composition_type": "AND",
  "policies": [
    {
      "node_type": "policy_bit",
      "id": "pb_check_premium",
      "hash": "blake3_placeholder",
      "condition": {
        "type": "binary",
        "operator": "EQ",
        "left": {"type": "context_ref", "path": ["user", "tier"]},
        "right": {"type": "literal", "value": "premium"}
      },
      "fallback": {"type": "literal", "value": false}
    },
    {
      "node_type": "policy_bit",
      "id": "pb_check_quota",
      "hash": "blake3_placeholder",
      "condition": {
        "type": "binary",
        "operator": "GT",
        "left": {"type": "context_ref", "path": ["user", "quota"]},
        "right": {"type": "literal", "value": 0}
      },
      "fallback": {"type": "literal", "value": false}
    }
  ],
  "metadata": {
    "description": "Premium user with available quota"
  }
}
```

This checks: **Is premium AND has quota > 0**

### Nested Expressions

```json
{
  "type": "binary",
  "operator": "AND",
  "left": {
    "type": "binary",
    "operator": "EQ",
    "left": {"type": "context_ref", "path": ["user", "verified"]},
    "right": {"type": "literal", "value": true}
  },
  "right": {
    "type": "binary",
    "operator": "GT",
    "left": {"type": "context_ref", "path": ["user", "age"]},
    "right": {"type": "literal", "value": 18}
  }
}
```

This checks: **(verified == true) AND (age > 18)**

---

## 🔐 Adding Audit Proof

### Basic Proof Structure

```json
{
  "tdln_spec_version": "2.0.0",
  "node_type": "semantic_unit",
  "id": "su_uuid",
  "hash": "blake3_placeholder",
  
  "policies": [ ... ],
  
  "proof": {
    "proof_type": "translation",
    "translation_steps": [
      {
        "step_id": "ts_001",
        "description": "Initial LLM output",
        "input_hash": "blake3_input_hash",
        "output_hash": "blake3_output_hash",
        "timestamp": "2025-12-16T10:30:00Z"
      },
      {
        "step_id": "ts_002",
        "description": "Human review and approval",
        "input_hash": "blake3_output_hash",
        "output_hash": "blake3_final_hash",
        "timestamp": "2025-12-16T10:35:00Z"
      }
    ],
    "provenance": {
      "signature": "ed25519_signature_here",
      "signer": "your-identity",
      "timestamp": "2025-12-16T10:35:00Z"
    }
  }
}
```

**Use case**: Compliance, auditability, workflow tracking

---

## 🎨 Common Patterns

### Pattern 1: Simple Authorization

```json
{
  "condition": {
    "type": "binary",
    "operator": "EQ",
    "left": {"type": "context_ref", "path": ["user", "role"]},
    "right": {"type": "literal", "value": "admin"}
  }
}
```

### Pattern 2: Range Check

```json
{
  "condition": {
    "type": "binary",
    "operator": "AND",
    "left": {
      "type": "binary",
      "operator": "GTE",
      "left": {"type": "context_ref", "path": ["value"]},
      "right": {"type": "literal", "value": 0}
    },
    "right": {
      "type": "binary",
      "operator": "LTE",
      "left": {"type": "context_ref", "path": ["value"]},
      "right": {"type": "literal", "value": 100}
    }
  }
}
```

Checks: **0 <= value <= 100**

### Pattern 3: String Contains

```json
{
  "condition": {
    "type": "function_call",
    "function": "string_contains",
    "arguments": [
      {"type": "context_ref", "path": ["email"]},
      {"type": "literal", "value": "@company.com"}
    ]
  }
}
```

Checks: **email contains "@company.com"**

---

## 🔗 Integration with TDLN-Chip

Once you have a valid `.tdln` file, compile it to hardware:

### Compile to Metal (Apple GPU)

```bash
tdln-chip compile my-first.tdln.json --target metal -o output.metal
```

### Compile to CUDA (NVIDIA GPU)

```bash
tdln-chip compile my-first.tdln.json --target cuda -o output.cu
```

### Compile to Verilog (FPGA/ASIC)

```bash
tdln-chip compile my-first.tdln.json --target verilog -o output.v
```

See [TDLN-Chip documentation](https://github.com/your-org/tdln-chip) for details.

---

## 📚 Next Steps

### Learn More

1. **Complete Format**: Read [TDLN_FORMAT.md](./TDLN_FORMAT.md)
2. **Architecture**: Read [ARCHITECTURE.md](./ARCHITECTURE.md)
3. **Examples**: Explore [examples/](../examples/)

### Advanced Topics

- **Custom aggregators**: Write custom policy composition logic
- **Materialization hints**: Optimize for specific backends
- **Proof generation**: Implement automated audit trails
- **Grammar extensions**: Support new input/output formats

### Get Help

- **Issues**: [GitHub Issues](https://github.com/your-org/tdln-pure/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-org/tdln-pure/discussions)
- **Contributing**: [CONTRIBUTING.md](../CONTRIBUTING.md)

---

## 💡 Pro Tips

### 1. Use UUIDs for IDs

```bash
# Generate UUID v4
python -c "import uuid; print(f'su_{uuid.uuid4()}')"
```

### 2. Validate During Development

```bash
# Watch and validate on file change
watch -n 1 jsonschema -i my-first.tdln.json specs/tdln-core-v2.0.schema.json
```

### 3. Use jq for Debugging

```bash
# Extract specific fields
jq '.policies[0].condition' my-first.tdln.json

# Filter policies by description
jq '.policies[] | select(.metadata.description | contains("admin"))' my-first.tdln.json
```

### 4. Template with Variables

```bash
# Use jq to fill template
jq --arg role "admin" '.policies[0].condition.right.value = $role' template.tdln.json
```

---

## 🎯 Common Errors

### Error: "is not valid under the given schema"

**Cause**: Missing required field or wrong type

**Fix**: Check schema requirements in `specs/tdln-core-v2.0.schema.json`

### Error: "Additional properties are not allowed"

**Cause**: Extra field not in schema

**Fix**: Remove unsupported fields or update schema (if contributing)

### Error: "hash is not blake3 format"

**Cause**: Invalid hash format

**Fix**: Use `blake3_` prefix or calculate actual BLAKE3 hash

---

## ✅ Checklist

Before committing your `.tdln` file:

- [ ] Validates against schema (`jsonschema` passes)
- [ ] All required fields present (`tdln_spec_version`, `node_type`, `id`, `hash`, `policies`)
- [ ] UUIDs are unique
- [ ] Hashes have correct prefix (`blake3_`)
- [ ] Descriptions in metadata
- [ ] Tested with examples

---

**You're ready!** Start building semantic policies with TDLN Pure. 🚀

For questions, see [CONTRIBUTING.md](../CONTRIBUTING.md) or open an issue.
