# TDLN Use Cases

> **Casos de uso do protocolo TDLN** — O que você pode fazer com TDLN além de chips

---

## 🎯 Visão Geral

TDLN é um **protocolo fundacional** para aplicação determinística de políticas. Ele **não é** apenas sobre compilar para hardware (TDLN-Chip), mas sim uma ferramenta versátil para:

```
TDLN Protocol
    ├─→ 🔩 Compilação para Hardware (TDLN-Chip)
    ├─→ 🗣️ Tradução de Linguagem Natural
    ├─→ ✅ Validação Formal de Políticas
    ├─→ 📊 Auditoria e Compliance
    ├─→ 🔗 Composição Modular de Regras
    └─→ ... (qualquer aplicação de políticas determinísticas)
```

---

## 1. 🔩 Compilação para Hardware

**Repositório**: [TDLN-Chip](https://github.com/logline/tdln-chip)

### O Que É

Compilar políticas TDLN para hardware sintetizável:
- **Metal** (GPU Apple Silicon)
- **CUDA** (GPU NVIDIA)
- **Verilog** (FPGA/ASIC)

### Quando Usar

- Edge computing (dispositivos IoT)
- Smart contracts em hardware
- Aceleradores de política customizados
- Validação ultra-rápida (hardware dedicado)

### Exemplo

```json
{
  "policies": [{
    "id": "pb_matmul",
    "operation": "MatMul",
    "dimensions": {"m": 512, "n": 512, "k": 512}
  }]
}
```

→ Compila para shader Metal (GPU M1) em 1.56ms

### Ver Mais

- [examples/01_chip/](../examples/01_chip/README.md)
- [TDLN-Chip README](https://github.com/logline-foundation/TDLN-Chip)

---

## 2. 🗣️ Tradução de Linguagem Natural

### O Que É

Converter especificações humanas em políticas formais `.tdln`:

```
"Usuários premium podem fazer até 1000 downloads/dia"
          ↓ [TDLN Translator]
SemanticUnit com 3 PolicyBits verificáveis
```

### Quando Usar

- Contratos inteligentes legíveis
- Políticas de compliance (GDPR, LGPD)
- Regras de negócio documentadas
- Requisitos de software formalizados

### Benefícios

- ✅ **Determinismo**: Mesma entrada → mesma saída
- ✅ **Auditável**: Hash Blake3 imutável
- ✅ **Verificável**: Schema JSON valida correção

### Implementação

```rust
use tdln_core::{SemanticUnit, PolicyBit};

struct NaturalLanguageParser;

impl NaturalLanguageParser {
    fn parse(&self, input: &str) -> Result<SemanticUnit, Error> {
        // NLP/LLM extrai intenções
        let intents = self.extract_intents(input);
        
        // Mapeia para PolicyBits
        let policies = intents.iter()
            .map(|i| self.intent_to_policy(i))
            .collect();
        
        Ok(SemanticUnit { policies, ..Default::default() })
    }
}
```

### Ver Mais

- [examples/02_translator/](../examples/02_translator/README.md)

---

## 3. ✅ Validação Formal de Políticas

### O Que É

Verificar se políticas são:
- Sintaticamente corretas (schema JSON)
- Semanticamente consistentes (sem contradições)
- Completas (cobrem todos casos)
- Livres de deadlocks

### Quando Usar

- Validação pré-deployment
- Detecção de bugs em políticas
- Análise de coverage (todos caminhos testados)
- Compliance regulatório

### Exemplo

```rust
use tdln_runtime::PolicyValidator;

let validator = PolicyValidator::new();

// Validar sintaxe
validator.validate_syntax(&unit)?;

// Validar semântica (contradições, completude)
validator.validate_semantics(&unit)?;

// Testar com casos de teste
validator.run_test_suite(&unit)?;
```

### Garantias

- ✅ **Sintaxe**: Schema JSON
- ✅ **Integridade**: Blake3 hash
- ✅ **Semântica**: Evaluator testa todos caminhos
- ✅ **Completude**: Coverage analysis

### Ver Mais

- [examples/03_validator/](../examples/03_validator/README.md)

---

## 4. 📊 Auditoria e Compliance

### O Que É

Sistema de rastreabilidade completo com provas criptográficas:
- **TranslationProof**: Cada etapa do pipeline
- **Trace NDJSON**: Log de todas execuções
- **Ed25519 Signature**: Autenticidade irrefutável

### Quando Usar

- Compliance regulatório (GDPR, LGPD, SOX)
- Investigação forense de incidentes
- Análise de decisões passadas
- Provas legais de correção

### Componentes

```json
{
  "proof": {
    "translation_steps": [
      {"stage": "parse", "duration_ms": 1.2, "hash": "blake3_..."},
      {"stage": "policy", "duration_ms": 0.8, "hash": "blake3_..."}
    ],
    "provenance": {
      "created_by": "user_alice",
      "created_at": "2025-01-15T14:30:00Z"
    },
    "signature": "ed25519_..."
  }
}
```

### Garantias Criptográficas

- ✅ **Imutabilidade**: Blake3 hash
- ✅ **Autenticidade**: Ed25519 signature
- ✅ **Não-repúdio**: Assinatura digital
- ✅ **Completude**: Trace NDJSON

### Ver Mais

- [examples/04_audit/](../examples/04_audit/README.md)
- [examples/complete-with-trace.tdln.json](../examples/complete-with-trace.tdln.json)

---

## 5. 🔗 Composição Modular de Regras

### O Que É

Compor políticas complexas a partir de políticas atômicas:

```json
{
  "node_type": "policy_composition",
  "policies": ["pb_auth", "pb_quota", "pb_verified"],
  "aggregator": {"type": "ALL"}
}
```

### Tipos de Composição

| Tipo | Descrição | Uso |
|------|-----------|-----|
| **ALL** | Todas devem passar | Multi-factor auth |
| **ANY** | Pelo menos uma passa | Fallback |
| **THRESHOLD** | Min N de M | Multi-sig wallet |
| **SEQUENTIAL** | Pipeline (A → B → C) | ETL, processamento |

### Quando Usar

- Smart contracts (blockchain)
- RBAC (role-based access control)
- Pipelines de processamento (ETL)
- Circuit breakers, rate limiting

### Padrões Comuns

**Multi-Sig Wallet**:
```json
{
  "policies": ["pb_owner_1", "pb_owner_2", "pb_owner_3"],
  "aggregator": {"type": "THRESHOLD", "min_votes": 2}
}
```

**Circuit Breaker**:
```json
{
  "policies": ["pb_error_rate_ok", "pb_latency_ok", "pb_upstream_healthy"],
  "aggregator": {"type": "ALL"}
}
```

### Ver Mais

- [examples/05_composition/](../examples/05_composition/README.md)

---

## 6. Outros Use Cases

### 6.1 Smart Contracts (Blockchain)

TDLN como linguagem de smart contracts:
- Política = contrato
- Hash Blake3 = endereço do contrato
- Execução determinística garantida

### 6.2 Policy as Code (DevOps)

Infraestrutura definida por políticas:
- Regras de deployment
- Validação de configuração
- Compliance automático

### 6.3 Access Control (IAM)

Sistema de permissões formal:
- RBAC (role-based)
- ABAC (attribute-based)
- Composição de regras

### 6.4 Data Governance

Políticas de dados:
- GDPR Article 17 (Right to Erasure)
- LGPD compliance
- Data retention policies

### 6.5 API Gateway

Validação de requests:
- Rate limiting
- Authentication/authorization
- Schema validation

---

## 📊 Comparação: Use Cases

| Use Case | Core TDLN | TDLN-Chip | Auditoria | Performance |
|----------|-----------|-----------|-----------|-------------|
| **Hardware** | ✅ | ✅ Especializado | ⚠️ Opcional | ⚡ Ultra-rápido |
| **Tradutor LN** | ✅ | ❌ | ✅ Recomendado | 🐢 LLM latency |
| **Validador** | ✅ | ❌ | ✅ Essencial | ⚡ Rápido |
| **Auditoria** | ✅ | ❌ | ✅ Core feature | 🐢 +1.8ms |
| **Composição** | ✅ | ✅ Possível | ⚠️ Opcional | ⚡ Rápido |

---

## 🎯 Como Escolher?

### Use **TDLN Core** quando:
- Precisa aplicar políticas determinísticas
- Quer auditoria e rastreabilidade
- Validação formal é crítica
- Composição modular de regras

### Use **TDLN-Chip** quando:
- Performance é crítica (hardware dedicado)
- Edge computing (IoT, embedded)
- Custo/Watt importa
- Quer independência de GPU comercial

### Use **Auditoria** quando:
- Compliance regulatório (GDPR, SOX)
- Investigação forense necessária
- Não-repúdio é requisito
- Provas legais de correção

---

## 📚 Recursos

- [TDLN Core](../tdln_core/) — Código Rust
- [Specs](../specs/) — Formato canônico
- [Docs](../docs/) — Documentação técnica
- [Examples](../examples/) — Exemplos práticos
- [TDLN-Chip](https://github.com/logline/tdln-chip) — Compilador hardware

---

**TDLN não é só sobre chips. É sobre aplicar políticas de forma determinística, verificável e auditável.** 🎯
