# Contributing to TDLN

**Join us in discovering the unexplored possibilities of deterministic policy execution.**

Thank you for your interest in contributing to TDLN! This is not just a protocol specification — it's a foundation for innovation we haven't fully imagined yet.

---

## 🧭 The Journey So Far

### What We've Discovered

Over 1 year of research and 2 days of intensive validation, we've uncovered some fundamental insights:

**The Wrong Comparison Insight (December 15, 2024)**
- Initial thought: "GPU slower than CPU? TDLN failed?"
- **Reality**: TDLN isn't competing with CPUs — it's an *architecture for silicon*
- This realization changed everything

**The Sweet Spot**
- Optimization Level 2 provides best cost-benefit ratio
- Linear scaling with cores (M1 8-core → M4 Pro 20-core = 2.5x speedup)
- Compute-bound, not memory-bound (only 1.2% bandwidth used)

**The Efficiency Breakthrough**
- 7x better energy efficiency than general-purpose CPUs
- 20,000x cost reduction potential (text file vs silicon)
- Infinite prototyping before tape-out

**The Philosophical Connection**
- Determinism is sacred — everything must be reproducible
- Hashes connect intention → implementation → execution
- Auditability isn't optional, it's architectural

### What We're Still Exploring

**Backend Possibilities We Haven't Built Yet:**
- WebGPU (browser-native execution)
- ROCm (AMD GPUs)
- TPU (Google's tensor processors)
- OpenCL (universal compute)
- Vulkan Compute
- Photonic accelerators
- Memristor-based substrates
- Quantum backends (future)

**Optimization Opportunities:**
- Automatic kernel fusion
- Multi-GPU orchestration
- Heterogeneous execution (CPU + GPU + FPGA)
- Streaming computation for massive datasets
- JIT compilation at runtime

**Integration Patterns:**
- REST API servers
- Python/JavaScript libraries
- Database query engines
- Blockchain smart contracts
- IoT embedded systems

**Tooling Gaps:**
- Visual policy graph editors
- REPL for interactive development
- Debuggers with step-through
- Profilers for bottleneck analysis
- CI/CD pipeline integration

## 🚀 What You Can Discover

We invite you to explore territories we haven't mapped. Here are some directions:

### 1. New Use Cases
**We've proven:** Chip compilation, GPU execution, auditability  
**What else?** Could TDLN be used for:
- Network protocol validation?
- Compiler optimization passes?
- Database query planning?
- Scientific computing workflows?
- **Your idea here**

### 2. Novel Backends
**We have:** Metal, CUDA, Verilog  
**What about:**
- Your favorite hardware platform?
- Distributed systems (Spark, Dask)?
- Specialized accelerators?
- Future technologies?

### 3. Optimization Frontiers
**We discovered:** Level 2 sweet spot, linear scaling  
**What about:**
- Better memory access patterns?
- Kernel fusion strategies?
- Auto-tuning for specific hardware?
- Cross-platform portability optimizations?

### 4. Developer Experience
**We have:** Rust libraries, JSON specs  
**What's missing:**
- Language bindings (Python, JS, Go, etc.)?
- IDE extensions?
- Better error messages?
- Learning resources?

## 📋 Table of Contents

- [Code of Conduct](#code-of-conduct)
- [How Can I Contribute?](#how-can-i-contribute)
- [Development Process](#development-process)
- [Specification Changes](#specification-changes)
- [Pull Request Process](#pull-request-process)
- [Style Guidelines](#style-guidelines)

---

## 🤝 Code of Conduct

By participating in this project, you agree to maintain a respectful and inclusive environment for all contributors.

---

## 🎯 How Can I Contribute?

### Reporting Issues

- **Security vulnerabilities**: Email the maintainers directly (do not open public issues)
- **Bugs**: Open an issue with:
  - Clear description of the problem
  - Steps to reproduce
  - Expected vs actual behavior
  - TDLN version and environment details
  
- **Feature requests**: Open an issue describing:
  - The use case
  - Why it's valuable
  - Proposed solution (if any)

### Improving Documentation

Documentation improvements are always welcome:
- Fix typos, clarify explanations
- Add examples
- Improve tutorials
- Translate documentation

### Proposing Specification Changes

For changes to the `.tdln` format or protocol:
1. Open an issue for discussion first
2. Explain the motivation
3. Provide backward compatibility analysis
4. Include implementation examples

---

## 🔧 Development Process

### Setting Up

```bash
# Clone the repository
git clone https://github.com/your-org/tdln-pure.git
cd tdln-pure

# Validate examples
pip install jsonschema
jsonschema -i examples/premium-user-access.tdln.json specs/tdln-core-v2.0.schema.json
```

### Testing Changes

When modifying the schema or examples:

```bash
# Validate all examples
./scripts/validate-all.sh

# Check format
./scripts/format-check.sh
```

---

## 📐 Specification Changes

### Schema Changes

Changes to `specs/tdln-core-v2.0.schema.json` require:

1. **Backward compatibility**: Existing `.tdln` files must remain valid
2. **Versioning**: Major changes require version bump
3. **Migration guide**: Document how to upgrade
4. **Examples**: Update all examples to demonstrate new features

### Version Numbering

We follow [Semantic Versioning](https://semver.org/):

- **MAJOR** (3.0.0): Breaking changes to the format
- **MINOR** (2.1.0): New optional features, backward compatible
- **PATCH** (2.0.1): Bug fixes, clarifications

---

## 🔄 Pull Request Process

### Before Submitting

1. **Create an issue** to discuss significant changes
2. **Update documentation** to reflect your changes
3. **Add tests/examples** demonstrating the change
4. **Update CHANGELOG.md** with your changes
5. **Ensure validation passes** for all examples

### PR Guidelines

- **Title**: Clear, descriptive (e.g., "Add materialization hints to schema")
- **Description**: 
  - What changed and why
  - Link to related issues
  - Breaking changes (if any)
- **Commits**: 
  - Atomic, focused commits
  - Clear commit messages
  - Sign commits (`git commit -s`)

### Review Process

1. Maintainers will review your PR
2. Address feedback and update as needed
3. Once approved, maintainers will merge

---

## 📝 Style Guidelines

### JSON Schema

```json
{
  "type": "object",
  "required": ["field_name"],
  "properties": {
    "field_name": {
      "type": "string",
      "description": "Clear, concise description"
    }
  }
}
```

### Markdown Documentation

- Use clear headings (`##`, `###`)
- Include code examples
- Use emojis sparingly (section headers only)
- Keep lines under 120 characters
- Use tables for comparisons

### Example Files

- **Canonical examples** (`.tdln.json`): Must validate against schema
- **Reference examples** (`.example.*`): Clearly marked as non-canonical
- Include comments explaining non-obvious parts
- Use realistic, clear use cases

---

## 🎨 File Naming Conventions

- **Specs**: `{name}-{version}.schema.json`
- **Examples**: `{use-case}.tdln.json` (canonical) or `{name}.example.{ext}`
- **Docs**: `SCREAMING_SNAKE_CASE.md` for top-level, `kebab-case.md` for docs/

---

## 🏷️ Commit Message Format

```
<type>(<scope>): <subject>

<body>

<footer>
```

**Types**:
- `spec`: Changes to schema/specification
- `docs`: Documentation changes
- `examples`: Example updates
- `chore`: Maintenance tasks
- `fix`: Bug fixes

**Example**:
```
spec(schema): Add materialization_hints field

Add optional materialization_hints to SemanticUnit for backend
compilation optimization. Maintains backward compatibility.

Closes #42
```

---

## 🚀 Release Process

(For maintainers)

1. Update `CHANGELOG.md` with version and date
2. Update version in `specs/tdln-core-v2.0.schema.json`
3. Tag release: `git tag -a v2.0.0 -m "Release v2.0.0"`
4. Push tag: `git push origin v2.0.0`
5. Create GitHub release with changelog

---

## ❓ Questions?

- Open a [discussion](https://github.com/your-org/tdln-pure/discussions)
- Check existing issues
- Read the [documentation](./docs/)

---

## 🙏 Thank You!

Your contributions help make TDLN better for everyone. We appreciate your time and effort!

---

**License**: By contributing, you agree that your contributions will be licensed under the MIT License.
