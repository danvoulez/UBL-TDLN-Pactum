# EXAMPLE ONLY — modelo ilustrativo. NÃO é arquivo canônico. Adapte antes de usar.
set -euo pipefail
if git ls-files | grep -qE '\.example\.(yml|yaml|json|ndjson|md|sh)$'; then
  echo "❌ Arquivos *.example.* detectados. Remova-os do pacote de release."
  exit 1
fi
