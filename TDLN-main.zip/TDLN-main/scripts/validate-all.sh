#!/bin/bash
# Validate all .tdln.json files against the canonical schema

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"
SCHEMA="$ROOT_DIR/specs/tdln-core-v2.0.schema.json"

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo "🔍 Validating TDLN files against schema..."
echo "Schema: $SCHEMA"
echo ""

# Check if jsonschema is installed
if ! command -v jsonschema &> /dev/null; then
    echo "❌ jsonschema not found. Install with: pip install jsonschema"
    exit 1
fi

# Find all .tdln.json files
TDLN_FILES=$(find "$ROOT_DIR/examples" -name "*.tdln.json" 2>/dev/null)

if [ -z "$TDLN_FILES" ]; then
    echo "⚠️  No .tdln.json files found"
    exit 0
fi

TOTAL=0
PASSED=0
FAILED=0

for file in $TDLN_FILES; do
    TOTAL=$((TOTAL + 1))
    filename=$(basename "$file")
    
    if jsonschema -i "$file" "$SCHEMA" 2>&1 | grep -q "is valid"; then
        echo -e "${GREEN}✅ $filename${NC}"
        PASSED=$((PASSED + 1))
    else
        echo -e "${RED}❌ $filename${NC}"
        jsonschema -i "$file" "$SCHEMA" 2>&1 | head -5
        FAILED=$((FAILED + 1))
    fi
done

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Total: $TOTAL | Passed: $PASSED | Failed: $FAILED"

if [ $FAILED -eq 0 ]; then
    echo -e "${GREEN}🎉 All validations passed!${NC}"
    exit 0
else
    echo -e "${RED}❌ Some validations failed${NC}"
    exit 1
fi
