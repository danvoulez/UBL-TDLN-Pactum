#!/bin/bash
# Format check for markdown files

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "📝 Checking markdown format..."
echo ""

WARNINGS=0

# Check for trailing whitespace
echo "Checking for trailing whitespace..."
if grep -r ' $' "$ROOT_DIR"/*.md "$ROOT_DIR"/docs/*.md 2>/dev/null; then
    echo -e "${YELLOW}⚠️  Found trailing whitespace${NC}"
    WARNINGS=$((WARNINGS + 1))
else
    echo -e "${GREEN}✅ No trailing whitespace${NC}"
fi

echo ""

# Check for long lines (>120 chars)
echo "Checking for long lines (>120 chars)..."
LONG_LINES=$(grep -r '.\{121\}' "$ROOT_DIR"/*.md "$ROOT_DIR"/docs/*.md 2>/dev/null | wc -l)
if [ "$LONG_LINES" -gt 0 ]; then
    echo -e "${YELLOW}⚠️  Found $LONG_LINES long lines${NC}"
    WARNINGS=$((WARNINGS + 1))
else
    echo -e "${GREEN}✅ All lines under 120 characters${NC}"
fi

echo ""

# Check for broken links (basic check)
echo "Checking for relative links..."
BROKEN_LINKS=$(grep -r '\[.*\](.*/.*\.md)' "$ROOT_DIR"/*.md "$ROOT_DIR"/docs/*.md 2>/dev/null | grep -v 'http' | wc -l)
if [ "$BROKEN_LINKS" -gt 0 ]; then
    echo -e "${YELLOW}ℹ️  Found $BROKEN_LINKS relative markdown links (verify manually)${NC}"
else
    echo -e "${GREEN}✅ No relative markdown links${NC}"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ $WARNINGS -eq 0 ]; then
    echo -e "${GREEN}🎉 Format checks passed!${NC}"
    exit 0
else
    echo -e "${YELLOW}ℹ️  Found $WARNINGS formatting issues (non-critical)${NC}"
    exit 0
fi
