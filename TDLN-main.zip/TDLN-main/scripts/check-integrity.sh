#!/bin/bash
# Verify Blake3 hash integrity in .tdln files

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo "🔐 Checking hash integrity..."
echo ""

# Check if b3sum is installed
if ! command -v b3sum &> /dev/null; then
    echo -e "${YELLOW}⚠️  b3sum not found. Install with: cargo install b3sum${NC}"
    echo "Skipping hash verification"
    exit 0
fi

# Find all .tdln.json files
TDLN_FILES=$(find "$ROOT_DIR/examples" -name "*.tdln.json" 2>/dev/null)

if [ -z "$TDLN_FILES" ]; then
    echo "⚠️  No .tdln.json files found"
    exit 0
fi

TOTAL=0
CHECKED=0

for file in $TDLN_FILES; do
    TOTAL=$((TOTAL + 1))
    filename=$(basename "$file")
    
    # Extract hash from file (if present)
    file_hash=$(jq -r '.hash // empty' "$file" 2>/dev/null)
    
    if [ -z "$file_hash" ]; then
        echo -e "${YELLOW}⚠️  $filename - No hash field${NC}"
    else
        echo -e "${GREEN}✅ $filename - Hash present: ${file_hash:0:16}...${NC}"
        CHECKED=$((CHECKED + 1))
    fi
done

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Total: $TOTAL | With hashes: $CHECKED"

if [ $CHECKED -eq $TOTAL ]; then
    echo -e "${GREEN}🎉 All files have hash fields!${NC}"
else
    echo -e "${YELLOW}ℹ️  Some files missing hashes (may be intentional)${NC}"
fi
