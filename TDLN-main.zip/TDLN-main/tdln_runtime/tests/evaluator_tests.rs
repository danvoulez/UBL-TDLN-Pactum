use tdln_runtime::{evaluate, Context};
use tdln_core::{Expression, Value, SemanticOp};

#[test]
fn test_evaluate_literal_boolean() {
    let context = Context::new();
    let expr = Expression::Literal(Value::Boolean(true));
    
    let result = evaluate(&expr, &context).unwrap();
    assert_eq!(result, Value::Boolean(true));
}

#[test]
fn test_evaluate_literal_integer() {
    let context = Context::new();
    let expr = Expression::Literal(Value::Integer(42));
    
    let result = evaluate(&expr, &context).unwrap();
    assert_eq!(result, Value::Integer(42));
}

#[test]
fn test_evaluate_and_true() {
    let context = Context::new();
    let expr = Expression::BinaryOp {
        op: SemanticOp::And,
        left: Box::new(Expression::Literal(Value::Boolean(true))),
        right: Box::new(Expression::Literal(Value::Boolean(true))),
    };
    
    let result = evaluate(&expr, &context).unwrap();
    assert_eq!(result, Value::Boolean(true));
}

#[test]
fn test_evaluate_and_false() {
    let context = Context::new();
    let expr = Expression::BinaryOp {
        op: SemanticOp::And,
        left: Box::new(Expression::Literal(Value::Boolean(true))),
        right: Box::new(Expression::Literal(Value::Boolean(false))),
    };
    
    let result = evaluate(&expr, &context).unwrap();
    assert_eq!(result, Value::Boolean(false));
}

#[test]
fn test_evaluate_or_true() {
    let context = Context::new();
    let expr = Expression::BinaryOp {
        op: SemanticOp::Or,
        left: Box::new(Expression::Literal(Value::Boolean(true))),
        right: Box::new(Expression::Literal(Value::Boolean(false))),
    };
    
    let result = evaluate(&expr, &context).unwrap();
    assert_eq!(result, Value::Boolean(true));
}

#[test]
fn test_evaluate_or_false() {
    let context = Context::new();
    let expr = Expression::BinaryOp {
        op: SemanticOp::Or,
        left: Box::new(Expression::Literal(Value::Boolean(false))),
        right: Box::new(Expression::Literal(Value::Boolean(false))),
    };
    
    let result = evaluate(&expr, &context).unwrap();
    assert_eq!(result, Value::Boolean(false));
}

#[test]
fn test_evaluate_add_integers() {
    let context = Context::new();
    let expr = Expression::BinaryOp {
        op: SemanticOp::Add,
        left: Box::new(Expression::Literal(Value::Integer(5))),
        right: Box::new(Expression::Literal(Value::Integer(10))),
    };
    
    let result = evaluate(&expr, &context).unwrap();
    assert_eq!(result, Value::Integer(15));
}

#[test]
fn test_evaluate_nested_expression() {
    let context = Context::new();
    
    // (true OR false) AND true
    let expr = Expression::BinaryOp {
        op: SemanticOp::And,
        left: Box::new(Expression::BinaryOp {
            op: SemanticOp::Or,
            left: Box::new(Expression::Literal(Value::Boolean(false))),
            right: Box::new(Expression::Literal(Value::Boolean(true))),
        }),
        right: Box::new(Expression::Literal(Value::Boolean(true))),
    };
    
    let result = evaluate(&expr, &context).unwrap();
    assert_eq!(result, Value::Boolean(true));
}
