use tdln_runtime::{evaluate, Value};
use tdln_core::{Expression, SemanticOp};
use std::collections::HashMap;

fn make_binary_op(op: SemanticOp, left: Value, right: Value) -> Expression {
    Expression::BinaryOp {
        op,
        left: Box::new(Expression::Literal(left)),
        right: Box::new(Expression::Literal(right)),
    }
}

#[test]
fn test_eq_integers() {
    let ctx = HashMap::new();
    
    // Equal
    let expr = make_binary_op(SemanticOp::Eq, Value::Integer(5), Value::Integer(5));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(true));
    
    // Not equal
    let expr = make_binary_op(SemanticOp::Eq, Value::Integer(5), Value::Integer(3));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(false));
}

#[test]
fn test_eq_floats() {
    let ctx = HashMap::new();
    
    // Equal (within epsilon)
    let expr = make_binary_op(SemanticOp::Eq, Value::Float(1.0), Value::Float(1.0));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(true));
    
    // Not equal
    let expr = make_binary_op(SemanticOp::Eq, Value::Float(1.0), Value::Float(2.0));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(false));
}

#[test]
fn test_eq_strings() {
    let ctx = HashMap::new();
    
    let expr = make_binary_op(
        SemanticOp::Eq,
        Value::String("hello".to_string()),
        Value::String("hello".to_string())
    );
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(true));
    
    let expr = make_binary_op(
        SemanticOp::Eq,
        Value::String("hello".to_string()),
        Value::String("world".to_string())
    );
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(false));
}

#[test]
fn test_neq() {
    let ctx = HashMap::new();
    
    let expr = make_binary_op(SemanticOp::Neq, Value::Integer(5), Value::Integer(3));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(true));
    
    let expr = make_binary_op(SemanticOp::Neq, Value::Integer(5), Value::Integer(5));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(false));
}

#[test]
fn test_gt() {
    let ctx = HashMap::new();
    
    // Integer
    let expr = make_binary_op(SemanticOp::Gt, Value::Integer(10), Value::Integer(5));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(true));
    
    let expr = make_binary_op(SemanticOp::Gt, Value::Integer(3), Value::Integer(5));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(false));
    
    // Float
    let expr = make_binary_op(SemanticOp::Gt, Value::Float(10.5), Value::Float(5.2));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(true));
}

#[test]
fn test_lt() {
    let ctx = HashMap::new();
    
    let expr = make_binary_op(SemanticOp::Lt, Value::Integer(3), Value::Integer(5));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(true));
    
    let expr = make_binary_op(SemanticOp::Lt, Value::Integer(10), Value::Integer(5));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(false));
}

#[test]
fn test_gte() {
    let ctx = HashMap::new();
    
    // Greater
    let expr = make_binary_op(SemanticOp::Gte, Value::Integer(10), Value::Integer(5));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(true));
    
    // Equal
    let expr = make_binary_op(SemanticOp::Gte, Value::Integer(5), Value::Integer(5));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(true));
    
    // Less
    let expr = make_binary_op(SemanticOp::Gte, Value::Integer(3), Value::Integer(5));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(false));
}

#[test]
fn test_lte() {
    let ctx = HashMap::new();
    
    // Less
    let expr = make_binary_op(SemanticOp::Lte, Value::Integer(3), Value::Integer(5));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(true));
    
    // Equal
    let expr = make_binary_op(SemanticOp::Lte, Value::Integer(5), Value::Integer(5));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(true));
    
    // Greater
    let expr = make_binary_op(SemanticOp::Lte, Value::Integer(10), Value::Integer(5));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(false));
}

#[test]
fn test_xor() {
    let ctx = HashMap::new();
    
    // true XOR false = true
    let expr = make_binary_op(SemanticOp::Xor, Value::Boolean(true), Value::Boolean(false));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(true));
    
    // true XOR true = false
    let expr = make_binary_op(SemanticOp::Xor, Value::Boolean(true), Value::Boolean(true));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(false));
    
    // false XOR false = false
    let expr = make_binary_op(SemanticOp::Xor, Value::Boolean(false), Value::Boolean(false));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Boolean(false));
}

#[test]
fn test_sub() {
    let ctx = HashMap::new();
    
    // Integer subtraction
    let expr = make_binary_op(SemanticOp::Sub, Value::Integer(10), Value::Integer(3));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Integer(7));
    
    // Float subtraction
    let expr = make_binary_op(SemanticOp::Sub, Value::Float(10.5), Value::Float(3.2));
    if let Value::Float(result) = evaluate(&expr, &ctx).unwrap() {
        assert!((result - 7.3).abs() < 1e-10);
    } else {
        panic!("Expected Float result");
    }
}

#[test]
fn test_div() {
    let ctx = HashMap::new();
    
    // Integer division
    let expr = make_binary_op(SemanticOp::Div, Value::Integer(10), Value::Integer(2));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Integer(5));
    
    // Float division
    let expr = make_binary_op(SemanticOp::Div, Value::Float(10.0), Value::Float(4.0));
    assert_eq!(evaluate(&expr, &ctx).unwrap(), Value::Float(2.5));
}

#[test]
fn test_div_by_zero_integer() {
    let ctx = HashMap::new();
    
    let expr = make_binary_op(SemanticOp::Div, Value::Integer(10), Value::Integer(0));
    let result = evaluate(&expr, &ctx);
    assert!(result.is_err());
    assert!(result.unwrap_err().contains("Division by zero"));
}

#[test]
fn test_div_by_zero_float() {
    let ctx = HashMap::new();
    
    let expr = make_binary_op(SemanticOp::Div, Value::Float(10.0), Value::Float(0.0));
    let result = evaluate(&expr, &ctx);
    assert!(result.is_err());
    assert!(result.unwrap_err().contains("Division by zero"));
}

#[test]
fn test_matrix_dimension_validation() {
    let ctx = HashMap::new();
    
    // Create oversized matrix (> 10,000 dimensions)
    let huge_matrix = Value::Matrix {
        rows: 15_000,
        cols: 15_000,
        data: vec![],  // Empty data, just testing validation
    };
    
    let normal_matrix = Value::Matrix {
        rows: 2,
        cols: 2,
        data: vec![1.0, 2.0, 3.0, 4.0],
    };
    
    let expr = make_binary_op(SemanticOp::MatMul, huge_matrix, normal_matrix);
    let result = evaluate(&expr, &ctx);
    
    assert!(result.is_err());
    assert!(result.unwrap_err().contains("dimensions too large"));
}
