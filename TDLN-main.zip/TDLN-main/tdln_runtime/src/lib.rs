use ndarray::{Array1, Array2};
use std::collections::HashMap;

pub use tdln_core::*;

pub type Context = HashMap<String, Value>;

pub fn evaluate(expr: &Expression, context: &Context) -> Result<Value, String> {
    match expr {
        Expression::Literal(v) => Ok(v.clone()),
        
        Expression::Variable(name) => {
            context.get(name)
                .cloned()
                .ok_or_else(|| format!("Variable '{name}' not found"))
        }
        
        Expression::ContextRef { path } => {
            if path.is_empty() {
                return Err("Empty context path".to_string());
            }
            let key = &path[0];
            context.get(key)
                .cloned()
                .ok_or_else(|| format!("Variable '{key}' not found"))
        }
        
        Expression::BinaryOp { op, left, right } => {
            let left_val = evaluate(left, context)?;
            let right_val = evaluate(right, context)?;
            
            match op {
                SemanticOp::And => match (left_val, right_val) {
                    (Value::Boolean(a), Value::Boolean(b)) => Ok(Value::Boolean(a && b)),
                    _ => Err("AND requires boolean operands".to_string()),
                },
                SemanticOp::Or => match (left_val, right_val) {
                    (Value::Boolean(a), Value::Boolean(b)) => Ok(Value::Boolean(a || b)),
                    _ => Err("OR requires boolean operands".to_string()),
                },
                SemanticOp::Xor => match (left_val, right_val) {
                    (Value::Boolean(a), Value::Boolean(b)) => Ok(Value::Boolean(a ^ b)),
                    _ => Err("XOR requires boolean operands".to_string()),
                },
                SemanticOp::Eq => match (left_val, right_val) {
                    (Value::Boolean(a), Value::Boolean(b)) => Ok(Value::Boolean(a == b)),
                    (Value::Integer(a), Value::Integer(b)) => Ok(Value::Boolean(a == b)),
                    (Value::Float(a), Value::Float(b)) => Ok(Value::Boolean((a - b).abs() < f64::EPSILON)),
                    (Value::String(a), Value::String(b)) => Ok(Value::Boolean(a == b)),
                    _ => Err("EQ requires comparable operands of same type".to_string()),
                },
                SemanticOp::Neq => match (left_val, right_val) {
                    (Value::Boolean(a), Value::Boolean(b)) => Ok(Value::Boolean(a != b)),
                    (Value::Integer(a), Value::Integer(b)) => Ok(Value::Boolean(a != b)),
                    (Value::Float(a), Value::Float(b)) => Ok(Value::Boolean((a - b).abs() >= f64::EPSILON)),
                    (Value::String(a), Value::String(b)) => Ok(Value::Boolean(a != b)),
                    _ => Err("NEQ requires comparable operands of same type".to_string()),
                },
                SemanticOp::Gt => match (left_val, right_val) {
                    (Value::Integer(a), Value::Integer(b)) => Ok(Value::Boolean(a > b)),
                    (Value::Float(a), Value::Float(b)) => Ok(Value::Boolean(a > b)),
                    _ => Err("GT requires numeric operands".to_string()),
                },
                SemanticOp::Lt => match (left_val, right_val) {
                    (Value::Integer(a), Value::Integer(b)) => Ok(Value::Boolean(a < b)),
                    (Value::Float(a), Value::Float(b)) => Ok(Value::Boolean(a < b)),
                    _ => Err("LT requires numeric operands".to_string()),
                },
                SemanticOp::Gte => match (left_val, right_val) {
                    (Value::Integer(a), Value::Integer(b)) => Ok(Value::Boolean(a >= b)),
                    (Value::Float(a), Value::Float(b)) => Ok(Value::Boolean(a >= b)),
                    _ => Err("GTE requires numeric operands".to_string()),
                },
                SemanticOp::Lte => match (left_val, right_val) {
                    (Value::Integer(a), Value::Integer(b)) => Ok(Value::Boolean(a <= b)),
                    (Value::Float(a), Value::Float(b)) => Ok(Value::Boolean(a <= b)),
                    _ => Err("LTE requires numeric operands".to_string()),
                },
                SemanticOp::Add => match (left_val, right_val) {
                    (Value::Integer(a), Value::Integer(b)) => Ok(Value::Integer(a + b)),
                    (Value::Float(a), Value::Float(b)) => Ok(Value::Float(a + b)),
                    _ => Err("ADD requires numeric operands".to_string()),
                },
                SemanticOp::Mul => match (left_val, right_val) {
                    (Value::Integer(a), Value::Integer(b)) => Ok(Value::Integer(a * b)),
                    (Value::Float(a), Value::Float(b)) => Ok(Value::Float(a * b)),
                    _ => Err("MUL requires numeric operands".to_string()),
                },
                SemanticOp::Sub => match (left_val, right_val) {
                    (Value::Integer(a), Value::Integer(b)) => Ok(Value::Integer(a - b)),
                    (Value::Float(a), Value::Float(b)) => Ok(Value::Float(a - b)),
                    _ => Err("SUB requires numeric operands".to_string()),
                },
                SemanticOp::Div => match (left_val, right_val) {
                    (Value::Integer(a), Value::Integer(b)) => {
                        if b == 0 {
                            Err("Division by zero".to_string())
                        } else {
                            Ok(Value::Integer(a / b))
                        }
                    }
                    (Value::Float(a), Value::Float(b)) => {
                        if b.abs() < f64::EPSILON {
                            Err("Division by zero".to_string())
                        } else {
                            Ok(Value::Float(a / b))
                        }
                    }
                    _ => Err("DIV requires numeric operands".to_string()),
                },
                SemanticOp::MatMul => {
                    match (left_val, right_val) {
                        (Value::Matrix { rows: r1, cols: c1, data: d1 }, 
                         Value::Matrix { rows: r2, cols: c2, data: d2 }) => {
                            // Validate dimensions to prevent OOM
                            const MAX_DIM: usize = 10_000;
                            if r1 > MAX_DIM || c1 > MAX_DIM || r2 > MAX_DIM || c2 > MAX_DIM {
                                return Err(format!(
                                    "Matrix dimensions too large: max {MAX_DIM}, got {}x{} @ {}x{}",
                                    r1, c1, r2, c2
                                ));
                            }
                            
                            if c1 != r2 {
                                return Err(format!(
                                    "MatMul dimension mismatch: {r1}x{c1} @ {r2}x{c2}"
                                ));
                            }
                            
                            let a = Array2::from_shape_vec((r1, c1), d1)
                                .map_err(|e| format!("Matrix A error: {e}"))?;
                            let b = Array2::from_shape_vec((r2, c2), d2)
                                .map_err(|e| format!("Matrix B error: {e}"))?;
                            
                            let result = a.dot(&b);
                            Ok(Value::Matrix {
                                rows: result.nrows(),
                                cols: result.ncols(),
                                data: result.into_raw_vec(),
                            })
                        }
                        _ => Err("MatMul requires matrix operands".to_string()),
                    }
                }
                SemanticOp::DotProduct => {
                    match (left_val, right_val) {
                        (Value::Array(a), Value::Array(b)) => {
                            if a.len() != b.len() {
                                return Err(format!(
                                    "DotProduct dimension mismatch: {} != {}",
                                    a.len(), b.len()
                                ));
                            }
                            
                            let av: Vec<f64> = a.iter().map(|v| match v {
                                Value::Float(f) => Ok(*f),
                                Value::Integer(i) => Ok(*i as f64),
                                _ => Err("DotProduct requires numeric values".to_string()),
                            }).collect::<Result<Vec<_>, _>>()?;
                            
                            let bv: Vec<f64> = b.iter().map(|v| match v {
                                Value::Float(f) => Ok(*f),
                                Value::Integer(i) => Ok(*i as f64),
                                _ => Err("DotProduct requires numeric values".to_string()),
                            }).collect::<Result<Vec<_>, _>>()?;
                            
                            let arr_a = Array1::from_vec(av);
                            let arr_b = Array1::from_vec(bv);
                            
                            Ok(Value::Float(arr_a.dot(&arr_b)))
                        }
                        _ => Err("DotProduct requires array operands".to_string()),
                    }
                }
                _ => Err(format!("Unsupported binary operation: {op:?}")),
            }
        }
        
        Expression::UnaryOp { op, arg } => {
            let val = evaluate(arg, context)?;
            match op {
                SemanticOp::Not => match val {
                    Value::Boolean(b) => Ok(Value::Boolean(!b)),
                    _ => Err("NOT requires boolean operand".to_string()),
                },
                SemanticOp::Transpose => match val {
                    Value::Matrix { rows, cols, data } => {
                        let m = Array2::from_shape_vec((rows, cols), data)
                            .map_err(|e| format!("Matrix error: {e}"))?;
                        let t = m.t().to_owned();
                        Ok(Value::Matrix {
                            rows: t.nrows(),
                            cols: t.ncols(),
                            data: t.into_raw_vec(),
                        })
                    }
                    _ => Err("Transpose requires matrix operand".to_string()),
                }
                _ => Err(format!("Unsupported unary operation: {op:?}")),
            }
        }
        
        _ => Err(format!("Unsupported expression: {expr:?}")),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_matmul() {
        let mut ctx = HashMap::new();
        
        // 2x3 matrix
        ctx.insert("A".to_string(), Value::Matrix {
            rows: 2,
            cols: 3,
            data: vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
        });
        
        // 3x2 matrix
        ctx.insert("B".to_string(), Value::Matrix {
            rows: 3,
            cols: 2,
            data: vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
        });
        
        let expr = matrix_multiply(
            Expression::Variable("A".to_string()),
            Expression::Variable("B".to_string()),
        );
        
        let result = evaluate(&expr, &ctx).unwrap();
        if let Value::Matrix { rows, cols, data } = result {
            assert_eq!(rows, 2);
            assert_eq!(cols, 2);
            // [1,2,3] @ [1,2]   = [22, 28]
            // [4,5,6]   [3,4]     [49, 64]
            //           [5,6]
            assert_eq!(data[0], 22.0);
            assert_eq!(data[1], 28.0);
            assert_eq!(data[2], 49.0);
            assert_eq!(data[3], 64.0);
        } else {
            panic!("Expected matrix result");
        }
    }

    #[test]
    fn test_dot_product() {
        let mut ctx = HashMap::new();
        ctx.insert("v1".to_string(), Value::Array(vec![
            Value::Float(1.0),
            Value::Float(2.0),
            Value::Float(3.0),
        ]));
        ctx.insert("v2".to_string(), Value::Array(vec![
            Value::Float(4.0),
            Value::Float(5.0),
            Value::Float(6.0),
        ]));
        
        let expr = dot_product(
            Expression::Variable("v1".to_string()),
            Expression::Variable("v2".to_string()),
        );
        
        let result = evaluate(&expr, &ctx).unwrap();
        if let Value::Float(f) = result {
            assert_eq!(f, 32.0); // 1*4 + 2*5 + 3*6 = 32
        } else {
            panic!("Expected float result");
        }
    }
}
