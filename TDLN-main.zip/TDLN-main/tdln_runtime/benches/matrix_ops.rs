use criterion::{black_box, criterion_group, criterion_main, Criterion, BenchmarkId};
use ndarray::{Array1, Array2};
use tdln_runtime::{evaluate, Value};
use std::collections::HashMap;

fn benchmark_matmul(c: &mut Criterion) {
    let mut group = c.benchmark_group("matmul_mac_mini");
    
    for size in [64, 128, 256, 512].iter() {
        // TDLN semantic chip MatMul
        group.bench_with_input(BenchmarkId::new("tdln", size), size, |bencher, &size| {
            let mat_a = Array2::from_elem((size, size), 1.5);
            let mat_b = Array2::from_elem((size, size), 2.0);
            
            let mut ctx = HashMap::new();
            ctx.insert("A".to_string(), Value::Matrix {
                rows: size,
                cols: size,
                data: mat_a.clone().into_raw_vec(),
            });
            ctx.insert("B".to_string(), Value::Matrix {
                rows: size,
                cols: size,
                data: mat_b.clone().into_raw_vec(),
            });
            
            let expr = tdln_core::matrix_multiply(
                tdln_core::Expression::Variable("A".to_string()),
                tdln_core::Expression::Variable("B".to_string()),
            );
            
            bencher.iter(|| {
                black_box(evaluate(&expr, &ctx).unwrap());
            });
        });

        // Baseline ndarray CPU MatMul
        group.bench_with_input(BenchmarkId::new("cpu_baseline", size), size, |bencher, &size| {
            let mat_a = Array2::from_elem((size, size), 1.5);
            let mat_b = Array2::from_elem((size, size), 2.0);
            
            bencher.iter(|| {
                black_box(mat_a.dot(&mat_b));
            });
        });
    }
    
    group.finish();
}

fn benchmark_dot_product(c: &mut Criterion) {
    let mut group = c.benchmark_group("dot_product_mac_mini");
    
    for size in [1000, 10000, 100000, 1000000].iter() {
        // TDLN semantic chip DotProduct
        group.bench_with_input(BenchmarkId::new("tdln", size), size, |bencher, &size| {
            let v1_data: Vec<Value> = (0..size).map(|_| Value::Float(1.5)).collect();
            let v2_data: Vec<Value> = (0..size).map(|_| Value::Float(2.0)).collect();
            
            let mut ctx = HashMap::new();
            ctx.insert("v1".to_string(), Value::Array(v1_data));
            ctx.insert("v2".to_string(), Value::Array(v2_data));
            
            let expr = tdln_core::dot_product(
                tdln_core::Expression::Variable("v1".to_string()),
                tdln_core::Expression::Variable("v2".to_string()),
            );
            
            bencher.iter(|| {
                black_box(evaluate(&expr, &ctx).unwrap());
            });
        });

        // Baseline CPU DotProduct
        group.bench_with_input(BenchmarkId::new("cpu_baseline", size), size, |bencher, &size| {
            let vec1 = Array1::from_elem(size, 1.5);
            let vec2 = Array1::from_elem(size, 2.0);
            
            bencher.iter(|| {
                black_box(vec1.dot(&vec2));
            });
        });
    }
    
    group.finish();
}

criterion_group!(benches, benchmark_matmul, benchmark_dot_product);
criterion_main!(benches);
